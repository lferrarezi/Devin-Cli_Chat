'use strict';
const vscode = require('vscode');
const fs = require('fs');
const path = require('path');
const os = require('os');
const cp = require('child_process');

const EXT = 'devinCliChat';
const CACHE_KEY = 'devinCliChat.modelosDetectados.v2';
const FALLBACK_MODELS = ['auto'];
const KNOWN_MODEL_HINTS = new Set(['opus','sonnet','swe','codex','gemini','auto']);

let provider;
let status;
let extensionContext;
let modelDiscovery = {
  status: 'idle',
  detail: 'Aguardando descoberta automatica de modelos.',
  source: 'inicial',
  models: []
};
let modelDiscoveryPromise;

function cfg(){ return vscode.workspace.getConfiguration(EXT); }
function root(){ return vscode.workspace.workspaceFolders && vscode.workspace.workspaceFolders[0] ? vscode.workspace.workspaceFolders[0].uri.fsPath : undefined; }
function rootName(){ return vscode.workspace.workspaceFolders && vscode.workspace.workspaceFolders[0] ? vscode.workspace.workspaceFolders[0].name : 'sem pasta aberta'; }
function home(p){ if(!p) return p; const s=String(p); return s === '~' ? os.homedir() : (s.startsWith('~/') || s.startsWith('~\\')) ? path.join(os.homedir(), s.slice(2)) : s; }
function absMaybe(p){ const v = home(p); if(!v) return v; return path.isAbsolute(v) ? v : path.join(root() || os.homedir(), v); }
function exists(p){ try { return !!p && fs.existsSync(p); } catch { return false; } }
function quote(s){ return `'${String(s).replace(/'/g, `'\\''`)}'`; }
function normalizeModel(m){ const value = String(m || '').trim(); if(!value || value === 'default' || value === 'padrao') return 'auto'; return value; }
function model(){ return normalizeModel(cfg().get('modeloAtual') || 'auto'); }
function modelForCli(){ const m = model(); return m === 'auto' ? undefined : m; }
function agent(){ return cfg().get('agenteAtual') || 'auto'; }
function devinPath(){ return cfg().get('caminhoDevin') || 'devin'; }
function findGitBash(){
  const c = [
    home(cfg().get('gitBashPath')),
    process.env.GIT_BASH_PATH,
    'C:\\Program Files\\Git\\bin\\bash.exe',
    'C:\\Program Files\\Git\\usr\\bin\\bash.exe',
    'C:\\Program Files (x86)\\Git\\bin\\bash.exe',
    path.join(os.homedir(),'AppData','Local','Programs','Git','bin','bash.exe')
  ].filter(Boolean);
  return c.find(exists);
}
function terminalShell(){ if(process.platform === 'win32' && cfg().get('usarGitBashNoWindows', true)){ return findGitBash(); } return process.env.SHELL || undefined; }
function manualModels(){ const configured = cfg().get('modelosDisponiveis'); return Array.isArray(configured) ? configured.map(String).map(s=>s.trim()).filter(Boolean) : []; }
function models(){
  const detected = Array.isArray(modelDiscovery.models) ? modelDiscovery.models : [];
  let list = detected.length ? detected : manualModels();
  if(!list.length) list = FALLBACK_MODELS;
  const out = ['auto', ...list];
  const current = model();
  if(current && !out.includes(current)) out.unshift(current);
  return Array.from(new Set(out.filter(Boolean)));
}
function modelSourceLabel(){
  if(modelDiscovery.status === 'loading') return 'detectando modelos no Devin CLI...';
  if(modelDiscovery.models && modelDiscovery.models.length) return `modelos detectados via ${modelDiscovery.source}`;
  if(manualModels().length) return 'usando fallback manual em devinCliChat.modelosDisponiveis';
  return modelDiscovery.detail || 'sem modelos detectados; usando auto';
}
function baseArgs(){ const out = [...(cfg().get('argumentosPadrao') || []).map(String).filter(Boolean)]; const ma = String(cfg().get('argumentoModelo') || '').trim(); const m = modelForCli(); if(ma && m) out.push(ma, m); return out; }
function fullPrompt(text){ const prefix = cfg().get('prefixoPromptPadrao') || ''; const selectedModel = modelForCli() || 'auto (padrao do Devin CLI)'; const ctx = [
  `Workspace VS Code: ${rootName()}`,
  root()?`Diretorio raiz: ${root()}`:'Diretorio raiz: nao ha pasta aberta',
  `Modelo selecionado: ${selectedModel}`,
  agent() !== 'auto' ? `Agente selecionado: ${agent()}` : 'Agente selecionado: auto'
].join('\n');
const agentHint = agent() !== 'auto' ? `Use o perfil/subagente Devin chamado "${agent()}" quando aplicavel. Se a CLI nao aceitar selecao direta de agente nesta chamada, trate este agente como persona operacional e siga as instrucoes do respectivo AGENT.md.` : '';
return [prefix, ctx, agentHint, text].filter(Boolean).join('\n\n'); }
function terminalCommand(text){ const args = baseArgs().map(quote).join(' '); const exe = quote(devinPath()); if(!text) return [exe, args].filter(Boolean).join(' '); return [exe, args, '--', quote(fullPrompt(text))].filter(Boolean).join(' '); }
function openTerminal(text){ const sh = terminalShell(); const t = vscode.window.createTerminal({ name:(cfg().get('nomeTerminal') || 'Devin Cli Chat'), cwd: root() || os.homedir(), shellPath: sh, shellArgs: process.platform==='win32' && sh?['--login','-i']:undefined }); t.show(true); t.sendText(terminalCommand(text)); }
function runIntegrated(text){ return new Promise((resolve)=>{ const args = [...baseArgs(), '-p', '--', fullPrompt(text)]; const child = cp.execFile(devinPath(), args, { cwd: root() || os.homedir(), timeout: cfg().get('timeoutChatMs') || 300000, maxBuffer: 1024*1024*16, windowsHide: true }, (err, stdout, stderr)=>{
    if(err && process.platform === 'win32'){
      runIntegratedViaBash(text, err).then(resolve); return;
    }
    const pieces=[]; if(stdout) pieces.push(stdout.trim()); if(stderr) pieces.push('STDERR:\n'+stderr.trim()); if(err) pieces.push(`Falha ao executar Devin CLI: ${err.message}`); resolve(pieces.join('\n\n') || 'Sem saida do Devin CLI.');
  });
  child.on('error', (err)=>resolve(`Falha ao iniciar Devin CLI: ${err.message}\n\nValide o caminho em devinCliChat.caminhoDevin e execute "Devin Cli Chat: Verificar Devin CLI".`));
}); }
function runIntegratedViaBash(text, firstError){ return new Promise((resolve)=>{ const sh = findGitBash(); if(!sh){ resolve(`Falha ao executar Devin CLI: ${firstError.message}\n\nGit Bash nao foi encontrado. Configure devinCliChat.gitBashPath ou ajuste devinCliChat.caminhoDevin.`); return; } const cmd = `${quote(devinPath())} ${baseArgs().map(quote).join(' ')} -p -- ${quote(fullPrompt(text))}`; cp.exec(cmd, { cwd: root() || os.homedir(), shell: sh, timeout: cfg().get('timeoutChatMs') || 300000, maxBuffer: 1024*1024*16 }, (err, stdout, stderr)=>{ const pieces=[]; if(stdout) pieces.push(stdout.trim()); if(stderr) pieces.push('STDERR:\n'+stderr.trim()); if(err) pieces.push(`Falha ao executar Devin CLI via Git Bash: ${err.message}`); resolve(pieces.join('\n\n') || 'Sem saida do Devin CLI.'); }); }); }
async function setConfig(k,v){ await cfg().update(k,v,vscode.ConfigurationTarget.Workspace); updateStatus(); provider && provider.refreshMeta(); }
function globalAgentsPath(){ const configured = cfg().get('diretorioAgentesGlobal'); if(process.platform === 'win32' && (!configured || configured === '~/.config/devin/agents')){ return path.join(process.env.APPDATA || path.join(os.homedir(),'AppData','Roaming'), 'devin', 'agents'); } return absMaybe(configured); }
function scanAgents(){ const dirs = [absMaybe(cfg().get('diretorioAgentesWorkspace')), globalAgentsPath()]; const out = ['auto']; for(const d of dirs){ try{ if(!d || !fs.existsSync(d)) continue; for(const name of fs.readdirSync(d)){ const p = path.join(d,name,'AGENT.md'); if(fs.existsSync(p)) out.push(name); } }catch{} } return Array.from(new Set(out)); }
function activeContext(){ const ed = vscode.window.activeTextEditor; if(!ed) return 'Nenhum editor ativo.'; const doc = ed.document; const sel = ed.selection && !ed.selection.isEmpty ? doc.getText(ed.selection) : doc.getText(); return [`Arquivo: ${doc.uri.fsPath}`, 'Conteudo:', '```', sel.slice(0,60000), '```'].join('\n'); }
function gitDiff(){ try{ return cp.execFileSync('git',['diff','--no-ext-diff'],{cwd:root()||os.homedir(),encoding:'utf8',maxBuffer:1024*1024*8}); }catch(e){ return `Nao foi possivel obter git diff: ${e.message}`; } }
function updateStatus(){ if(!status){ status = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 90); status.command='devinCliChat.abrirPainel'; status.show(); } const selectedModel = modelForCli() || 'auto'; status.text = `Devin Cli Chat: ${selectedModel} / ${agent()}`; status.tooltip = `Workspace: ${rootName()}\n${modelSourceLabel()}`; }

function shellSplit(input){
  const out=[]; let cur=''; let quoteChar=null; let esc=false;
  for(const ch of String(input||'')){
    if(esc){ cur += ch; esc=false; continue; }
    if(ch === '\\'){ esc=true; continue; }
    if(quoteChar){ if(ch === quoteChar) quoteChar=null; else cur += ch; continue; }
    if(ch === '"' || ch === "'"){ quoteChar=ch; continue; }
    if(/\s/.test(ch)){ if(cur){ out.push(cur); cur=''; } continue; }
    cur += ch;
  }
  if(cur) out.push(cur);
  return out;
}
function discoveryCommands(){
  const custom = shellSplit(cfg().get('comandoDescobertaModelos') || '');
  const commands = [];
  if(custom.length) commands.push({source:`devin ${custom.join(' ')}`, args:custom, trust:'high'});
  commands.push(
    {source:'devin models --format json', args:['models','--format','json'], trust:'high'},
    {source:'devin models --json', args:['models','--json'], trust:'high'},
    {source:'devin models', args:['models'], trust:'high'},
    {source:'devin model list --format json', args:['model','list','--format','json'], trust:'high'},
    {source:'devin model list --json', args:['model','list','--json'], trust:'high'},
    {source:'devin model list', args:['model','list'], trust:'high'},
    {source:'devin --list-models', args:['--list-models'], trust:'high'},
    {source:'devin --models', args:['--models'], trust:'high'},
    {source:'invalid-model probe', args:['--model','__devin_cli_chat_model_probe__','-p','--','ok'], trust:'medium'},
    {source:'devin --help', args:['--help'], trust:'low'}
  );
  return commands;
}
function execDevin(args){
  return new Promise((resolve)=>{
    let done=false;
    const finish=(result)=>{ if(done) return; done=true; resolve(result); };
    const opts = { cwd: root() || os.homedir(), timeout: cfg().get('timeoutDescobertaModelosMs') || 15000, maxBuffer: 1024*1024*4, windowsHide: true };
    const child = cp.execFile(devinPath(), args, opts, (err, stdout, stderr)=>{
      if(err && process.platform === 'win32'){
        execDevinViaBash(args).then(finish); return;
      }
      finish({ err, stdout: stdout || '', stderr: stderr || '' });
    });
    child.on('error', (err)=>{
      if(process.platform === 'win32') execDevinViaBash(args).then(finish);
      else finish({err, stdout:'', stderr:''});
    });
  });
}
function execDevinViaBash(args){
  return new Promise((resolve)=>{
    const sh = findGitBash();
    if(!sh){ resolve({err:new Error('Git Bash nao encontrado'), stdout:'', stderr:''}); return; }
    const cmd = `${quote(devinPath())} ${args.map(quote).join(' ')}`;
    cp.exec(cmd, { cwd: root() || os.homedir(), shell: sh, timeout: cfg().get('timeoutDescobertaModelosMs') || 15000, maxBuffer: 1024*1024*4 }, (err, stdout, stderr)=>resolve({err, stdout:stdout||'', stderr:stderr||''}));
  });
}

function spawnAcpProcess(){
  try{
    return cp.spawn(devinPath(), ['acp'], { cwd: root() || os.homedir(), stdio:['pipe','pipe','pipe'], windowsHide:true });
  }catch(e){
    if(process.platform === 'win32'){
      const sh = findGitBash();
      if(sh) return cp.spawn(sh, ['--login','-lc',`${quote(devinPath())} acp`], { cwd: root() || os.homedir(), stdio:['pipe','pipe','pipe'], windowsHide:true });
    }
    throw e;
  }
}
function modelsFromAcpConfigOptions(configOptions){
  if(!Array.isArray(configOptions)) return [];
  const values=[];
  for(const opt of configOptions){
    const category = String(opt && opt.category || '').toLowerCase();
    const id = String(opt && opt.id || '').toLowerCase();
    const name = String(opt && opt.name || '').toLowerCase();
    if(category !== 'model' && id !== 'model' && !name.includes('model')) continue;
    const options = Array.isArray(opt.options) ? opt.options : [];
    for(const option of options){
      if(option && typeof option === 'object') values.push(option.value || option.id || option.name);
      else values.push(option);
    }
    if(opt.currentValue) values.push(opt.currentValue);
  }
  return uniqModels(values);
}
function discoverModelsViaAcp(){
  return new Promise((resolve)=>{
    let child;
    try{ child = spawnAcpProcess(); }catch(e){ resolve({models:[], error:e}); return; }
    let done=false;
    let buffer='';
    let stderr='';
    let sessionId;
    const timeoutMs = cfg().get('timeoutDescobertaModelosMs') || 15000;
    const timer = setTimeout(()=>finish([], new Error('Timeout ACP')), timeoutMs);
    function finish(models, err){
      if(done) return;
      done=true;
      clearTimeout(timer);
      try{
        if(sessionId) child.stdin.write(JSON.stringify({jsonrpc:'2.0',id:99,method:'session/close',params:{sessionId}})+'\n');
      }catch{}
      setTimeout(()=>{ try{ child.kill(); }catch{} }, 150);
      resolve({models, error:err, stderr});
    }
    function send(id, method, params){
      try{ child.stdin.write(JSON.stringify({jsonrpc:'2.0', id, method, params})+'\n'); }
      catch(e){ finish([], e); }
    }
    child.on('error', err=>finish([], err));
    child.stderr.on('data', d=>{ stderr += String(d); });
    child.stdout.on('data', data=>{
      buffer += String(data);
      let idx;
      while((idx = buffer.indexOf('\n')) >= 0){
        const line = buffer.slice(0, idx).trim();
        buffer = buffer.slice(idx+1);
        if(!line) continue;
        let msg;
        try{ msg = JSON.parse(line); }catch{ continue; }
        if(msg.id === 1 && msg.result){
          send(2, 'session/new', { cwd: root() || os.homedir(), mcpServers: [] });
        } else if(msg.id === 2){
          if(msg.error){ finish([], new Error(msg.error.message || 'Erro ACP em session/new')); return; }
          sessionId = msg.result && msg.result.sessionId;
          const models = modelsFromAcpConfigOptions(msg.result && msg.result.configOptions);
          if(models.length > 1) finish(models, undefined);
          else finish([], new Error('ACP nao retornou configOptions de modelo'));
        } else if(msg.id && msg.method){
          try{ child.stdin.write(JSON.stringify({jsonrpc:'2.0', id:msg.id, error:{code:-32601, message:'Metodo nao suportado pela descoberta de modelos'}})+'\n'); }catch{}
        }
      }
    });
    child.on('exit', code=>{ if(!done) finish([], new Error(`ACP encerrou com codigo ${code}`)); });
    send(1, 'initialize', {
      protocolVersion: 1,
      clientInfo: { name: 'Devin Cli Chat', version: '0.10.0' },
      clientCapabilities: { fs: { readTextFile:false, writeTextFile:false }, terminal:false }
    });
  });
}

function uniqModels(items){
  const out=[]; const seen=new Set();
  for(const raw of items){
    const value = normalizeCandidate(raw);
    if(!value) continue;
    const key = value.toLowerCase();
    if(!seen.has(key)){ seen.add(key); out.push(value); }
  }
  if(!out.includes('auto')) out.unshift('auto');
  return out;
}
function normalizeCandidate(raw){
  let s = String(raw || '').trim();
  s = s.replace(/^[`'"\[\](),:;]+|[`'"\[\](),:;]+$/g, '').trim();
  if(!s) return '';
  if(s === '<MODEL>' || s === '[MODEL]' || s === 'MODEL') return '';
  if(/[\\/]/.test(s) || s.includes('@')) return '';
  if(!/^[A-Za-z0-9][A-Za-z0-9._-]{1,80}$/.test(s)) return '';
  const lower = s.toLowerCase();
  const stop = new Set(['devin','model','models','available','allowed','valid','invalid','error','usage','options','prompt','print','response','exit','format','json','list','set','session','command','flag','slash','name','current','configured','default','padrao','the','and','or','for','with','true','false','normal','dangerous','bypass','accept-edits','plan','ask','workspace','help','version','auth','login','logout','status','mcp','rules','skills','paths','show','remove','add','update','setup','uninstall','context','compact','theme','mode']);
  if(stop.has(lower)) return '';
  if(KNOWN_MODEL_HINTS.has(lower)) return lower;
  if(/^(claude|gpt|codex|gemini|swe|kimi|glm|llama|mistral|deepseek|qwen|o[0-9]|nova|command|granite|mixtral)[A-Za-z0-9._-]*/i.test(s)) return s;
  if(/[.-]/.test(s) && /\d/.test(s)) return s;
  return '';
}
function collectStringsFromJson(obj, acc){
  if(Array.isArray(obj)){ for(const x of obj) collectStringsFromJson(x, acc); return; }
  if(obj && typeof obj === 'object'){
    for(const [k,v] of Object.entries(obj)){
      const key = k.toLowerCase();
      if(typeof v === 'string' && /(model|name|id|value)/.test(key)) acc.push(v);
      else collectStringsFromJson(v, acc);
    }
    return;
  }
  if(typeof obj === 'string') acc.push(obj);
}
function parseJsonModels(text){
  const clean = String(text||'').trim();
  if(!clean) return [];
  const chunks = [clean];
  const firstBrace = clean.search(/[\[{]/);
  if(firstBrace > 0) chunks.push(clean.slice(firstBrace));
  for(const c of chunks){
    try{
      const parsed = JSON.parse(c);
      const acc=[]; collectStringsFromJson(parsed, acc);
      const models = uniqModels(acc);
      if(models.length > 1) return models;
    }catch{}
  }
  return [];
}
function parseTextModels(text, trust){
  const all = String(text || '');
  const json = parseJsonModels(all);
  if(json.length > 1) return json;
  const candidates=[];
  const lines = all.split(/\r?\n/);
  for(const line of lines){
    const lower = line.toLowerCase();
    const modelishLine = /(model|models|allowed|available|valid|whitelist|allowlist|config name|provider|claude|gpt|codex|gemini|swe|opus|sonnet|kimi|glm|llama|mistral|deepseek|qwen)/.test(lower);
    if(trust === 'low' && !modelishLine) continue;
    const backticks = [...line.matchAll(/`([^`]+)`/g)].map(m=>m[1]);
    candidates.push(...backticks);
    const afterColon = line.includes(':') ? line.slice(line.indexOf(':')+1) : line;
    candidates.push(...afterColon.split(/[\s,|]+/g));
  }
  return uniqModels(candidates);
}
function loadModelCache(){
  if(!extensionContext) return;
  const cached = extensionContext.globalState.get(CACHE_KEY);
  if(cached && Array.isArray(cached.models)){
    const ttl = cfg().get('cacheModelosMs') || 1800000;
    const fresh = Date.now() - (cached.time || 0) < ttl;
    modelDiscovery = {
      status: fresh ? 'ok' : 'stale',
      detail: fresh ? 'Cache de modelos carregado.' : 'Cache de modelos expirado; aguardando nova descoberta.',
      source: cached.source || 'cache',
      models: cached.models
    };
  }
}
async function saveModelCache(models, source){
  if(!extensionContext) return;
  await extensionContext.globalState.update(CACHE_KEY, { time: Date.now(), source, models });
}
async function discoverModels(force){
  if(!cfg().get('descobrirModelosAutomaticamente', true)){
    modelDiscovery = {status:'off', detail:'Descoberta automatica desabilitada.', source:'configuracao', models:[]};
    provider && provider.refreshMeta(); updateStatus(); return modelDiscovery;
  }
  if(modelDiscoveryPromise) return modelDiscoveryPromise;
  const cached = extensionContext && extensionContext.globalState.get(CACHE_KEY);
  const ttl = cfg().get('cacheModelosMs') || 1800000;
  if(!force && cached && Array.isArray(cached.models) && Date.now() - (cached.time || 0) < ttl){
    modelDiscovery = {status:'ok', detail:'Lista carregada do cache local.', source:cached.source || 'cache', models:cached.models};
    provider && provider.refreshMeta(); updateStatus(); return modelDiscovery;
  }
  modelDiscovery = {status:'loading', detail:'Consultando o Devin CLI local...', source:'auto', models:modelDiscovery.models || []};
  provider && provider.refreshMeta(); updateStatus();
  modelDiscoveryPromise = (async()=>{
    const errors=[];
    const acp = await discoverModelsViaAcp();
    if(acp.models && acp.models.filter(m => m !== 'auto').length){
      const list = uniqModels(acp.models);
      modelDiscovery = {status:'ok', detail:`${list.length-1} modelo(s) detectado(s).`, source:'devin acp configOptions', models:list};
      await saveModelCache(list, 'devin acp configOptions');
      provider && provider.refreshMeta(); updateStatus();
      return modelDiscovery;
    }
    if(acp.error) errors.push(`devin acp: ${acp.error.message}`);
    for(const cmd of discoveryCommands()){
      const res = await execDevin(cmd.args);
      const text = [res.stdout, res.stderr].filter(Boolean).join('\n');
      const parsed = parseTextModels(text, cmd.trust);
      const useful = parsed.filter(m => m !== 'auto');
      if(useful.length){
        const list = uniqModels(parsed);
        modelDiscovery = {status:'ok', detail:`${list.length-1} modelo(s) detectado(s).`, source:cmd.source, models:list};
        await saveModelCache(list, cmd.source);
        provider && provider.refreshMeta(); updateStatus();
        return modelDiscovery;
      }
      if(res.err) errors.push(`${cmd.source}: ${res.err.message}`);
    }
    modelDiscovery = {status:'error', detail:`Nao foi possivel detectar modelos automaticamente. ${errors.slice(0,2).join(' | ')}`, source:'fallback', models:[]};
    provider && provider.refreshMeta(); updateStatus();
    return modelDiscovery;
  })();
  try { return await modelDiscoveryPromise; }
  finally { modelDiscoveryPromise = undefined; }
}
async function ensureModels(){
  if(!cfg().get('descobrirModelosAutomaticamente', true)) return;
  if(modelDiscovery.status === 'idle' || modelDiscovery.status === 'stale' || !modelDiscovery.models.length){
    discoverModels(false);
  }
}
async function pickManualModel(){ const value = await vscode.window.showInputBox({ title:'Devin Cli Chat: Definir modelo manual', prompt:'Informe o nome exato aceito pelo Devin CLI ou pela allowlist enterprise.', value: modelForCli() || '' }); if(value && value.trim()) await setConfig('modeloAtual', value.trim()); }
async function pickModel(){
  await discoverModels(false);
  const items = models().map(m => ({ label:m, description:m==='auto'?'nao envia --model; usa padrao/allowlist do Devin CLI':'' }));
  items.push({ label:'$(sync) Atualizar modelos do Devin CLI', description:'executa a descoberta automatica novamente' });
  items.push({ label:'$(edit) Informar modelo manual...', description:'usar um nome que nao aparece na lista' });
  const pick = await vscode.window.showQuickPick(items,{placeHolder:`Selecione o modelo Devin (${modelSourceLabel()})`});
  if(!pick) return;
  if(pick.label.includes('Atualizar modelos')){ await discoverModels(true); return pickModel(); }
  if(pick.label.includes('Informar modelo manual')) return pickManualModel();
  await setConfig('modeloAtual', pick.label);
}

class ChatViewProvider{
  constructor(context){ this.context=context; this.view=undefined; }
  resolveWebviewView(view){ this.view=view; view.webview.options={ enableScripts:true, localResourceRoots:[this.context.extensionUri] }; view.webview.html=this.html(view.webview); view.webview.onDidReceiveMessage(async msg=>{ if(msg.type==='ready'){ this.refreshMeta(); ensureModels(); } if(msg.type==='send') await this.send(msg.text||''); if(msg.type==='terminal') openTerminal(msg.text||''); if(msg.type==='setModel') await setConfig('modeloAtual', msg.value); if(msg.type==='manualModel') await pickManualModel(); if(msg.type==='refreshModels') await discoverModels(true); if(msg.type==='setAgent') await setConfig('agenteAtual', msg.value); if(msg.type==='review') await this.send('Revise o git diff atual com foco em bugs, seguranca, testes, impacto produtivo e rollback.\n\n```diff\n'+gitDiff()+'\n```'); if(msg.type==='selection') await this.send('Analise o contexto do editor atual.\n\n'+activeContext()); }); }
  post(m){ try{ this.view && this.view.webview.postMessage(m); }catch{} }
  refreshMeta(){ this.post({type:'meta', models:models(), model:model(), modelStatus:modelSourceLabel(), modelDiscoveryStatus:modelDiscovery.status, agents:scanAgents(), agent:agent(), workspace:rootName(), mode:cfg().get('modoExecucaoChat')||'resposta-integrada'}); }
  async send(text){ const prompt = String(text||'').trim(); if(!prompt) return; this.post({type:'message', role:'user', text:prompt}); this.post({type:'busy', value:true}); const mode = cfg().get('modoExecucaoChat') || 'resposta-integrada'; if(mode === 'terminal'){ openTerminal(prompt); this.post({type:'message', role:'assistant', text:'Sessao aberta no terminal integrado, ja posicionada na pasta aberta no VS Code.'}); this.post({type:'busy', value:false}); return; } const answer = await runIntegrated(prompt); this.post({type:'message', role:'assistant', text:answer}); this.post({type:'busy', value:false}); }
  html(webview){ const nonce=Date.now().toString(36); return `<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src ${webview.cspSource} data:; style-src 'unsafe-inline' ${webview.cspSource}; script-src 'nonce-${nonce}';"><meta name="viewport" content="width=device-width, initial-scale=1.0"><style>
:root{
  --bg:var(--vscode-sideBar-background);
  --fg:var(--vscode-foreground);
  --muted:var(--vscode-descriptionForeground);
  --border:var(--vscode-panel-border);
  --input:var(--vscode-input-background);
  --input-fg:var(--vscode-input-foreground);
  --focus:var(--vscode-focusBorder);
  --accent:var(--vscode-button-background);
  --accent-fg:var(--vscode-button-foreground);
  --secondary:var(--vscode-button-secondaryBackground);
  --secondary-fg:var(--vscode-button-secondaryForeground);
  --editor:var(--vscode-editor-background);
  --hover:var(--vscode-list-hoverBackground);
  --active:var(--vscode-list-activeSelectionBackground);
  --active-fg:var(--vscode-list-activeSelectionForeground);
  --code:var(--vscode-textCodeBlock-background);
}
*{box-sizing:border-box}
html,body{width:100%;height:100%;padding:0;margin:0;overflow:hidden;background:var(--bg);color:var(--fg);font-family:var(--vscode-font-family);font-size:var(--vscode-font-size)}
button,select,textarea{font:inherit;color:inherit}
.app{height:100vh;display:flex;flex-direction:column;background:var(--bg)}
.header{height:38px;min-height:38px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:8px;padding:0 10px;background:var(--bg)}
.product{display:flex;align-items:center;gap:8px;min-width:0;font-weight:600;font-size:12px;letter-spacing:.01em;text-transform:uppercase;color:var(--muted)}
.logo{width:18px;height:18px;border-radius:999px;background:var(--accent);color:var(--accent-fg);display:grid;place-items:center;font-size:10px;font-weight:700;flex:0 0 auto}.headerSpacer{flex:1}.iconBtn{border:0;background:transparent;color:var(--muted);width:26px;height:26px;border-radius:6px;display:grid;place-items:center;cursor:pointer}.iconBtn:hover{background:var(--hover);color:var(--fg)}.iconBtn.primary{background:var(--accent);color:var(--accent-fg)}
.thread{flex:1;overflow:auto;padding:14px 14px 10px 14px;scrollbar-gutter:stable;display:flex;flex-direction:column;gap:16px;background:var(--editor)}
.contextStrip{display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin:0 0 2px 0;color:var(--muted);font-size:11px}.ctxPill{border:1px solid var(--border);background:var(--bg);border-radius:999px;padding:3px 8px;max-width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ctxPill strong{font-weight:600;color:var(--fg)}
.welcome{margin:auto 0;display:grid;gap:12px;padding:8px 0 18px 0}.welcomeRow{display:flex;align-items:center;gap:10px}.welcomeTitle{font-size:18px;line-height:1.25;font-weight:600}.welcomeText{color:var(--muted);line-height:1.45;max-width:560px}.starterGrid{display:grid;gap:8px;grid-template-columns:1fr}.starter{border:1px solid var(--border);background:var(--bg);color:var(--fg);border-radius:10px;text-align:left;padding:10px;cursor:pointer}.starter:hover{background:var(--hover);border-color:var(--focus)}.starter b{display:block;margin-bottom:3px}.starter span{display:block;color:var(--muted);font-size:11px;line-height:1.35}
.msgRow{display:flex;gap:10px;align-items:flex-start}.msgRow.user{justify-content:flex-end}.avatar{width:24px;height:24px;border-radius:999px;display:grid;place-items:center;background:var(--accent);color:var(--accent-fg);font-size:11px;font-weight:700;flex:0 0 auto;margin-top:2px}.msg{max-width:92%;line-height:1.48;white-space:pre-wrap;overflow-wrap:anywhere}.msg.assistant{width:100%;padding:0 2px}.msg.user{background:var(--input);border:1px solid var(--border);border-radius:16px;padding:9px 12px;max-width:82%;box-shadow:0 1px 0 rgba(0,0,0,.08)}.msgMeta{font-size:11px;color:var(--muted);margin-bottom:4px}.msg pre{background:var(--code);border:1px solid var(--border);border-radius:8px;padding:10px;overflow:auto;white-space:pre-wrap}.msg code{font-family:var(--vscode-editor-font-family);font-size:var(--vscode-editor-font-size)}
.composerWrap{border-top:1px solid var(--border);background:var(--bg);padding:10px 10px 9px 10px}.composer{border:1px solid var(--border);background:var(--input);border-radius:12px;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 0 0 1px rgba(0,0,0,.02)}.composer:focus-within{border-color:var(--focus)}.inputLine{display:flex;align-items:flex-start;gap:8px;padding:8px 8px 0 8px}.mention{height:24px;border-radius:6px;background:var(--active);color:var(--active-fg);padding:3px 6px;font-size:12px;white-space:nowrap;flex:0 0 auto}textarea{width:100%;min-height:62px;max-height:200px;resize:none;background:transparent;color:var(--input-fg);border:0;outline:0;padding:3px 0 8px 0;line-height:1.4}.composerBar{display:flex;align-items:center;gap:6px;padding:6px 8px 8px 8px;border-top:1px solid color-mix(in srgb, var(--border) 70%, transparent)}.chip,.selectChip{height:26px;border:1px solid var(--border);background:var(--bg);color:var(--fg);border-radius:999px;padding:0 8px;display:flex;align-items:center;gap:5px;font-size:11px;white-space:nowrap;max-width:100%;min-width:0}.selectChip{appearance:none;cursor:pointer;padding-right:20px;background-image:linear-gradient(45deg, transparent 50%, var(--muted) 50%),linear-gradient(135deg, var(--muted) 50%, transparent 50%);background-position:calc(100% - 10px) 10px, calc(100% - 6px) 10px;background-size:4px 4px,4px 4px;background-repeat:no-repeat}.chip.small{padding:0 7px;color:var(--muted)}.barSpacer{flex:1;min-width:8px}.sendBtn{width:28px;height:28px;border-radius:8px;border:0;background:var(--accent);color:var(--accent-fg);cursor:pointer;display:grid;place-items:center;font-weight:700}.sendBtn:disabled{opacity:.5;cursor:not-allowed}.statusLine{display:flex;align-items:center;gap:8px;color:var(--muted);font-size:10px;margin-top:6px;padding:0 2px}.statusLine span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.busyDot{display:none;width:7px;height:7px;border-radius:999px;background:var(--accent);animation:pulse 1s infinite}.is-busy .busyDot{display:block}.is-busy .sendBtn{opacity:.55;pointer-events:none}@keyframes pulse{0%,100%{opacity:.35}50%{opacity:1}}
@media (max-width:380px){.chip.local,.chip.approvals{display:none}.msg{max-width:100%}.msg.user{max-width:88%}.composerBar{gap:4px}.selectChip{max-width:112px}.productText{display:none}}
</style></head><body><div class="app"><header class="header"><div class="product"><div class="logo">D</div><span class="productText">Devin Cli Chat</span></div><div class="headerSpacer"></div><button class="iconBtn" id="newChat" title="Nova conversa">+</button><button class="iconBtn" id="refreshModelsTop" title="Atualizar modelos">R</button><button class="iconBtn" id="terminalTop" title="Abrir sessao no terminal">⌁</button></header><main class="thread" id="thread"><div class="contextStrip" id="contextStrip"><span class="ctxPill">Workspace: <strong id="ctxWorkspace">carregando</strong></span><span class="ctxPill">Modelo: <strong id="ctxModel">auto</strong></span><span class="ctxPill">Agente: <strong id="ctxAgent">auto</strong></span></div><section class="welcome" id="welcome"><div class="welcomeRow"><div class="avatar">D</div><div><div class="welcomeTitle">Como posso ajudar neste workspace?</div><div class="welcomeText">Use o Devin CLI com contexto da pasta aberta no VS Code. Selecione modelo e agente no composer, como em uma tela de chat agentic.</div></div></div><div class="starterGrid"><button class="starter" data-prompt="Revise o git diff atual com foco em bugs, seguranca, testes, impacto produtivo e rollback."><b>Revisar diff</b><span>Analisa alteracoes locais com foco produtivo.</span></button><button class="starter" data-prompt="Planeje a implementacao da proxima tarefa em etapas pequenas, com riscos, testes e estrategia de rollback."><b>Planejar tarefa</b><span>Gera um plano objetivo antes de alterar codigo.</span></button><button class="starter" data-prompt="Analise o contexto do editor atual e explique os pontos mais importantes."><b>Explicar contexto</b><span>Usa arquivo aberto ou selecao atual.</span></button></div></section></main><footer class="composerWrap"><div class="composer"><div class="inputLine"><span class="mention">@devin</span><textarea id="prompt" placeholder="Use Devin CLI com o workspace atual, modelo e agente selecionados..."></textarea></div><div class="composerBar"><button class="iconBtn" id="selection" title="Adicionar contexto do editor">＋</button><span class="chip local" title="Execucao local no workspace aberto">▣ Local</span><span class="chip approvals" title="Aprovacoes padrao do Devin CLI">◇ Aprovacoes Padrao</span><select class="selectChip" id="agent" title="Agente Devin"></select><select class="selectChip" id="model" title="Modelo Devin"></select><button class="iconBtn" id="manualModel" title="Informar modelo manual">⚙</button><div class="barSpacer"></div><button class="sendBtn" id="send" title="Enviar">↑</button></div></div><div class="statusLine"><span class="busyDot"></span><span id="mode">integrado</span><span>·</span><span id="modelStatus">detectando modelos...</span></div></footer></div><script nonce="${nonce}">const vscode=acquireVsCodeApi();const $=id=>document.getElementById(id);const state={hasMessages:false,busy:false};function opt(sel,items,val){const keep=sel.value;sel.innerHTML='';(items||[]).forEach(x=>{const o=document.createElement('option');o.value=x;o.textContent=x==='auto'?'Auto':x;if(x===val || (!val && x===keep))o.selected=true;sel.appendChild(o)})}function safeText(s){return String(s||'')}function hideWelcome(){state.hasMessages=true;$('welcome').style.display='none'}function clearThread(){state.hasMessages=false;Array.from($('thread').querySelectorAll('.msgRow')).forEach(n=>n.remove());$('welcome').style.display='grid';$('thread').scrollTop=0}function content(el,text){const value=safeText(text);const fence=String.fromCharCode(96,96,96);const parts=value.split(fence);if(parts.length===1){el.textContent=value;return}parts.forEach((part,i)=>{if(i%2===0){const span=document.createElement('span');span.textContent=part;el.appendChild(span)}else{const pre=document.createElement('pre');const code=document.createElement('code');code.textContent=part.replace(/^\w+\n/,'');pre.appendChild(code);el.appendChild(pre)}})}function add(role,text){hideWelcome();const row=document.createElement('div');row.className='msgRow '+(role==='user'?'user':'assistant');if(role!=='user'){const av=document.createElement('div');av.className='avatar';av.textContent='D';row.appendChild(av)}const msg=document.createElement('div');msg.className='msg '+(role==='user'?'user':'assistant');if(role!=='user'){const meta=document.createElement('div');meta.className='msgMeta';meta.textContent='Devin Cli Chat';msg.appendChild(meta)}content(msg,text);row.appendChild(msg);$('thread').appendChild(row);$('thread').scrollTop=$('thread').scrollHeight}function sendText(t){const text=safeText(t).trim();if(!text||state.busy)return;vscode.postMessage({type:'send',text});$('prompt').value=''}window.addEventListener('message',e=>{const m=e.data||{};if(m.type==='meta'){opt($('model'),m.models,m.model);opt($('agent'),m.agents,m.agent);$('ctxWorkspace').textContent=m.workspace||'sem workspace';$('ctxModel').textContent=m.model||'auto';$('ctxAgent').textContent=m.agent||'auto';$('mode').textContent=m.mode==='terminal'?'terminal':'integrado';$('modelStatus').textContent=m.modelStatus||'';$('refreshModelsTop').textContent=m.modelDiscoveryStatus==='loading'?'…':'R'}if(m.type==='message')add(m.role,m.text);if(m.type==='busy'){state.busy=!!m.value;document.body.classList.toggle('is-busy',state.busy)}});$('send').onclick=()=>sendText($('prompt').value);$('prompt').addEventListener('keydown',e=>{if(e.key==='Enter'&&(e.metaKey||e.ctrlKey)){e.preventDefault();$('send').click()}});$('model').onchange=e=>vscode.postMessage({type:'setModel',value:e.target.value});$('agent').onchange=e=>vscode.postMessage({type:'setAgent',value:e.target.value});$('manualModel').onclick=()=>vscode.postMessage({type:'manualModel'});$('refreshModelsTop').onclick=()=>vscode.postMessage({type:'refreshModels'});$('terminalTop').onclick=()=>vscode.postMessage({type:'terminal'});$('newChat').onclick=clearThread;$('selection').onclick=()=>vscode.postMessage({type:'selection'});document.querySelectorAll('.starter').forEach(b=>b.addEventListener('click',()=>{const p=b.getAttribute('data-prompt')||'';if(p.startsWith('Revise o git diff'))vscode.postMessage({type:'review'});else if(p.startsWith('Analise o contexto'))vscode.postMessage({type:'selection'});else sendText(p)}));vscode.postMessage({type:'ready'});</script></body></html>`; }
}
async function activate(context){
  extensionContext = context;
  loadModelCache();
  provider=new ChatViewProvider(context);
  context.subscriptions.push(vscode.window.registerWebviewViewProvider('devinCliChat.chatView',provider,{webviewOptions:{retainContextWhenHidden:true}}));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.abrirPainel',async()=>vscode.commands.executeCommand('workbench.view.extension.devinCliChat')));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.novaSessao',()=>openTerminal('')));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.revisarDiff',async()=>{await vscode.commands.executeCommand('workbench.view.extension.devinCliChat'); provider && provider.send('Revise o git diff atual com foco em bugs, seguranca, testes, impacto produtivo e rollback.\n\n```diff\n'+gitDiff()+'\n```');}));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.enviarSelecao',async()=>{await vscode.commands.executeCommand('workbench.view.extension.devinCliChat'); provider && provider.send('Analise o contexto do editor atual.\n\n'+activeContext());}));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.selecionarModelo',pickModel));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.definirModeloManual',pickManualModel));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.atualizarModelos',async()=>{ await discoverModels(true); vscode.window.showInformationMessage(modelDiscovery.models.length ? `Modelos atualizados: ${modelDiscovery.models.length-1} detectado(s).` : `Nao foi possivel detectar modelos automaticamente.`); }));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.selecionarAgente',async()=>{const pick=await vscode.window.showQuickPick(scanAgents(),{placeHolder:'Selecione o agente Devin'}); if(pick) await setConfig('agenteAtual',pick);}));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.verificarCli',async()=>{cp.execFile(devinPath(),['--version'],{cwd:root()||os.homedir(),windowsHide:true},(err,stdout,stderr)=>{vscode.window.showInformationMessage(err?`Falha ao verificar Devin CLI: ${err.message}`:`Devin CLI encontrado: ${(stdout||stderr||'ok').trim()}`); if(!err) discoverModels(true);});}));
  updateStatus();
  ensureModels();
  context.subscriptions.push(vscode.workspace.onDidChangeConfiguration(e=>{if(e.affectsConfiguration(EXT)){loadModelCache(); updateStatus(); provider && provider.refreshMeta(); ensureModels();}}));
}
function deactivate(){}
module.exports={activate,deactivate};
