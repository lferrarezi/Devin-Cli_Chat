
## 0.13.0

- Mantido layout e ícone da versão anterior.
- Corrigido travamento na detecção de modelos.
- `devin acp` deixou de ser executado por padrão.
- O seletor usa cache, configuração local, `auto` e modelos manuais.
- Consulta externa ao CLI agora é opt-in por configuração explícita.

# Changelog

## 0.12.0

- Mantido layout e icone da versao 0.11.0, sem alteracoes visuais.
- Descoberta de modelos ajustada para nao travar o seletor nem a tela.
- Reducao do timeout padrao por tentativa para 3 segundos.
- Adicionado orcamento total de descoberta por ciclo.
- Encerramento forcado de subprocessos `devin acp`/fallbacks em caso de timeout.
- Removidos fallbacks legados por padrao; podem ser reativados em `devinCliChat.tentarComandosLegadosDescobertaModelos`.
- Seletor de modelos abre imediatamente com cache, config local ou `auto`, mesmo enquanto a descoberta roda em background.

## 0.11.0

- Icone da extensao atualizado a partir da imagem fornecida.
- `package.json` agora aponta `icon` para `media/devin-cli-chat.png`.
- Activity Bar passa a usar `media/devin-cli-chat-activity.svg`, derivado do mesmo conceito visual.
- Pacote VSIX atualizado para exibir a identidade visual `Devin Cli Chat` na lista de extensoes.


## 0.10.0

- Redesenho completo da tela propria de chat.
- Composer inferior com seletores de modelo e agente, inspirado no fluxo de extensoes agentic modernas.
- Remocao de qualquer dependencia da tela nativa Chat do VS Code.
- Area de conversa mais limpa, sem cards grandes para cada resposta.
- Acoes rapidas para revisar diff, planejar tarefa, explicar contexto e abrir sessao terminal.
- Instrucoes de instalacao limpa para remover participantes legados `iuDevaChat`.

## 0.9.0

- Descoberta automatica de modelos via Devin CLI, com uso de ACP quando disponivel.
