# Devin Cli Chat

Extensao VS Code para usar o Devin CLI em uma tela propria de chat, com execucao ancorada na pasta aberta no VS Code.

## Experiencia 0.12.0

- Tela propria na Activity Bar, sem depender da tela nativa Chat do VS Code.
- Layout redesenhado no padrao de paineis modernos de agentes de codigo: conversa central, composer inferior, seletores no composer e acoes rapidas.
- Seletor de modelo no composer, preenchido automaticamente a partir do Devin CLI local quando possivel.
- Seletor de agente no composer, lendo `.devin/agents/<agente>/AGENT.md` e agentes globais.
- Execucao local no workspace aberto.
- Suporte a Windows corporativo sem PowerShell, usando Git Bash quando necessario.

## Identidade visual

- Icone da extensao atualizado a partir da imagem fornecida.
- A lista de extensoes usa `media/devin-cli-chat.png`.
- A Activity Bar usa `media/devin-cli-chat-activity.svg`, versao vetorial derivada do mesmo desenho para melhor compatibilidade com o VS Code.

## Uso

1. Instale o VSIX.
2. Abra uma pasta no VS Code.
3. Abra a Activity Bar `Devin Cli Chat`.
4. Selecione modelo e agente no composer inferior.
5. Envie o prompt.

## Instalacao limpa recomendada

Se voce instalou as versoes antigas `iuDevaChat`, remova-as para evitar que o participante antigo continue aparecendo na tela Chat nativa do VS Code.

```bash
code --uninstall-extension luiz-ferrarezi.iudevachat
code --uninstall-extension itau-unibanco.iudevachat
code --uninstall-extension luiz-alberto-abarca-ferrarezi.iudevachat
code --install-extension devin-cli-chat-0.12.0.vsix --force
```

## Configuracoes principais

```json
{
  "devinCliChat.caminhoDevin": "devin",
  "devinCliChat.modeloAtual": "auto",
  "devinCliChat.agenteAtual": "auto",
  "devinCliChat.modoExecucaoChat": "resposta-integrada",
  "devinCliChat.descobrirModelosAutomaticamente": true,
  "devinCliChat.usarGitBashNoWindows": true,
  "devinCliChat.timeoutDescobertaModelosMs": 3000,
  "devinCliChat.timeoutTotalDescobertaModelosMs": 7000
}
```

## Descoberta automatica de modelos

A extensao tenta consultar o Devin CLI local para montar a lista real de modelos disponiveis, mas agora usa timeout curto, orcamento total e encerramento forcado de subprocessos. Quando a descoberta falha, ela mantem o seletor responsivo, usa `auto` e a configuracao manual `devinCliChat.modelosDisponiveis` como fallback.

## Desenvolvedor

Luiz Alberto Abarca Ferrarezi


## 0.13.0

Correção de estabilidade: a seleção de modelos não inicia mais `devin acp` por padrão. O seletor usa `auto`, cache, configuração local e `devinCliChat.modelosDisponiveis`. A consulta externa ao CLI ficou opt-in via `devinCliChat.comandoDescobertaModelos` ou `devinCliChat.usarAcpParaDescobertaModelos`. Layout e ícone foram preservados.
