'use strict';
const vscode = require('vscode');
const fs = require('fs');
const path = require('path');
const os = require('os');
const cp = require('child_process');

const EXT = 'devinCliChat';
const CACHE_KEY = 'devinCliChat.modelosDetectados.v7';
const FALLBACK_MODELS = ['auto'];
const KNOWN_MODEL_HINTS = new Set(['opus','sonnet','swe','codex','gemini','auto','haiku','gpt','claude','o3','o4','o5']);

let provider;
let status;
let extensionContext;
let modelDiscovery = {
  status: 'ok',
  detail: 'Modelos: auto. Leitura local de config.json e caches do Devin sera iniciada em segundo plano.',
  source: 'inicial',
  models: ['auto']
};
let modelDiscoveryPromise;
let modelDiscoveryTimer;
let cachedAgents = ['auto'];
let agentScanScheduled = false;
let cachedCurrentModel;

function cfg(){ return vscode.workspace.getConfiguration(EXT); }
function root(){ return vscode.workspace.workspaceFolders && vscode.workspace.workspaceFolders[0] ? vscode.workspace.workspaceFolders[0].uri.fsPath : undefined; }
function rootName(){ return vscode.workspace.workspaceFolders && vscode.workspace.workspaceFolders[0] ? vscode.workspace.workspaceFolders[0].name : 'sem pasta aberta'; }
function home(p){ if(!p) return p; const s=String(p); return s === '~' ? os.homedir() : (s.startsWith('~/') || s.startsWith('~\\')) ? path.join(os.homedir(), s.slice(2)) : s; }
function absMaybe(p){ const v = home(p); if(!v) return v; return path.isAbsolute(v) ? v : path.join(root() || os.homedir(), v); }
function exists(p){ try { return !!p && fs.existsSync(p); } catch { return false; } }
function htmlEscape(value){ return String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
function quote(s){ return `'${String(s).replace(/'/g, `'\\''`)}'`; }
function normalizeModel(m){ const value = String(m || '').trim(); if(!value || value === 'default' || value === 'padrao') return 'auto'; return value; }
function settingConfigured(key){
  try{
    const inspected = cfg().inspect(key);
    return !!(inspected && (inspected.globalValue !== undefined || inspected.workspaceValue !== undefined || inspected.workspaceFolderValue !== undefined));
  }catch{ return false; }
}
function model(){
  const configured = normalizeModel(cfg().get('modeloAtual') || 'auto');
  if(settingConfigured('modeloAtual') && configured !== 'auto') return configured;
  const cached = normalizeModel(cachedCurrentModel || 'auto');
  if(cached && cached !== 'auto') return cached;
  return normalizeModel(configured || 'auto');
}
function modelForCli(){
  if(!settingConfigured('modeloAtual')) return undefined;
  const configured = normalizeModel(cfg().get('modeloAtual') || 'auto');
  return configured === 'auto' ? undefined : configured;
}
function agent(){ return cfg().get('agenteAtual') || 'auto'; }
function devinPath(){ return cfg().get('caminhoDevin') || 'devin'; }
function findGitBash(){
  const c = [
    home(cfg().get('gitBashPath')),
    process.env.GIT_BASH_PATH,
    'C:\\Program Files\\Git\\bin\\bash.exe',
    'C:\\Program Files\\Git\\usr\\bin\\bash.exe',
    'C:\\Program Files (x86)\\Git\\bin\\bash.exe',
    path.join(os.homedir(),'AppData','Local','Programs','Git','bin','bash.exe')
  ].filter(Boolean);
  return c.find(exists);
}
function terminalShell(){ if(process.platform === 'win32' && cfg().get('usarGitBashNoWindows', true)){ return findGitBash(); } return process.env.SHELL || undefined; }
function manualModels(){ const configured = cfg().get('modelosDisponiveis'); return Array.isArray(configured) ? configured.map(String).map(s=>s.trim()).filter(Boolean) : []; }
function models(){
  const detected = Array.isArray(modelDiscovery.models) ? modelDiscovery.models : [];
  let list = detected.length ? detected : manualModels();
  if(!list.length) list = FALLBACK_MODELS;
  const out = ['auto', ...list];
  const current = model();
  if(current && !out.includes(current)) out.unshift(current);
  return Array.from(new Set(out.filter(Boolean)));
}
function modelSourceLabel(){
  if(modelDiscovery.status === 'loading') return modelDiscovery.detail || 'Carregando cache local de modelos...';
  if(modelDiscovery.models && modelDiscovery.models.length) return `modelos detectados via ${modelDiscovery.source}`;
  if(manualModels().length) return 'usando fallback manual em devinCliChat.modelosDisponiveis';
  return modelDiscovery.detail || 'sem modelos detectados; usando auto';
}
function baseArgs(){ const out = [...(cfg().get('argumentosPadrao') || []).map(String).filter(Boolean)]; const ma = String(cfg().get('argumentoModelo') || '').trim(); const m = modelForCli(); if(ma && m) out.push(ma, m); return out; }
function fullPrompt(text){ const prefix = cfg().get('prefixoPromptPadrao') || ''; const selectedModel = modelForCli() || model() || 'auto (padrao do Devin CLI)'; const ctx = [
  `Workspace VS Code: ${rootName()}`,
  root()?`Diretorio raiz: ${root()}`:'Diretorio raiz: nao ha pasta aberta',
  `Modelo selecionado: ${selectedModel}`,
  agent() !== 'auto' ? `Agente selecionado: ${agent()}` : 'Agente selecionado: auto'
].join('\n');
const agentHint = agent() !== 'auto' ? `Use o perfil/subagente Devin chamado "${agent()}" quando aplicavel. Se a CLI nao aceitar selecao direta de agente nesta chamada, trate este agente como persona operacional e siga as instrucoes do respectivo AGENT.md.` : '';
return [prefix, ctx, agentHint, text].filter(Boolean).join('\n\n'); }
function terminalCommand(text){ const args = baseArgs().map(quote).join(' '); const exe = quote(devinPath()); if(!text) return [exe, args].filter(Boolean).join(' '); return [exe, args, '--', quote(fullPrompt(text))].filter(Boolean).join(' '); }
function openTerminal(text){ const sh = terminalShell(); const t = vscode.window.createTerminal({ name:(cfg().get('nomeTerminal') || 'Devin Cli Chat'), cwd: root() || os.homedir(), shellPath: sh, shellArgs: process.platform==='win32' && sh?['--login','-i']:undefined }); t.show(true); t.sendText(terminalCommand(text)); }
function runIntegrated(text){ return new Promise((resolve)=>{ const args = [...baseArgs(), '-p', '--', fullPrompt(text)]; const child = cp.execFile(devinPath(), args, { cwd: root() || os.homedir(), timeout: cfg().get('timeoutChatMs') || 300000, maxBuffer: 1024*1024*16, windowsHide: true }, (err, stdout, stderr)=>{
    if(err && process.platform === 'win32'){
      runIntegratedViaBash(text, err).then(resolve); return;
    }
    const pieces=[]; if(stdout) pieces.push(stdout.trim()); if(stderr) pieces.push('STDERR:\n'+stderr.trim()); if(err) pieces.push(`Falha ao executar Devin CLI: ${err.message}`); resolve(pieces.join('\n\n') || 'Sem saida do Devin CLI.');
  });
  child.on('error', (err)=>resolve(`Falha ao iniciar Devin CLI: ${err.message}\n\nValide o caminho em devinCliChat.caminhoDevin e execute "Devin Cli Chat: Verificar Devin CLI".`));
}); }
function runIntegratedViaBash(text, firstError){ return new Promise((resolve)=>{ const sh = findGitBash(); if(!sh){ resolve(`Falha ao executar Devin CLI: ${firstError.message}\n\nGit Bash nao foi encontrado. Configure devinCliChat.gitBashPath ou ajuste devinCliChat.caminhoDevin.`); return; } const cmd = `${quote(devinPath())} ${baseArgs().map(quote).join(' ')} -p -- ${quote(fullPrompt(text))}`; cp.exec(cmd, { cwd: root() || os.homedir(), shell: sh, timeout: cfg().get('timeoutChatMs') || 300000, maxBuffer: 1024*1024*16 }, (err, stdout, stderr)=>{ const pieces=[]; if(stdout) pieces.push(stdout.trim()); if(stderr) pieces.push('STDERR:\n'+stderr.trim()); if(err) pieces.push(`Falha ao executar Devin CLI via Git Bash: ${err.message}`); resolve(pieces.join('\n\n') || 'Sem saida do Devin CLI.'); }); }); }
async function setConfig(k,v){ await cfg().update(k,v,vscode.ConfigurationTarget.Workspace); updateStatus(); provider && provider.refreshMeta(); }
function globalAgentsPath(){ const configured = cfg().get('diretorioAgentesGlobal'); if(process.platform === 'win32' && (!configured || configured === '~/.config/devin/agents')){ return path.join(process.env.APPDATA || path.join(os.homedir(),'AppData','Roaming'), 'devin', 'agents'); } return absMaybe(configured); }
function scanAgentsSync(){ const dirs = [absMaybe(cfg().get('diretorioAgentesWorkspace')), globalAgentsPath()]; const out = ['auto']; for(const d of dirs){ try{ if(!d || !fs.existsSync(d)) continue; for(const name of fs.readdirSync(d)){ const p = path.join(d,name,'AGENT.md'); if(fs.existsSync(p)) out.push(name); } }catch{} } return Array.from(new Set(out)); }
function agentsForUi(){ const selected = agent(); const out = ['auto', ...(Array.isArray(cachedAgents) ? cachedAgents : [])]; if(selected && !out.includes(selected)) out.unshift(selected); return Array.from(new Set(out.filter(Boolean))); }
function scheduleAgentsScan(force){ if(agentScanScheduled && !force) return; agentScanScheduled = true; setTimeout(()=>{ try{ const scanned = scanAgentsSync(); if(scanned && scanned.length) cachedAgents = scanned; }catch{} agentScanScheduled = false; provider && provider.refreshMeta(); }, force ? 0 : 350); }
function activeContext(){ const ed = vscode.window.activeTextEditor; if(!ed) return 'Nenhum editor ativo.'; const doc = ed.document; const sel = ed.selection && !ed.selection.isEmpty ? doc.getText(ed.selection) : doc.getText(); return [`Arquivo: ${doc.uri.fsPath}`, 'Conteudo:', '```', sel.slice(0,60000), '```'].join('\n'); }
function gitDiff(){ try{ return cp.execFileSync('git',['diff','--no-ext-diff'],{cwd:root()||os.homedir(),encoding:'utf8',maxBuffer:1024*1024*8}); }catch(e){ return `Nao foi possivel obter git diff: ${e.message}`; } }
function updateStatus(){ if(!status){ status = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 90); status.command='devinCliChat.abrirPainel'; status.show(); } const selectedModel = modelForCli() || 'auto'; status.text = `Devin Cli Chat: ${selectedModel} / ${agent()}`; status.tooltip = `Workspace: ${rootName()}\n${modelSourceLabel()}`; }

function shellSplit(input){
  const out=[]; let cur=''; let quoteChar=null; let esc=false;
  for(const ch of String(input||'')){
    if(esc){ cur += ch; esc=false; continue; }
    if(ch === '\\'){ esc=true; continue; }
    if(quoteChar){ if(ch === quoteChar) quoteChar=null; else cur += ch; continue; }
    if(ch === '"' || ch === "'"){ quoteChar=ch; continue; }
    if(/\s/.test(ch)){ if(cur){ out.push(cur); cur=''; } continue; }
    cur += ch;
  }
  if(cur) out.push(cur);
  return out;
}
function safeDiscoveryTimeoutMs(){
  const raw = Number(cfg().get('timeoutDescobertaModelosMs') || 3000);
  if(!Number.isFinite(raw) || raw <= 0) return 3000;
  return Math.max(1000, Math.min(raw, 10000));
}
function totalDiscoveryBudgetMs(){
  const raw = Number(cfg().get('timeoutTotalDescobertaModelosMs') || 7000);
  if(!Number.isFinite(raw) || raw <= 0) return 7000;
  return Math.max(safeDiscoveryTimeoutMs(), Math.min(raw, 30000));
}
function killProcessTree(child){
  if(!child || !child.pid) return;
  try{
    if(process.platform === 'win32'){
      try{ child.kill(); }catch{}
      try{ cp.execFile('taskkill', ['/PID', String(child.pid), '/T', '/F'], {windowsHide:true}, ()=>{}); }catch{}
    } else {
      try{ child.kill('SIGTERM'); }catch{}
      setTimeout(()=>{ try{ child.kill('SIGKILL'); }catch{} }, 300);
    }
  }catch{
    try{ child.kill(); }catch{}
  }
}
function stripJsonComments(text){
  return String(text || '').replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:])\/\/.*$/gm, '$1');
}
function readJsoncFile(file){
  try{
    if(!file || !fs.existsSync(file)) return undefined;
    return JSON.parse(stripJsonComments(fs.readFileSync(file, 'utf8')));
  }catch{ return undefined; }
}
function devinConfigFiles(){
  const userFile = process.platform === 'win32'
    ? path.join(process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'), 'devin', 'config.json')
    : path.join(os.homedir(), '.config', 'devin', 'config.json');
  const workspace = root();
  const files = [userFile];
  if(workspace){
    files.push(path.join(workspace, '.devin', 'config.json'));
    files.push(path.join(workspace, '.devin', 'config.local.json'));
  }
  return files;
}

function readCurrentDevinModel(){
  for(const file of devinConfigFiles()){
    const data = readJsoncFile(file);
    if(!data || typeof data !== 'object') continue;
    const candidates = [];
    try{ if(data.agent && data.agent.model) candidates.push(data.agent.model); }catch{}
    try{ if(data.model) candidates.push(data.model); }catch{}
    try{ if(data.default_model) candidates.push(data.default_model); }catch{}
    try{ if(data.defaultModel) candidates.push(data.defaultModel); }catch{}
    for(const candidate of candidates){
      const normalized = normalizeCandidate(candidate) || normalizeModel(candidate);
      if(normalized && normalized !== 'auto') return normalized;
    }
  }
  return undefined;
}
function devinModelCacheFiles(){
  const configured = cfg().get('arquivosCacheModelos');
  const files = [];
  if(Array.isArray(configured)){
    for(const item of configured){
      const p = home(String(item || '').trim());
      if(p) files.push(path.isAbsolute(p) ? p : path.join(root() || os.homedir(), p));
    }
  }
  if(process.platform === 'win32'){
    const local = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
    files.push(path.join(local, 'Devin', 'CLI', 'model_configs.bin'));
    files.push(path.join(local, 'Devin', 'CLI', 'team_settings.bin'));
  } else {
    const candidates = [
      path.join(os.homedir(), '.cache', 'Devin', 'CLI'),
      path.join(os.homedir(), '.cache', 'devin', 'CLI'),
      path.join(os.homedir(), '.local', 'share', 'Devin', 'CLI'),
      path.join(os.homedir(), '.local', 'share', 'devin', 'CLI'),
      path.join(os.homedir(), 'Library', 'Application Support', 'Devin', 'CLI')
    ];
    for(const base of candidates){
      files.push(path.join(base, 'model_configs.bin'));
      files.push(path.join(base, 'team_settings.bin'));
    }
  }
  return Array.from(new Set(files.filter(Boolean)));
}
function splitPrintableStrings(text){
  return String(text || '')
    .replace(/[^\x20-\x7E\u00A0-\uFFFF]+/g, '\n')
    .split(/\n+/g)
    .map(s=>s.trim())
    .filter(s=>s.length >= 2 && s.length <= 160);
}
function readProtoVarint(buf, offset, end){
  let result = 0n;
  let shift = 0n;
  let i = offset;
  while(i < end){
    const byte = buf[i++];
    result |= BigInt(byte & 0x7f) << shift;
    if((byte & 0x80) === 0) return {value:Number(result), offset:i};
    shift += 7n;
    if(shift > 70n) throw new Error('varint invalido');
  }
  throw new Error('protobuf truncado');
}
function decodeUtf8Printable(buf){
  try{
    const s = Buffer.from(buf).toString('utf8');
    if(/^[\t\n\r\x20-\x7e\u00a0-\uffff]*$/.test(s)) return s;
  }catch{}
  return undefined;
}
function parseProtoFields(buf, maxFields){
  const out=[];
  let i=0;
  const end = buf.length;
  const limit = Math.max(1, maxFields || 10000);
  while(i < end && out.length < limit){
    const pos = i;
    const keyInfo = readProtoVarint(buf, i, end);
    const key = keyInfo.value;
    i = keyInfo.offset;
    const field = key >> 3;
    const wire = key & 7;
    const item = {field, wire, pos};
    if(wire === 0){
      const valueInfo = readProtoVarint(buf, i, end);
      item.value = valueInfo.value;
      i = valueInfo.offset;
    } else if(wire === 1){
      if(i + 8 > end) break;
      item.raw = buf.subarray(i, i + 8);
      i += 8;
    } else if(wire === 2){
      const lenInfo = readProtoVarint(buf, i, end);
      const len = lenInfo.value;
      i = lenInfo.offset;
      if(len < 0 || i + len > end) break;
      item.raw = buf.subarray(i, i + len);
      item.value = decodeUtf8Printable(item.raw);
      i += len;
    } else if(wire === 5){
      if(i + 4 > end) break;
      item.raw = buf.subarray(i, i + 4);
      i += 4;
    } else {
      break;
    }
    out.push(item);
  }
  return out;
}
function parseModelConfigsBin(buf){
  const values=[];
  try{
    for(const top of parseProtoFields(buf, 20000)){
      if(top.field !== 1 || top.wire !== 2 || !top.raw) continue;
      let id;
      let label;
      try{
        for(const item of parseProtoFields(top.raw, 300)){
          if(item.field === 22 && typeof item.value === 'string') id = item.value;
          if(item.field === 1 && typeof item.value === 'string') label = item.value;
        }
      }catch{}
      const normalized = normalizeCandidate(id);
      if(normalized) values.push(normalized);
      else if(label) values.push(...parseTextModels(label, 'high'));
    }
  }catch{}
  return uniqModels(values);
}
function parseTeamSettingsBin(buf){
  const values=[];
  try{
    for(const item of parseProtoFields(buf, 20000)){
      if(item.wire !== 2 || typeof item.value !== 'string') continue;
      if(item.field === 7 || item.field === 26){
        const normalized = normalizeCandidate(item.value);
        if(normalized) values.push(normalized);
      }
    }
  }catch{}
  return uniqModels(values);
}

function fastModelsFromBinaryBuffer(buf){
  const values = [];
  const addText = (text)=>{
    for(const token of splitPrintableStrings(text)){
      const normalized = normalizeCandidate(token);
      if(normalized) values.push(normalized);
      if(/(MODEL_[A-Z0-9_]+|claude|gpt|codex|gemini|swe|opus|sonnet|haiku|o[0-9]|kimi|glm|llama|mistral|deepseek|qwen|nova|command|granite|mixtral|adaptive)/i.test(token)){
        values.push(...parseTextModels(token, 'high'));
      }
    }
  };
  try{ addText(buf.toString('utf8')); }catch{}
  try{ addText(buf.toString('latin1')); }catch{}
  return uniqModels(values);
}
function readBinaryModelCacheFile(file){
  try{
    if(!file || !fs.existsSync(file)) return [];
    const stat = fs.statSync(file);
    const maxBytes = Math.max(1024, Math.min(Number(cfg().get('limiteBytesCacheModelos') || 5242880), 52428800));
    if(!stat.isFile() || stat.size <= 0 || stat.size > maxBytes) return [];
    const buf = fs.readFileSync(file);
    const base = path.basename(file).toLowerCase();
    let parsed = [];
    try{
      if(base === 'team_settings.bin') parsed = parseTeamSettingsBin(buf);
      else if(base === 'model_configs.bin') parsed = parseModelConfigsBin(buf);
      else parsed = uniqModels([...parseTeamSettingsBin(buf), ...parseModelConfigsBin(buf)]);
    }catch{ parsed = []; }
    if(parsed.filter(m => m !== 'auto').length) return parsed;
    return fastModelsFromBinaryBuffer(buf);
  }catch{ return []; }
}
function readCachedDevinModels(){
  const values = [];
  for(const file of devinModelCacheFiles()){
    values.push(...readBinaryModelCacheFile(file));
  }
  return uniqModels(values);
}
function keyLooksLikeModel(key){
  return /(model|models|modelo|modelos|allowedModels|availableModels|defaultModel|default_model|model_allowlist|allowlist)/i.test(String(key || ''));
}
function collectConfigModelValues(value, acc, key){
  if(value === undefined || value === null) return;
  const modelKey = keyLooksLikeModel(key);
  if(typeof value === 'string'){
    if(modelKey) acc.push(value);
    return;
  }
  if(Array.isArray(value)){
    for(const item of value){
      if(typeof item === 'string'){
        if(modelKey) acc.push(item);
      } else if(item && typeof item === 'object'){
        collectConfigModelValues(item, acc, key);
      }
    }
    return;
  }
  if(typeof value === 'object'){
    for(const [childKey, childValue] of Object.entries(value)){
      if(modelKey && typeof childValue === 'string' && /^(id|name|value|model|modelo)$/i.test(childKey)) acc.push(childValue);
      collectConfigModelValues(childValue, acc, childKey);
    }
  }
}
function readConfigModels(){
  const values=[];
  for(const file of devinConfigFiles()){
    const data = readJsoncFile(file);
    if(!data || typeof data !== 'object') continue;
    collectConfigModelValues(data, values, 'root');
    if(data.agent && data.agent.model) values.push(data.agent.model);
    if(data.model) values.push(data.model);
    if(data.default_model) values.push(data.default_model);
    if(data.defaultModel) values.push(data.defaultModel);
  }
  return uniqModels(values);
}
function customDiscoveryArgs(){ return shellSplit(cfg().get('comandoDescobertaModelos') || ''); }
function discoveryCommands(){
  const custom = customDiscoveryArgs();
  const commands = [];
  if(custom.length) commands.push({source:'devin '+custom.join(' '), args:custom, trust:'high', custom:true});
  if(cfg().get('tentarComandosLegadosDescobertaModelos', false)){
    commands.push(
      {source:'devin models --format json', args:['models','--format','json'], trust:'high'},
      {source:'devin models --json', args:['models','--json'], trust:'high'},
      {source:'devin models', args:['models'], trust:'high'},
      {source:'devin model list --format json', args:['model','list','--format','json'], trust:'high'},
      {source:'devin model list --json', args:['model','list','--json'], trust:'high'},
      {source:'devin model list', args:['model','list'], trust:'high'},
      {source:'devin --list-models', args:['--list-models'], trust:'high'},
      {source:'devin --models', args:['--models'], trust:'high'}
    );
  }
  return commands;
}
function execDevin(args, timeoutMs){
  return new Promise((resolve)=>{
    let done=false;
    let child;
    const started = Date.now();
    const finish=(result)=>{
      if(done) return;
      done=true;
      clearTimeout(timer);
      resolve(Object.assign({durationMs: Date.now() - started}, result));
    };
    const timer=setTimeout(()=>{
      killProcessTree(child);
      finish({err:new Error('Timeout apos '+timeoutMs+'ms'), stdout:'', stderr:''});
    }, timeoutMs);
    try{
      child = cp.execFile(devinPath(), args, { cwd: root() || os.homedir(), maxBuffer: 1024*1024*4, windowsHide: true }, (err, stdout, stderr)=>{
        if(err && process.platform === 'win32'){
          execDevinViaBash(args, Math.max(1000, timeoutMs - (Date.now() - started))).then(finish);
          return;
        }
        finish({ err, stdout: stdout || '', stderr: stderr || '' });
      });
      child.on('error', (err)=>{
        if(process.platform === 'win32') execDevinViaBash(args, Math.max(1000, timeoutMs - (Date.now() - started))).then(finish);
        else finish({err, stdout:'', stderr:''});
      });
    }catch(err){
      if(process.platform === 'win32') execDevinViaBash(args, timeoutMs).then(finish);
      else finish({err, stdout:'', stderr:''});
    }
  });
}
function execDevinViaBash(args, timeoutMs){
  return new Promise((resolve)=>{
    const sh = findGitBash();
    if(!sh){ resolve({err:new Error('Git Bash nao encontrado'), stdout:'', stderr:''}); return; }
    let done=false;
    let child;
    const started = Date.now();
    const finish=(result)=>{ if(done) return; done=true; clearTimeout(timer); resolve(Object.assign({durationMs: Date.now() - started}, result)); };
    const timer=setTimeout(()=>{ killProcessTree(child); finish({err:new Error('Timeout apos '+timeoutMs+'ms'), stdout:'', stderr:''}); }, timeoutMs);
    try{
      const cmd = String(quote(devinPath()) + ' ' + args.map(quote).join(' ')).trim();
      child = cp.exec(cmd, { cwd: root() || os.homedir(), shell: sh, maxBuffer: 1024*1024*4 }, (err, stdout, stderr)=>finish({err, stdout:stdout||'', stderr:stderr||''}));
      child.on('error', err=>finish({err, stdout:'', stderr:''}));
    }catch(err){ finish({err, stdout:'', stderr:''}); }
  });
}

function spawnAcpProcess(){
  try{
    return cp.spawn(devinPath(), ['acp'], { cwd: root() || os.homedir(), stdio:['pipe','pipe','pipe'], windowsHide:true });
  }catch(e){
    if(process.platform === 'win32'){
      const sh = findGitBash();
      if(sh) return cp.spawn(sh, ['--login','-lc', quote(devinPath())+' acp'], { cwd: root() || os.homedir(), stdio:['pipe','pipe','pipe'], windowsHide:true });
    }
    throw e;
  }
}
function modelsFromAcpConfigOptions(configOptions){
  if(!Array.isArray(configOptions)) return [];
  const values=[];
  for(const opt of configOptions){
    const category = String(opt && opt.category || '').toLowerCase();
    const id = String(opt && opt.id || '').toLowerCase();
    const name = String(opt && opt.name || '').toLowerCase();
    if(category !== 'model' && id !== 'model' && !name.includes('model')) continue;
    const options = Array.isArray(opt.options) ? opt.options : [];
    for(const option of options){
      if(option && typeof option === 'object') values.push(option.value || option.id || option.name);
      else values.push(option);
    }
    if(opt.currentValue) values.push(opt.currentValue);
  }
  return uniqModels(values);
}
function writeAcpMessage(child, payload){
  const body = JSON.stringify(payload);
  const header = 'Content-Length: ' + Buffer.byteLength(body, 'utf8') + '\r\n\r\n';
  child.stdin.write(header + body);
}
function parseAcpMessages(buffer, onMessage){
  const messages=[];
  let rest = buffer;
  while(rest.length){
    if(/^Content-Length:/i.test(rest)){
      let sep = rest.indexOf('\r\n\r\n');
      let sepLen = 4;
      if(sep < 0){ sep = rest.indexOf('\n\n'); sepLen = 2; }
      if(sep < 0) break;
      const header = rest.slice(0, sep);
      const match = header.match(/Content-Length:\s*(\d+)/i);
      if(!match) break;
      const headerLen = sep + sepLen;
      const len = Number(match[1]);
      if(rest.length < headerLen + len) break;
      messages.push(rest.slice(headerLen, headerLen + len));
      rest = rest.slice(headerLen + len);
      continue;
    }
    const idx = rest.indexOf('\n');
    if(idx < 0) break;
    const line = rest.slice(0, idx).trim();
    rest = rest.slice(idx + 1);
    if(line) messages.push(line);
  }
  for(const raw of messages){
    try{ onMessage(JSON.parse(raw)); }catch{}
  }
  return rest;
}
function discoverModelsViaAcp(timeoutMs){
  return new Promise((resolve)=>{
    if(!cfg().get('usarAcpParaDescobertaModelos', false)){
      resolve({models:[], error:new Error('ACP desabilitado por configuracao')});
      return;
    }
    let child;
    try{ child = spawnAcpProcess(); }catch(e){ resolve({models:[], error:e}); return; }
    let done=false;
    let buffer='';
    let stderr='';
    let sessionId;
    const started = Date.now();
    const timer = setTimeout(()=>finish([], new Error('Timeout ACP apos '+timeoutMs+'ms')), timeoutMs);
    function finish(models, err){
      if(done) return;
      done=true;
      clearTimeout(timer);
      try{
        if(sessionId) writeAcpMessage(child, {jsonrpc:'2.0',id:99,method:'session/close',params:{sessionId}});
      }catch{}
      killProcessTree(child);
      resolve({models, error:err, stderr, durationMs: Date.now() - started});
    }
    function send(id, method, params){
      try{ writeAcpMessage(child, {jsonrpc:'2.0', id, method, params}); }
      catch(e){ finish([], e); }
    }
    function handleMessage(msg){
      if(msg.id === 1 && msg.result){
        send(2, 'session/new', { cwd: root() || os.homedir(), mcpServers: [] });
      } else if(msg.id === 2){
        if(msg.error){ finish([], new Error(msg.error.message || 'Erro ACP em session/new')); return; }
        sessionId = msg.result && msg.result.sessionId;
        const models = modelsFromAcpConfigOptions(msg.result && msg.result.configOptions);
        if(models.length > 1) finish(models, undefined);
        else finish([], new Error('ACP nao retornou configOptions de modelo'));
      } else if(msg.id && msg.method){
        try{ writeAcpMessage(child, {jsonrpc:'2.0', id:msg.id, error:{code:-32601, message:'Metodo nao suportado pela descoberta de modelos'}}); }catch{}
      }
    }
    child.on('error', err=>finish([], err));
    child.stderr.on('data', d=>{ stderr += String(d); });
    child.stdout.on('data', data=>{
      buffer += String(data);
      buffer = parseAcpMessages(buffer, handleMessage);
    });
    child.on('exit', code=>{ if(!done) finish([], new Error('ACP encerrou com codigo '+code)); });
    send(1, 'initialize', {
      protocolVersion: 1,
      clientInfo: { name: 'Devin Cli Chat', title:'Devin Cli Chat', version: '0.17.0' },
      clientCapabilities: { fs: { readTextFile:false, writeTextFile:false }, terminal:false }
    });
  });
}

function uniqModels(items){
  const out=[]; const seen=new Set();
  for(const raw of items){
    const value = normalizeCandidate(raw);
    if(!value) continue;
    const key = value.toLowerCase();
    if(!seen.has(key)){ seen.add(key); out.push(value); }
  }
  if(!out.includes('auto')) out.unshift('auto');
  return out;
}
function normalizeCandidate(raw){
  let s = String(raw || '').trim();
  s = s.replace(/^[`'"\[\](),:;]+|[`'"\[\](),:;]+$/g, '').trim();
  if(!s) return '';
  if(s === '<MODEL>' || s === '[MODEL]' || s === 'MODEL') return '';
  if(/[\\/]/.test(s) || s.includes('@')) return '';
  if(!/^[A-Za-z0-9][A-Za-z0-9._-]{1,80}$/.test(s)) return '';
  const lower = s.toLowerCase();
  const stop = new Set(['devin','model','models','available','allowed','valid','invalid','error','usage','options','prompt','print','response','exit','format','json','list','set','session','command','flag','slash','name','current','configured','default','padrao','the','and','or','for','with','true','false','normal','dangerous','bypass','accept-edits','plan','ask','workspace','help','version','auth','login','logout','status','mcp','rules','skills','paths','show','remove','add','update','setup','uninstall','context','compact','theme','mode']);
  if(stop.has(lower)) return '';
  if(KNOWN_MODEL_HINTS.has(lower)) return lower;
  if(/^(claude|gpt|codex|gemini|swe|kimi|glm|llama|mistral|deepseek|qwen|o[0-9]|nova|command|granite|mixtral)[A-Za-z0-9._-]*/i.test(s)) return s;
  if(/^MODEL_[A-Z0-9_]+$/.test(s)) return s;
  if(/[._-]/.test(s) && /\d/.test(s)) return s;
  return '';
}
function collectStringsFromJson(obj, acc){
  if(Array.isArray(obj)){ for(const x of obj) collectStringsFromJson(x, acc); return; }
  if(obj && typeof obj === 'object'){
    for(const [k,v] of Object.entries(obj)){
      const key = k.toLowerCase();
      if(typeof v === 'string' && /(model|name|id|value)/.test(key)) acc.push(v);
      else collectStringsFromJson(v, acc);
    }
    return;
  }
  if(typeof obj === 'string') acc.push(obj);
}
function parseJsonModels(text){
  const clean = String(text||'').trim();
  if(!clean) return [];
  const chunks = [clean];
  const firstBrace = clean.search(/[\[{]/);
  if(firstBrace > 0) chunks.push(clean.slice(firstBrace));
  for(const c of chunks){
    try{
      const parsed = JSON.parse(c);
      const acc=[]; collectStringsFromJson(parsed, acc);
      const models = uniqModels(acc);
      if(models.length > 1) return models;
    }catch{}
  }
  return [];
}
function parseTextModels(text, trust){
  const all = String(text || '');
  const json = parseJsonModels(all);
  if(json.length > 1) return json;
  const candidates=[];
  const lines = all.split(/\r?\n/);
  for(const line of lines){
    const lower = line.toLowerCase();
    const modelishLine = /(model|models|allowed|available|valid|whitelist|allowlist|config name|provider|claude|gpt|codex|gemini|swe|opus|sonnet|kimi|glm|llama|mistral|deepseek|qwen)/.test(lower);
    if(trust === 'low' && !modelishLine) continue;
    const backticks = [...line.matchAll(/`([^`]+)`/g)].map(m=>m[1]);
    candidates.push(...backticks);
    const afterColon = line.includes(':') ? line.slice(line.indexOf(':')+1) : line;
    candidates.push(...afterColon.split(/[\s,|]+/g));
  }
  return uniqModels(candidates);
}
function loadModelCache(){
  if(!extensionContext) return;
  const cached = extensionContext.globalState.get(CACHE_KEY);
  if(cached && Array.isArray(cached.models)){
    const ttl = cfg().get('cacheModelosMs') || 1800000;
    const fresh = Date.now() - (cached.time || 0) < ttl;
    modelDiscovery = {
      status: fresh ? 'ok' : 'stale',
      detail: fresh ? 'Cache de modelos carregado.' : 'Cache de modelos expirado; aguardando nova descoberta.',
      source: cached.source || 'cache',
      models: cached.models
    };
  }
}
async function saveModelCache(models, source){
  if(!extensionContext) return;
  await extensionContext.globalState.update(CACHE_KEY, { time: Date.now(), source, models });
}
function readLocalModelSources(){
  const values = [];
  try{ cachedCurrentModel = readCurrentDevinModel(); if(cachedCurrentModel) values.push(cachedCurrentModel); }catch{}
  const configModels = readConfigModels().filter(m => m !== 'auto');
  const cachedFileModels = readCachedDevinModels().filter(m => m !== 'auto');
  const manual = manualModels();
  return uniqModels([...values, ...configModels, ...cachedFileModels, ...manual]);
}
async function discoverModels(force){
  if(modelDiscoveryPromise) return modelDiscoveryPromise;
  const previous = models();
  modelDiscovery = {
    status:'loading',
    detail:'Lendo config.json e caches locais do Devin...',
    source:'arquivos locais do Devin',
    models: previous && previous.length ? previous : ['auto']
  };
  provider && provider.refreshMeta(); updateStatus();
  modelDiscoveryPromise = new Promise((resolve)=>{
    setTimeout(async()=>{
      try{
        const local = readLocalModelSources();
        const useful = local.filter(m => m !== 'auto');
        if(useful.length){
          modelDiscovery = {
            status:'ok',
            detail:String(useful.length)+' modelo(s) carregado(s) de config.json/cache local/manual.',
            source:'arquivos locais do Devin',
            models:local
          };
          await saveModelCache(local, modelDiscovery.source);
        } else {
          const cached = extensionContext && extensionContext.globalState.get(CACHE_KEY);
          if(!force && cached && Array.isArray(cached.models) && cached.models.filter(m => m !== 'auto').length){
            modelDiscovery = {status:'ok', detail:'Lista carregada do cache da extensao.', source:cached.source || 'cache da extensao', models:cached.models};
          } else {
            modelDiscovery = {status:'ok', detail:'Nenhum cache local de modelos encontrado; usando auto.', source:'fallback seguro', models:['auto']};
          }
        }
      }catch(err){
        modelDiscovery = {status:'error', detail:'Falha ao ler modelos locais: '+(err && err.message ? err.message : String(err)), source:'erro', models: previous && previous.length ? previous : ['auto']};
      }
      provider && provider.refreshMeta(); updateStatus();
      const result = modelDiscovery;
      modelDiscoveryPromise = undefined;
      resolve(result);
    }, force ? 0 : 150);
  });
  return modelDiscoveryPromise;
}
async function ensureModels(){
  if(!cfg().get('descobrirModelosAutomaticamente', true)) return;
  if(modelDiscovery.status === 'loading' || modelDiscoveryPromise) return;
  const useful = (modelDiscovery.models || []).filter(m => m !== 'auto');
  if(modelDiscovery.status === 'stale' || modelDiscovery.status === 'idle' || modelDiscovery.status === 'error' || useful.length === 0){
    if(modelDiscoveryTimer) clearTimeout(modelDiscoveryTimer);
    modelDiscoveryTimer = setTimeout(()=>{
      discoverModels(false).catch(err=>{
        modelDiscovery = {status:'error', detail:'Falha ao ler modelos locais: '+(err && err.message ? err.message : String(err)), source:'erro', models:models()};
        provider && provider.refreshMeta(); updateStatus();
      });
    }, 250);
  }
}
async function pickManualModel(){ const value = await vscode.window.showInputBox({ title:'Devin Cli Chat: Definir modelo manual', prompt:'Informe o nome exato aceito pelo Devin CLI ou pela allowlist enterprise.', value: modelForCli() || '' }); if(value && value.trim()) await setConfig('modeloAtual', value.trim()); }
async function pickModel(){
  if(modelDiscovery.status === 'idle' || modelDiscovery.status === 'stale') await discoverModels(false);
  const items = models().map(m => ({ label:m, description:m==='auto'?'nao envia --model; usa padrao/allowlist do Devin CLI':'' }));
  items.push({ label:'$(sync) Atualizar modelos do Devin CLI', description:'executa a descoberta automatica novamente' });
  items.push({ label:'$(edit) Informar modelo manual...', description:'usar um nome que nao aparece na lista' });
  const pick = await vscode.window.showQuickPick(items,{placeHolder:`Selecione o modelo Devin (${modelSourceLabel()})`});
  if(!pick) return;
  if(pick.label.includes('Atualizar modelos')){ await discoverModels(true); return pickModel(); }
  if(pick.label.includes('Informar modelo manual')) return pickManualModel();
  await setConfig('modeloAtual', pick.label);
}

class ChatViewProvider{
  constructor(context){ this.context=context; this.view=undefined; this.busy=false; }
  resolveWebviewView(view){
    this.view=view;
    view.webview.options={ enableScripts:true, localResourceRoots:[this.context.extensionUri] };
    view.webview.html=this.html(view.webview);
    view.webview.onDidReceiveMessage(async msg=>{
      try{
        const type = msg && msg.type;
        if(type === 'ready'){ this.refreshMeta(); setTimeout(()=>ensureModels(), 400); scheduleAgentsScan(false); return; }
        if(type === 'send'){ await this.send(msg.text||''); return; }
        if(type === 'terminal'){ openTerminal(msg.text||''); return; }
        if(type === 'setModel'){ await setConfig('modeloAtual', msg.value); return; }
        if(type === 'manualModel'){ await pickManualModel(); return; }
        if(type === 'refreshModels'){ await this.refreshModelsFromUi(); return; }
        if(type === 'setAgent'){ await setConfig('agenteAtual', msg.value); return; }
        if(type === 'review'){ await this.send('Revise o git diff atual com foco em bugs, seguranca, testes, impacto produtivo e rollback.\n\n```diff\n'+gitDiff()+'\n```'); return; }
        if(type === 'selection'){ await this.send('Analise o contexto do editor atual.\n\n'+activeContext()); return; }
        if(type === 'insertSelection'){ this.post({type:'insertPrompt', text:'Analise o contexto do editor atual.\n\n'+activeContext()}); return; }
      }catch(err){
        this.busy=false;
        this.post({type:'busy', value:false});
        this.post({type:'message', role:'assistant', text:'Falha ao executar acao do painel: '+(err && err.message ? err.message : String(err))});
      }
    });
    setTimeout(()=>this.refreshMeta(), 50);
  }
  post(m){ try{ this.view && this.view.webview.postMessage(m); }catch{} }
  refreshMeta(){
    const payload = {type:'meta', models:['auto'], model:'auto', modelStatus:'modelo: auto', modelDiscoveryStatus:modelDiscovery.status || 'ok', agents:['auto'], agent:'auto', workspace:rootName(), mode:'resposta-integrada'};
    try{ payload.models = models(); }catch(e){ payload.models = ['auto']; payload.modelStatus = 'falha ao preparar lista de modelos; usando auto'; }
    try{ payload.model = model(); }catch(e){ payload.model = 'auto'; }
    try{ payload.modelStatus = modelSourceLabel(); }catch(e){}
    try{ payload.agents = agentsForUi(); }catch(e){ payload.agents = ['auto']; }
    try{ payload.agent = agent(); }catch(e){ payload.agent = 'auto'; }
    try{ payload.mode = cfg().get('modoExecucaoChat') || 'resposta-integrada'; }catch(e){}
    this.post(payload);
  }
  async refreshModelsFromUi(){
    this.post({type:'modelLoading', value:true});
    try{ await discoverModels(true); }
    catch(err){ modelDiscovery={status:'error', detail:'Falha na descoberta: '+(err && err.message ? err.message : String(err)), source:'erro', models:models()}; }
    finally{ this.refreshMeta(); this.post({type:'modelLoading', value:false}); }
  }
  async send(text){
    const prompt = String(text||'').trim();
    if(!prompt) return;
    if(this.busy){ this.post({type:'message', role:'assistant', text:'Ja existe uma execucao em andamento. Aguarde a conclusao antes de enviar outro prompt.'}); return; }
    this.busy = true;
    this.post({type:'message', role:'user', text:prompt});
    this.post({type:'busy', value:true});
    try{
      const mode = cfg().get('modoExecucaoChat') || 'resposta-integrada';
      if(mode === 'terminal'){
        openTerminal(prompt);
        this.post({type:'message', role:'assistant', text:'Sessao aberta no terminal integrado, ja posicionada na pasta aberta no VS Code.'});
        return;
      }
      const answer = await runIntegrated(prompt);
      this.post({type:'message', role:'assistant', text:answer});
    }catch(err){
      this.post({type:'message', role:'assistant', text:'Falha ao enviar para o Devin CLI: '+(err && err.message ? err.message : String(err))});
    }finally{
      this.busy = false;
      this.post({type:'busy', value:false});
      this.refreshMeta();
    }
  }
  html(webview){ const nonce=Date.now().toString(36); return `<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src ${webview.cspSource} data:; style-src 'unsafe-inline' ${webview.cspSource}; script-src 'nonce-${nonce}';"><meta name="viewport" content="width=device-width, initial-scale=1.0"><style>
:root{
  --bg:var(--vscode-sideBar-background);
  --fg:var(--vscode-foreground);
  --muted:var(--vscode-descriptionForeground);
  --border:var(--vscode-panel-border);
  --input:var(--vscode-input-background);
  --input-fg:var(--vscode-input-foreground);
  --focus:var(--vscode-focusBorder);
  --accent:var(--vscode-button-background);
  --accent-fg:var(--vscode-button-foreground);
  --secondary:var(--vscode-button-secondaryBackground);
  --secondary-fg:var(--vscode-button-secondaryForeground);
  --editor:var(--vscode-editor-background);
  --hover:var(--vscode-list-hoverBackground);
  --active:var(--vscode-list-activeSelectionBackground);
  --active-fg:var(--vscode-list-activeSelectionForeground);
  --code:var(--vscode-textCodeBlock-background);
}
*{box-sizing:border-box}
html,body{width:100%;height:100%;padding:0;margin:0;overflow:hidden;background:var(--bg);color:var(--fg);font-family:var(--vscode-font-family);font-size:var(--vscode-font-size)}
button,select,textarea{font:inherit;color:inherit}
.app{height:100vh;display:flex;flex-direction:column;background:var(--bg)}
.header{height:38px;min-height:38px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:8px;padding:0 10px;background:var(--bg)}
.product{display:flex;align-items:center;gap:8px;min-width:0;font-weight:600;font-size:12px;letter-spacing:.01em;text-transform:uppercase;color:var(--muted)}
.logo{width:18px;height:18px;border-radius:999px;background:var(--accent);color:var(--accent-fg);display:grid;place-items:center;font-size:10px;font-weight:700;flex:0 0 auto}.headerSpacer{flex:1}.iconBtn{border:0;background:transparent;color:var(--muted);width:26px;height:26px;border-radius:6px;display:grid;place-items:center;cursor:pointer}.iconBtn:hover{background:var(--hover);color:var(--fg)}.iconBtn.primary{background:var(--accent);color:var(--accent-fg)}
.thread{flex:1;overflow:auto;padding:14px 14px 10px 14px;scrollbar-gutter:stable;display:flex;flex-direction:column;gap:16px;background:var(--editor)}
.contextStrip{display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin:0 0 2px 0;color:var(--muted);font-size:11px}.ctxPill{border:1px solid var(--border);background:var(--bg);border-radius:999px;padding:3px 8px;max-width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ctxPill strong{font-weight:600;color:var(--fg)}
.welcome{margin:auto 0;display:grid;gap:12px;padding:8px 0 18px 0}.welcomeRow{display:flex;align-items:center;gap:10px}.welcomeTitle{font-size:18px;line-height:1.25;font-weight:600}.welcomeText{color:var(--muted);line-height:1.45;max-width:560px}.starterGrid{display:grid;gap:8px;grid-template-columns:1fr}.starter{border:1px solid var(--border);background:var(--bg);color:var(--fg);border-radius:10px;text-align:left;padding:10px;cursor:pointer}.starter:hover{background:var(--hover);border-color:var(--focus)}.starter b{display:block;margin-bottom:3px}.starter span{display:block;color:var(--muted);font-size:11px;line-height:1.35}
.msgRow{display:flex;gap:10px;align-items:flex-start}.msgRow.user{justify-content:flex-end}.avatar{width:24px;height:24px;border-radius:999px;display:grid;place-items:center;background:var(--accent);color:var(--accent-fg);font-size:11px;font-weight:700;flex:0 0 auto;margin-top:2px}.msg{max-width:92%;line-height:1.48;white-space:pre-wrap;overflow-wrap:anywhere}.msg.assistant{width:100%;padding:0 2px}.msg.user{background:var(--input);border:1px solid var(--border);border-radius:16px;padding:9px 12px;max-width:82%;box-shadow:0 1px 0 rgba(0,0,0,.08)}.msgMeta{font-size:11px;color:var(--muted);margin-bottom:4px}.msg pre{background:var(--code);border:1px solid var(--border);border-radius:8px;padding:10px;overflow:auto;white-space:pre-wrap}.msg code{font-family:var(--vscode-editor-font-family);font-size:var(--vscode-editor-font-size)}
.composerWrap{border-top:1px solid var(--border);background:var(--bg);padding:10px 10px 9px 10px}.composer{border:1px solid var(--border);background:var(--input);border-radius:12px;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 0 0 1px rgba(0,0,0,.02)}.composer:focus-within{border-color:var(--focus)}.inputLine{display:flex;align-items:flex-start;gap:8px;padding:8px 8px 0 8px}.mention{height:24px;border-radius:6px;background:var(--active);color:var(--active-fg);padding:3px 6px;font-size:12px;white-space:nowrap;flex:0 0 auto}textarea{width:100%;min-height:62px;max-height:200px;resize:none;background:transparent;color:var(--input-fg);border:0;outline:0;padding:3px 0 8px 0;line-height:1.4}.composerBar{display:flex;align-items:center;gap:6px;padding:6px 8px 8px 8px;border-top:1px solid color-mix(in srgb, var(--border) 70%, transparent)}.chip,.selectChip{height:26px;border:1px solid var(--border);background:var(--bg);color:var(--fg);border-radius:999px;padding:0 8px;display:flex;align-items:center;gap:5px;font-size:11px;white-space:nowrap;max-width:100%;min-width:0}.selectChip{appearance:none;cursor:pointer;padding-right:20px;background-image:linear-gradient(45deg, transparent 50%, var(--muted) 50%),linear-gradient(135deg, var(--muted) 50%, transparent 50%);background-position:calc(100% - 10px) 10px, calc(100% - 6px) 10px;background-size:4px 4px,4px 4px;background-repeat:no-repeat}.chip.small{padding:0 7px;color:var(--muted)}.barSpacer{flex:1;min-width:8px}.sendBtn{width:28px;height:28px;border-radius:8px;border:0;background:var(--accent);color:var(--accent-fg);cursor:pointer;display:grid;place-items:center;font-weight:700}.sendBtn:disabled{opacity:.5;cursor:not-allowed}.statusLine{display:flex;align-items:center;gap:8px;color:var(--muted);font-size:10px;margin-top:6px;padding:0 2px}.statusLine span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.busyDot{display:none;width:7px;height:7px;border-radius:999px;background:var(--accent);animation:pulse 1s infinite}.is-busy .busyDot{display:block}.is-busy .sendBtn{opacity:.55;pointer-events:none}@keyframes pulse{0%,100%{opacity:.35}50%{opacity:1}}
@media (max-width:380px){.chip.local,.chip.approvals{display:none}.msg{max-width:100%}.msg.user{max-width:88%}.composerBar{gap:4px}.selectChip{max-width:112px}.productText{display:none}}
</style></head><body><div class="app"><header class="header"><div class="product"><div class="logo">D</div><span class="productText">Devin Cli Chat</span></div><div class="headerSpacer"></div><button type="button" class="iconBtn" id="newChat" title="Nova conversa">+</button><button type="button" class="iconBtn" id="refreshModelsTop" title="Atualizar modelos">R</button><button type="button" class="iconBtn" id="terminalTop" title="Abrir sessao no terminal">⌁</button></header><main class="thread" id="thread"><div class="contextStrip" id="contextStrip"><span class="ctxPill">Workspace: <strong id="ctxWorkspace">${htmlEscape(rootName())}</strong></span><span class="ctxPill">Modelo: <strong id="ctxModel">${htmlEscape(modelForCli() || 'auto')}</strong></span><span class="ctxPill">Agente: <strong id="ctxAgent">${htmlEscape(agent() || 'auto')}</strong></span></div><section class="welcome" id="welcome"><div class="welcomeRow"><div class="avatar">D</div><div><div class="welcomeTitle">Como posso ajudar neste workspace?</div><div class="welcomeText">Use o Devin CLI com contexto da pasta aberta no VS Code. Selecione modelo e agente no composer, como em uma tela de chat agentic.</div></div></div><div class="starterGrid"><button type="button" class="starter" data-prompt="Revise o git diff atual com foco em bugs, seguranca, testes, impacto produtivo e rollback."><b>Revisar diff</b><span>Analisa alteracoes locais com foco produtivo.</span></button><button type="button" class="starter" data-prompt="Planeje a implementacao da proxima tarefa em etapas pequenas, com riscos, testes e estrategia de rollback."><b>Planejar tarefa</b><span>Gera um plano objetivo antes de alterar codigo.</span></button><button type="button" class="starter" data-prompt="Analise o contexto do editor atual e explique os pontos mais importantes."><b>Explicar contexto</b><span>Usa arquivo aberto ou selecao atual.</span></button></div></section></main><footer class="composerWrap"><div class="composer"><div class="inputLine"><span class="mention">@devin</span><textarea id="prompt" placeholder="Use Devin CLI com o workspace atual, modelo e agente selecionados..."></textarea></div><div class="composerBar"><button type="button" class="iconBtn" id="selection" title="Adicionar contexto do editor">＋</button><span class="chip local" title="Execucao local no workspace aberto">▣ Local</span><span class="chip approvals" title="Aprovacoes padrao do Devin CLI">◇ Aprovacoes Padrao</span><select class="selectChip" id="agent" title="Agente Devin"><option value="${htmlEscape(agent() || 'auto')}">${htmlEscape((agent() || 'auto') === 'auto' ? 'Auto' : agent())}</option></select><select class="selectChip" id="model" title="Modelo Devin"><option value="${htmlEscape(modelForCli() || 'auto')}">${htmlEscape((modelForCli() || 'auto') === 'auto' ? 'Auto' : (modelForCli() || 'auto'))}</option></select><button type="button" class="iconBtn" id="manualModel" title="Informar modelo manual">⚙</button><div class="barSpacer"></div><button type="button" class="sendBtn" id="send" title="Enviar">↑</button></div></div><div class="statusLine"><span class="busyDot"></span><span id="mode">integrado</span><span>·</span><span id="modelStatus">modelo: auto</span></div></footer></div><script nonce="${nonce}">(function(){
  const vscode = acquireVsCodeApi();
  const $ = function(id){ return document.getElementById(id); };
  const state = { hasMessages:false, busy:false, modelLoading:false };

  function safeText(value){ return String(value || ''); }
  function showClientError(err){
    const msg = 'Falha no painel: ' + (err && err.message ? err.message : String(err));
    const status = $('modelStatus');
    if(status) status.textContent = msg;
  }
  window.addEventListener('error', function(event){ showClientError(event.error || event.message); });

  function setBusy(value){
    state.busy = !!value;
    document.body.classList.toggle('is-busy', state.busy);
    const send = $('send');
    if(send) send.disabled = state.busy;
  }

  function setModelLoading(value){
    state.modelLoading = !!value;
    const refresh = $('refreshModelsTop');
    if(refresh) refresh.textContent = state.modelLoading ? '...' : 'R';
  }

  function post(message){ vscode.postMessage(message); }

  function opt(sel, items, value){
    if(!sel) return;
    const previous = sel.value;
    const selected = value || previous || 'auto';
    const seen = new Set();
    const list = Array.isArray(items) ? items.slice() : [];
    if(selected && list.indexOf(selected) === -1) list.unshift(selected);
    if(list.indexOf('auto') === -1) list.unshift('auto');
    sel.innerHTML = '';
    list.forEach(function(item){
      const x = safeText(item).trim();
      if(!x || seen.has(x)) return;
      seen.add(x);
      const option = document.createElement('option');
      option.value = x;
      option.textContent = x === 'auto' ? 'Auto' : x;
      if(x === selected) option.selected = true;
      sel.appendChild(option);
    });
  }

  function hideWelcome(){
    state.hasMessages = true;
    const welcome = $('welcome');
    if(welcome) welcome.style.display = 'none';
  }

  function clearThread(){
    state.hasMessages = false;
    const thread = $('thread');
    if(thread){
      Array.from(thread.querySelectorAll('.msgRow')).forEach(function(node){ node.remove(); });
      thread.scrollTop = 0;
    }
    const welcome = $('welcome');
    if(welcome) welcome.style.display = 'grid';
  }

  function content(el, text){
    const value = safeText(text);
    const fence = String.fromCharCode(96,96,96);
    const parts = value.split(fence);
    if(parts.length === 1){ el.textContent = value; return; }
    parts.forEach(function(part, index){
      if(index % 2 === 0){
        const span = document.createElement('span');
        span.textContent = part;
        el.appendChild(span);
      }else{
        const pre = document.createElement('pre');
        const code = document.createElement('code');
        code.textContent = part.replace(/^\w+\n/, '');
        pre.appendChild(code);
        el.appendChild(pre);
      }
    });
  }

  function add(role, text){
    hideWelcome();
    const thread = $('thread');
    if(!thread) return;
    const row = document.createElement('div');
    row.className = 'msgRow ' + (role === 'user' ? 'user' : 'assistant');
    if(role !== 'user'){
      const avatar = document.createElement('div');
      avatar.className = 'avatar';
      avatar.textContent = 'D';
      row.appendChild(avatar);
    }
    const msg = document.createElement('div');
    msg.className = 'msg ' + (role === 'user' ? 'user' : 'assistant');
    if(role !== 'user'){
      const meta = document.createElement('div');
      meta.className = 'msgMeta';
      meta.textContent = 'Devin Cli Chat';
      msg.appendChild(meta);
    }
    content(msg, text);
    row.appendChild(msg);
    thread.appendChild(row);
    thread.scrollTop = thread.scrollHeight;
  }

  function getPrompt(){ const prompt = $('prompt'); return prompt ? prompt.value : ''; }
  function setPrompt(value){ const prompt = $('prompt'); if(prompt){ prompt.value = value; prompt.focus(); } }
  function appendPrompt(text){
    const current = getPrompt().trim();
    const next = current ? current + '\n\n' + safeText(text).trim() : safeText(text).trim();
    setPrompt(next);
  }

  function sendText(text){
    const value = safeText(text).trim();
    if(!value || state.busy) return;
    post({type:'send', text:value});
    setPrompt('');
  }

  function bind(id, event, fn){
    const el = $(id);
    if(!el) return;
    el.addEventListener(event, function(e){
      try{ e.preventDefault(); fn(e, el); }
      catch(err){ showClientError(err); }
    });
  }

  window.addEventListener('message', function(event){
    try{
      const message = event.data || {};
      if(message.type === 'meta'){
        opt($('model'), message.models, message.model);
        opt($('agent'), message.agents, message.agent);
        const workspace = $('ctxWorkspace');
        const ctxModel = $('ctxModel');
        const ctxAgent = $('ctxAgent');
        const mode = $('mode');
        const modelStatus = $('modelStatus');
        if(workspace) workspace.textContent = message.workspace || 'sem workspace';
        if(ctxModel) ctxModel.textContent = message.model || 'auto';
        if(ctxAgent) ctxAgent.textContent = message.agent || 'auto';
        if(mode) mode.textContent = message.mode === 'terminal' ? 'terminal' : 'integrado';
        if(modelStatus) modelStatus.textContent = message.modelStatus || '';
        setModelLoading(message.modelDiscoveryStatus === 'loading');
      }
      if(message.type === 'message') add(message.role, message.text);
      if(message.type === 'busy') setBusy(!!message.value);
      if(message.type === 'modelLoading') setModelLoading(!!message.value);
      if(message.type === 'insertPrompt') appendPrompt(message.text || '');
    }catch(err){ showClientError(err); }
  });

  bind('send', 'click', function(){ sendText(getPrompt()); });
  bind('prompt', 'keydown', function(e){
    if(e.key === 'Enter' && !e.shiftKey){
      e.preventDefault();
      sendText(getPrompt());
    }
  });
  bind('model', 'change', function(e){ post({type:'setModel', value:e.target.value}); });
  bind('agent', 'change', function(e){ post({type:'setAgent', value:e.target.value}); });
  bind('manualModel', 'click', function(){ post({type:'manualModel'}); });
  bind('refreshModelsTop', 'click', function(){ setModelLoading(true); post({type:'refreshModels'}); });
  bind('terminalTop', 'click', function(){ post({type:'terminal', text:getPrompt()}); });
  bind('newChat', 'click', function(){ clearThread(); });
  bind('selection', 'click', function(){ post({type:'insertSelection'}); });

  document.querySelectorAll('.starter').forEach(function(button){
    button.addEventListener('click', function(e){
      e.preventDefault();
      const prompt = button.getAttribute('data-prompt') || '';
      if(prompt.indexOf('Revise o git diff') === 0) post({type:'review'});
      else if(prompt.indexOf('Analise o contexto') === 0) post({type:'selection'});
      else sendText(prompt);
    });
  });

  setBusy(false);
  post({type:'ready'});
})();</script></body></html>`; }
}
async function activate(context){
  extensionContext = context;
  loadModelCache();
  provider=new ChatViewProvider(context);
  context.subscriptions.push(vscode.window.registerWebviewViewProvider('devinCliChat.chatView',provider,{webviewOptions:{retainContextWhenHidden:true}}));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.abrirPainel',async()=>vscode.commands.executeCommand('workbench.view.extension.devinCliChat')));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.novaSessao',()=>openTerminal('')));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.revisarDiff',async()=>{await vscode.commands.executeCommand('workbench.view.extension.devinCliChat'); provider && provider.send('Revise o git diff atual com foco em bugs, seguranca, testes, impacto produtivo e rollback.\n\n```diff\n'+gitDiff()+'\n```');}));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.enviarSelecao',async()=>{await vscode.commands.executeCommand('workbench.view.extension.devinCliChat'); provider && provider.send('Analise o contexto do editor atual.\n\n'+activeContext());}));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.selecionarModelo',pickModel));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.definirModeloManual',pickManualModel));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.atualizarModelos',async()=>{ await discoverModels(true); vscode.window.showInformationMessage(modelDiscovery.models.length ? `Modelos atualizados: ${modelDiscovery.models.length-1} detectado(s).` : `Nao foi possivel detectar modelos automaticamente.`); }));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.selecionarAgente',async()=>{try{cachedAgents = scanAgentsSync();}catch{} const pick=await vscode.window.showQuickPick(agentsForUi(),{placeHolder:'Selecione o agente Devin'}); if(pick) await setConfig('agenteAtual',pick);}));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.verificarCli',async()=>{cp.execFile(devinPath(),['--version'],{cwd:root()||os.homedir(),windowsHide:true},(err,stdout,stderr)=>{vscode.window.showInformationMessage(err?`Falha ao verificar Devin CLI: ${err.message}`:`Devin CLI encontrado: ${(stdout||stderr||'ok').trim()}`); if(!err) discoverModels(true);});}));
  updateStatus();
  context.subscriptions.push(vscode.workspace.onDidChangeConfiguration(e=>{if(e.affectsConfiguration(EXT)){loadModelCache(); updateStatus(); provider && provider.refreshMeta(); ensureModels();}}));
}
function deactivate(){}
module.exports={activate,deactivate};
