# Devin Cli Chat

Tela própria de chat para usar o Devin CLI dentro do VS Code.

## Versão 0.20.0

Esta versão preserva o layout e o ícone da tela anterior, mas reimplementa o ciclo funcional dos botões e do chat com o fluxo que já funcionava na versão 0.5.0: `devin -p -- "<prompt>"`.

## Uso

1. Instale o VSIX.
2. Abra uma pasta no VS Code.
3. Abra a Activity Bar **Devin Cli Chat**.
4. Digite uma mensagem e pressione **Enviar** ou **Enter**.

## Configurações principais

```json
{
  "devinCliChat.caminhoDevin": "devin",
  "devinCliChat.modeloAtual": "auto",
  "devinCliChat.agenteAtual": "auto",
  "devinCliChat.modoExecucaoChat": "resposta-integrada"
}
```
