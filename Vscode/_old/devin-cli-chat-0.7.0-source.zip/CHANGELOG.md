# Changelog

## 0.7.0

- Correção da contribuição da tela própria: a view agora é do tipo `webview`.
- Corrige o erro: "Não há nenhum provedor de dados registrado que possa fornecer dados de exibição".
- Nome técnico do pacote alterado para `devin-cli-chat`.
- Desenvolvedor atualizado para **Luiz Alberto Abarca Ferrarezi**.
- Namespace de configuração alterado para `devinCliChat`.


## 0.6.0

- Nome exibido alterado para **Devin Cli Chat**.
- Removida a integração com a tela nativa `Chat` do VS Code.
- Mantida uma tela própria na Activity Bar com seletor de modelo e seletor de agente.
- Mantida a execução no workspace aberto no VS Code.
- Mantido desenvolvedor **Luiz Alberto Abarca Ferrarezi**.

## 0.5.0

- Correção da chamada integrada com `devin -p -- <prompt>`.
- Desenvolvedor alterado para Luiz Alberto Abarca Ferrarezi.
