# Devin Cli Chat

Desenvolvedor: **Luiz Alberto Abarca Ferrarezi**

Extensão VS Code para operar o **Devin CLI** em uma **tela própria de chat**, sem usar a tela nativa `Chat` do VS Code. A experiência inclui seleção de modelo, seleção de agente e execução sempre ancorada na pasta aberta no VS Code.

## Uso

1. Instale o VSIX.
2. Abra uma pasta no VS Code.
3. Abra a Activity Bar **Devin Cli Chat**.
4. Selecione o **modelo** e o **agente** no topo da tela.
5. Envie mensagens pelo composer do painel lateral.

## Experiência de chat

A extensão entrega uma tela própria, no mesmo padrão operacional de extensões agentic modernas:

- painel dedicado na Activity Bar;
- seletor de modelo no topo;
- seletor de agente no topo;
- composer de prompt;
- histórico da conversa no painel;
- botão para enviar contexto do editor;
- botão para revisar `git diff`;
- botão para abrir sessão interativa no terminal;
- execução com `cwd` igual à pasta aberta no VS Code.

## Modos de execução

- **Resposta integrada**: usa `devin -p -- <prompt>` para capturar a resposta e renderizar no painel.
- **Terminal**: abre uma sessão REPL do Devin CLI no terminal integrado.

## Windows corporativo

A extensão não depende de PowerShell para abrir sessões. No terminal integrado do Windows, ela tenta usar Git Bash quando `devinCliChat.usarGitBashNoWindows` está habilitado.

Configure manualmente quando necessário:

```json
{
  "devinCliChat.gitBashPath": "C:\\Program Files\\Git\\bin\\bash.exe"
}
```

## Configurações principais

```json
{
  "devinCliChat.caminhoDevin": "devin",
  "devinCliChat.modeloAtual": "opus",
  "devinCliChat.modelosDisponiveis": ["opus", "sonnet", "swe", "codex", "gemini"],
  "devinCliChat.agenteAtual": "auto",
  "devinCliChat.modoExecucaoChat": "resposta-integrada",
  "devinCliChat.nomeTerminal": "Devin Cli Chat",
  "devinCliChat.usarGitBashNoWindows": true
}
```

## Agentes

A extensão lista agentes encontrados em:

```text
.devin/agents/<nome>/AGENT.md
~/.config/devin/agents/<nome>/AGENT.md
```

Quando um agente é selecionado, o nome é injetado no contexto do prompt. Isso evita acoplamento a flags ainda não consolidadas para subagentes no Devin CLI.

## Comandos

- `Devin Cli Chat: Abrir chat`
- `Devin Cli Chat: Nova sessão Devin no workspace`
- `Devin Cli Chat: Revisar git diff`
- `Devin Cli Chat: Selecionar modelo`
- `Devin Cli Chat: Selecionar agente`
- `Devin Cli Chat: Verificar Devin CLI`

## Compatibilidade

O identificador interno foi alterado para `devin-cli-chat` e as configurações agora usam o namespace `devinCliChat`. Desinstale a extensão antiga `iudevachat` para evitar duplicidade na lista de extensões.


## Correção 0.7.0

- A visualização foi declarada explicitamente como `webview`, corrigindo a mensagem "Não há nenhum provedor de dados registrado que possa fornecer dados de exibição".
- O nome técnico do pacote foi alterado para `devin-cli-chat`, para aparecer como **Devin Cli Chat** sem o nome anterior na lista de extensões.
- Desenvolvedor atualizado para **Luiz Alberto Abarca Ferrarezi**.
