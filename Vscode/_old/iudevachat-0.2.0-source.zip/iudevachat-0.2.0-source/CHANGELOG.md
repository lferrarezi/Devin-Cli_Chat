# Changelog

## 0.2.0

- Localização de comandos, configurações e documentação para português brasileiro.
- Desenvolvedor definido como Itaú Unibanco.
- Suporte explícito a Git Bash em Windows corporativo com PowerShell desabilitado.
- Novo cockpit com ações rápidas: sessão, prompt, diff, plano, testes, erro/log e revisão de seleção.
- Novos comandos para seleção, arquivo atual, agentes, regras e verificação do Devin CLI.

## 0.1.0

- MVP inicial com terminal integrado, painel lateral, agentes e revisão de diff.
