# iuDevaChat

**iuDevaChat** é uma extensão VS Code desenvolvida por **Itaú Unibanco** para operar o **Devin CLI** dentro da IDE, em português brasileiro, com uma experiência próxima ao fluxo de extensões agentic como Codex, Claude Code e Gemini CLI.

A extensão é um cockpit local: ela não reimplementa o Devin. Ela orquestra o `devin-cli` via terminal integrado, adicionando atalhos, contexto de arquivo/seleção/diff, painel lateral, gerenciamento de agentes e regras do projeto.

## Recursos

- Activity Bar própria: `iuDevaChat`.
- Painel lateral `Chat Devin` para prompts e ações rápidas.
- Comandos no Command Palette em português brasileiro.
- Menu de contexto no editor para seleção e arquivo atual.
- Ação de revisão no painel de SCM para `git diff`.
- Gerenciamento de agentes Devin locais e globais.
- Criação assistida de `AGENTS.md`.
- Suporte a ambientes Windows corporativos com PowerShell desabilitado, usando **Git Bash**.
- Status Bar para iniciar sessão rapidamente.

## Pré-requisitos

1. Visual Studio Code 1.92 ou superior.
2. Devin CLI instalado e autenticado.
3. Git Bash instalado nas máquinas Windows em que PowerShell esteja bloqueado.

## Instalação manual

```bash
code --install-extension iudevachat-0.2.0.vsix
```

## Configurações

Todas as configurações estão em português brasileiro.

```json
{
  "iudevachat.caminhoDevin": "devin",
  "iudevachat.argumentosPadrao": [],
  "iudevachat.modoEnvioPrompt": "argumento",
  "iudevachat.nomeTerminal": "iuDevaChat",
  "iudevachat.usarGitBashNoWindows": true,
  "iudevachat.gitBashPath": "",
  "iudevachat.diretorioAgentesGlobal": "~/.config/devin/agents",
  "iudevachat.diretorioAgentesWorkspace": ".devin/agents",
  "iudevachat.prefixoPromptPadrao": "Responda em português brasileiro. Seja objetivo, cite arquivos concretos e priorize impacto produtivo, segurança, testes e rollback."
}
```

### Modos de envio de prompt

| Valor | Uso |
|---|---|
| `argumento` | Envia o prompt como argumento do comando `devin`. |
| `stdin` | Envia o prompt via heredoc Bash para o stdin do Devin CLI. Recomendado quando o CLI lê entrada padrão. |
| `arquivo-temporario` | Salva o prompt em arquivo temporário e envia o caminho como argumento. Útil para prompts longos. |

## Comandos principais

- `iuDevaChat: Iniciar sessão Devin`
- `iuDevaChat: Enviar prompt livre`
- `iuDevaChat: Explicar seleção`
- `iuDevaChat: Revisar seleção`
- `iuDevaChat: Gerar testes para seleção`
- `iuDevaChat: Refatorar seleção`
- `iuDevaChat: Analisar arquivo atual`
- `iuDevaChat: Documentar arquivo atual`
- `iuDevaChat: Investigar arquivo atual`
- `iuDevaChat: Revisar git diff`
- `iuDevaChat: Planejar tarefa`
- `iuDevaChat: Planejar ou rodar testes`
- `iuDevaChat: Diagnosticar erro ou log`
- `iuDevaChat: Abrir configuração do Devin`
- `iuDevaChat: Abrir ou criar AGENTS.md`
- `iuDevaChat: Criar agente no workspace`
- `iuDevaChat: Verificar Devin CLI`

## Agentes Devin

A extensão reconhece agentes no padrão:

```text
.devin/agents/<nome-do-agente>/AGENT.md
~/.config/devin/agents/<nome-do-agente>/AGENT.md
```

A view `Agentes Devin` lista agentes encontrados e permite abrir o `AGENT.md` diretamente.

## Windows corporativo sem PowerShell

Quando `iudevachat.usarGitBashNoWindows` estiver habilitado, a extensão tenta localizar o Git Bash nos caminhos comuns:

```text
C:\Program Files\Git\bin\bash.exe
C:\Program Files\Git\usr\bin\bash.exe
C:\Program Files (x86)\Git\bin\bash.exe
%USERPROFILE%\AppData\Local\Programs\Git\bin\bash.exe
```

Se o Git Bash estiver em outro local, configure:

```json
{
  "iudevachat.gitBashPath": "C:\\caminho\\para\\Git\\bin\\bash.exe"
}
```

## Arquitetura

```text
VS Code
  ├─ Activity Bar iuDevaChat
  ├─ Webview Chat Devin
  ├─ Tree View Agentes Devin
  ├─ Command Palette / Context Menus / SCM
  └─ Terminal integrado
       └─ devin-cli
```

## Limitações conhecidas

- O chat nativo do VS Code não é usado nesta versão para evitar dependência de APIs propostas ou instáveis.
- O comportamento final depende do contrato real do `devin-cli`; ajuste `iudevachat.modoEnvioPrompt` conforme o ambiente.
- A extensão não captura nem interpreta output interativo do terminal. Ela opera como orquestrador de comandos.

## Desenvolvimento

```bash
npm install
npm run check
```

Empacotamento manual:

```bash
vsce package
```

Quando `vsce` não estiver disponível, o VSIX pode ser montado como arquivo ZIP com estrutura `extension/`, `[Content_Types].xml` e `extension.vsixmanifest`.
