'use strict';

const vscode = require('vscode');
const fs = require('fs');
const path = require('path');
const os = require('os');
const cp = require('child_process');

const EXT = 'iudevachat';

function cfg() { return vscode.workspace.getConfiguration(EXT); }
function workspaceRoot() { return vscode.workspace.workspaceFolders && vscode.workspace.workspaceFolders[0] ? vscode.workspace.workspaceFolders[0].uri.fsPath : undefined; }
function isWindows() { return process.platform === 'win32'; }

function expandHome(inputPath) {
  if (!inputPath) return inputPath;
  if (inputPath === '~') return os.homedir();
  if (inputPath.startsWith('~/') || inputPath.startsWith('~\\')) return path.join(os.homedir(), inputPath.slice(2));
  return inputPath;
}

function resolvePathMaybeWorkspace(inputPath) {
  const expanded = expandHome(inputPath);
  if (!expanded) return expanded;
  if (path.isAbsolute(expanded)) return expanded;
  const root = workspaceRoot();
  return root ? path.join(root, expanded) : expanded;
}

function ensureDir(dir) { fs.mkdirSync(dir, { recursive: true }); }
function fileExists(file) { try { return fs.existsSync(file); } catch (_) { return false; } }

function shQuote(value) {
  return "'" + String(value).replace(/'/g, "'\\''") + "'";
}

function heredoc(prompt) {
  const marker = 'IUDEVACHAT_PROMPT_' + Date.now().toString(36);
  return `cat <<'${marker}'\n${prompt}\n${marker}`;
}

function findGitBash() {
  const configured = expandHome(cfg().get('gitBashPath'));
  const candidates = [
    configured,
    process.env.GIT_BASH_PATH,
    'C:\\Program Files\\Git\\bin\\bash.exe',
    'C:\\Program Files\\Git\\usr\\bin\\bash.exe',
    'C:\\Program Files (x86)\\Git\\bin\\bash.exe',
    path.join(os.homedir(), 'AppData', 'Local', 'Programs', 'Git', 'bin', 'bash.exe')
  ].filter(Boolean);
  return candidates.find((candidate) => fileExists(candidate));
}

function terminalOptions(name, cwd) {
  const options = { name, cwd: cwd || workspaceRoot() };
  if (isWindows() && cfg().get('usarGitBashNoWindows', true)) {
    const bash = findGitBash();
    if (bash) {
      options.shellPath = bash;
      options.shellArgs = ['--login', '-i'];
    }
  }
  return options;
}

function getTerminal(name) {
  const terminalName = name || cfg().get('nomeTerminal') || 'iuDevaChat';
  const existing = vscode.window.terminals.find((terminal) => terminal.name === terminalName);
  if (existing) return existing;
  return vscode.window.createTerminal(terminalOptions(terminalName, workspaceRoot()));
}

function getDevinInvocation() {
  const devinPath = cfg().get('caminhoDevin') || 'devin';
  const args = cfg().get('argumentosPadrao') || [];
  return [shQuote(devinPath), ...args.map(shQuote)].join(' ');
}

function buildCommand(prompt) {
  const prefix = cfg().get('prefixoPromptPadrao') || '';
  const fullPrompt = [prefix, prompt].filter(Boolean).join('\n\n');
  const mode = cfg().get('modoEnvioPrompt') || 'argumento';
  const base = getDevinInvocation();
  if (mode === 'stdin') return `${heredoc(fullPrompt)} | ${base}`;
  if (mode === 'arquivo-temporario') {
    const tempDir = path.join(os.tmpdir(), 'iudevachat');
    ensureDir(tempDir);
    const file = path.join(tempDir, `prompt-${Date.now()}.md`);
    fs.writeFileSync(file, fullPrompt, 'utf8');
    return `${base} ${shQuote(file)}`;
  }
  return `${base} ${shQuote(fullPrompt)}`;
}

function runPrompt(prompt, terminalName) {
  const terminal = getTerminal(terminalName);
  terminal.show(true);
  terminal.sendText(buildCommand(prompt));
}

function relPath(file) {
  const root = workspaceRoot();
  return root ? path.relative(root, file) : file;
}

function getActiveFileContext(includeContent) {
  const editor = vscode.window.activeTextEditor;
  if (!editor) return undefined;
  const file = relPath(editor.document.uri.fsPath);
  const language = editor.document.languageId;
  const selection = !editor.selection.isEmpty ? editor.document.getText(editor.selection) : '';
  const content = includeContent ? editor.document.getText() : '';
  return { editor, file, language, selection, content };
}

async function openFileEnsuring(file, defaultContent) {
  ensureDir(path.dirname(file));
  if (!fileExists(file)) fs.writeFileSync(file, defaultContent || '', 'utf8');
  await vscode.window.showTextDocument(vscode.Uri.file(file));
}

async function openFolderPath(dir) {
  if (!dir) return;
  ensureDir(dir);
  const uri = vscode.Uri.file(dir);
  await vscode.commands.executeCommand('vscode.openFolder', uri, { forceNewWindow: false });
}

async function askFreePrompt() {
  const prompt = await vscode.window.showInputBox({
    title: 'iuDevaChat: prompt livre',
    prompt: 'Digite a solicitação para o Devin CLI',
    placeHolder: 'Ex.: faça um plano de correção para os testes quebrados neste workspace'
  });
  if (prompt && prompt.trim()) runPrompt(prompt.trim());
}

function promptSelection(kind) {
  const ctx = getActiveFileContext(false);
  if (!ctx || !ctx.selection) {
    vscode.window.showWarningMessage('Selecione um trecho de código antes de acionar o iuDevaChat.');
    return;
  }
  const recipes = {
    explicar: `Explique a seleção abaixo do arquivo ${ctx.file}. Seja objetivo, destaque responsabilidade, dependências, riscos e pontos de atenção.\n\nLinguagem: ${ctx.language}\n\n\`\`\`${ctx.language}\n${ctx.selection}\n\`\`\``,
    revisar: `Revise a seleção abaixo do arquivo ${ctx.file}. Procure bugs, riscos de segurança, problemas de performance, observabilidade, testabilidade e impacto produtivo. Retorne achados acionáveis com severidade.\n\nLinguagem: ${ctx.language}\n\n\`\`\`${ctx.language}\n${ctx.selection}\n\`\`\``,
    testes: `Proponha testes para a seleção abaixo do arquivo ${ctx.file}. Cubra caminhos felizes, bordas, falhas, mocks necessários e dados de teste. Sugira nomes de testes e arquivos prováveis.\n\nLinguagem: ${ctx.language}\n\n\`\`\`${ctx.language}\n${ctx.selection}\n\`\`\``,
    refatorar: `Refatore com segurança a seleção abaixo do arquivo ${ctx.file}. Preserve contrato público, minimize blast radius, proponha passos pequenos e indique testes de regressão.\n\nLinguagem: ${ctx.language}\n\n\`\`\`${ctx.language}\n${ctx.selection}\n\`\`\``
  };
  runPrompt(recipes[kind]);
}

function promptCurrentFile(kind) {
  const ctx = getActiveFileContext(false);
  if (!ctx) {
    vscode.window.showWarningMessage('Abra um arquivo antes de acionar o iuDevaChat.');
    return;
  }
  const recipes = {
    analisar: `Analise o arquivo atual ${ctx.file}. Explique objetivo, hotspots, dependências relevantes, riscos produtivos, lacunas de teste e melhorias seguras.`,
    documentar: `Gere uma proposta de documentação técnica para o arquivo ${ctx.file}. Inclua objetivo, APIs/funções relevantes, exemplos de uso, contratos, riscos e troubleshooting.`,
    corrigir: `Investigue o arquivo ${ctx.file} como candidato a bug. Liste hipóteses, evidências a coletar, comandos de diagnóstico e patch mínimo recomendado.`
  };
  runPrompt(recipes[kind]);
}

function reviewDiff() {
  runPrompt('Revise o git diff atual deste repositório. Foque em bugs, segurança, privacidade, testes, observabilidade, manutenibilidade, compatibilidade e impacto produtivo. Estruture a resposta em: resumo executivo, achados por severidade, arquivos impactados, recomendações e testes obrigatórios. Cite caminhos de arquivos concretos.');
}

function planTask() {
  runPrompt('Faça um plano de execução para a tarefa em contexto neste workspace. Primeiro entenda a arquitetura e o git status. Depois proponha fases, arquivos prováveis, riscos, testes e plano de rollback. Não faça mudanças grandes sem justificar trade-offs.');
}

function runTests() {
  runPrompt('Identifique a stack de testes deste repositório e proponha ou execute o menor conjunto de testes relevante para validar a alteração atual. Explique comandos, cobertura esperada, falhas e próximos passos.');
}

function explainError() {
  runPrompt('Analise o erro mais recente do terminal ou logs disponíveis no workspace. Encontre causa raiz provável, arquivos envolvidos, comandos de diagnóstico e correção mínima segura.');
}

async function openConfig() {
  const root = workspaceRoot();
  const workspaceConfig = root ? path.join(root, '.devin', 'config.json') : undefined;
  const globalConfig = isWindows() ? path.join(process.env.APPDATA || os.homedir(), 'devin', 'config.json') : path.join(os.homedir(), '.config', 'devin', 'config.json');
  const target = workspaceConfig || globalConfig;
  await openFileEnsuring(target, '{\n  "model": "sonnet"\n}\n');
}

async function openRules() {
  const root = workspaceRoot();
  if (!root) {
    vscode.window.showWarningMessage('Abra um workspace antes de criar ou editar AGENTS.md.');
    return;
  }
  const file = path.join(root, 'AGENTS.md');
  const content = `# Instruções do projeto para Devin\n\n## Princípios de engenharia\n\n- Priorize diffs pequenos, reversíveis e fáceis de revisar.\n- Preserve contratos públicos, APIs e compatibilidade retroativa salvo orientação explícita.\n- Antes de refatorações amplas, exponha trade-offs, blast radius e plano de rollback.\n- Para toda mudança, indique testes executados ou recomendados.\n- Sinalize riscos de segurança, privacidade, observabilidade, performance e operação.\n\n## Formato de resposta esperado\n\n1. Resumo executivo\n2. Evidências e arquivos analisados\n3. Plano ou alterações propostas\n4. Riscos e mitigação\n5. Testes e validação\n`; 
  await openFileEnsuring(file, content);
}

async function createWorkspaceAgent(provider) {
  const root = workspaceRoot();
  if (!root) {
    vscode.window.showWarningMessage('Abra um workspace antes de criar um agente Devin.');
    return;
  }
  const name = await vscode.window.showInputBox({ title: 'Novo agente Devin', prompt: 'Nome do agente', placeHolder: 'revisor-seguranca' });
  if (!name) return;
  const safeName = name.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9_-]+/g, '-').replace(/^-|-$/g, '');
  if (!safeName) return;
  const baseDir = resolvePathMaybeWorkspace(cfg().get('diretorioAgentesWorkspace') || '.devin/agents');
  const dir = path.join(baseDir, safeName);
  const file = path.join(dir, 'AGENT.md');
  const title = safeName.replace(/-/g, ' ');
  const content = `---\nname: ${safeName}\ndescription: Agente especializado em ${title}\nmodel: sonnet\nallowed-tools:\n  - read\n  - grep\n  - glob\n  - exec\npermissions:\n  allow:\n    - Exec(git diff)\n    - Exec(git status)\n    - Exec(git log)\n  deny:\n    - write\n    - edit\n---\n\nVocê é o agente ${title}.\n\nDiretrizes operacionais:\n- Seja objetivo, rastreável e orientado a evidências.\n- Cite arquivos, símbolos e comandos concretos.\n- Priorize baixo acoplamento, segurança, observabilidade, testabilidade e impacto operacional.\n- Recomende mudanças pequenas, reversíveis e com testes de regressão.\n`; 
  await openFileEnsuring(file, content);
  provider.refresh();
}

function listAgentsIn(dir, origem) {
  const items = [];
  if (!dir || !fileExists(dir)) {
    const item = new vscode.TreeItem(`${origem}: não encontrado`, vscode.TreeItemCollapsibleState.None);
    item.description = dir || '';
    item.iconPath = new vscode.ThemeIcon('warning');
    return [item];
  }
  const entries = fs.readdirSync(dir, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && fileExists(path.join(dir, entry.name, 'AGENT.md')))
    .map((entry) => entry.name)
    .sort();
  if (!entries.length) {
    const item = new vscode.TreeItem(`${origem}: vazio`, vscode.TreeItemCollapsibleState.None);
    item.description = dir;
    item.iconPath = new vscode.ThemeIcon('circle-slash');
    return [item];
  }
  for (const name of entries) {
    const agentFile = path.join(dir, name, 'AGENT.md');
    const item = new vscode.TreeItem(name, vscode.TreeItemCollapsibleState.None);
    item.description = origem;
    item.tooltip = agentFile;
    item.iconPath = new vscode.ThemeIcon('hubot');
    item.command = { command: 'vscode.open', title: 'Abrir agente', arguments: [vscode.Uri.file(agentFile)] };
    items.push(item);
  }
  return items;
}

class AgentsProvider {
  constructor() { this._onDidChangeTreeData = new vscode.EventEmitter(); this.onDidChangeTreeData = this._onDidChangeTreeData.event; }
  refresh() { this._onDidChangeTreeData.fire(); }
  getTreeItem(element) { return element; }
  getChildren(element) {
    if (element) return [];
    const workspaceDir = resolvePathMaybeWorkspace(cfg().get('diretorioAgentesWorkspace') || '.devin/agents');
    const globalDir = resolvePathMaybeWorkspace(cfg().get('diretorioAgentesGlobal') || '~/.config/devin/agents');
    return [...listAgentsIn(workspaceDir, 'Workspace'), ...listAgentsIn(globalDir, 'Global')];
  }
}

class ChatPanelProvider {
  resolveWebviewView(webviewView) {
    webviewView.webview.options = { enableScripts: true };
    webviewView.webview.html = this.html();
    webviewView.webview.onDidReceiveMessage((message) => {
      if (!message || !message.command) return;
      const map = {
        start: 'iudevachat.iniciarSessao',
        prompt: 'iudevachat.promptLivre',
        diff: 'iudevachat.revisarDiff',
        plan: 'iudevachat.planejarTarefa',
        tests: 'iudevachat.rodarTestes',
        error: 'iudevachat.explicarErro',
        selectionReview: 'iudevachat.revisarSelecao',
        selectionTests: 'iudevachat.gerarTestesSelecao'
      };
      if (message.command === 'sendPrompt') {
        const prompt = String(message.prompt || '').trim();
        if (prompt) runPrompt(prompt);
        return;
      }
      const command = map[message.command];
      if (command) vscode.commands.executeCommand(command);
    });
  }
  html() {
    const nonce = Date.now().toString(36);
    return `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-${nonce}';"><meta name="viewport" content="width=device-width, initial-scale=1.0"><style>
      body{font-family:var(--vscode-font-family);padding:12px;color:var(--vscode-foreground)}
      h2{font-size:16px;margin:0 0 6px}.hint{color:var(--vscode-descriptionForeground);font-size:12px;line-height:1.45;margin-bottom:12px}
      textarea{width:100%;min-height:132px;box-sizing:border-box;background:var(--vscode-input-background);color:var(--vscode-input-foreground);border:1px solid var(--vscode-input-border);padding:8px;border-radius:4px}
      button{width:100%;margin-top:8px;padding:8px;background:var(--vscode-button-background);color:var(--vscode-button-foreground);border:0;border-radius:4px;cursor:pointer}
      button.secondary{background:var(--vscode-button-secondaryBackground);color:var(--vscode-button-secondaryForeground)}
      .grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}.grid button{margin-top:0}.section{margin-top:14px;font-size:11px;text-transform:uppercase;color:var(--vscode-descriptionForeground);letter-spacing:.04em}
    </style></head><body>
      <h2>iuDevaChat</h2><div class="hint">Cockpit Devin CLI para fluxo agentic dentro do VS Code. Usa terminal integrado e Git Bash no Windows quando disponível.</div>
      <textarea id="prompt" placeholder="Ex.: analise o impacto da mudança atual e proponha um plano de rollout seguro"></textarea>
      <button id="send">Enviar para Devin</button>
      <div class="section">Ações rápidas</div><div class="grid">
        <button class="secondary" data-cmd="start">Sessão</button><button class="secondary" data-cmd="diff">Revisar diff</button>
        <button class="secondary" data-cmd="plan">Planejar</button><button class="secondary" data-cmd="tests">Testes</button>
        <button class="secondary" data-cmd="error">Erro/log</button><button class="secondary" data-cmd="selectionReview">Revisar seleção</button>
      </div>
      <script nonce="${nonce}">const vscode=acquireVsCodeApi();document.getElementById('send').addEventListener('click',()=>vscode.postMessage({command:'sendPrompt',prompt:document.getElementById('prompt').value}));document.querySelectorAll('[data-cmd]').forEach(b=>b.addEventListener('click',()=>vscode.postMessage({command:b.dataset.cmd})));</script>
    </body></html>`;
  }
}

function createStatusBar(context) {
  const item = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 80);
  item.text = '$(hubot) iuDevaChat';
  item.tooltip = 'Iniciar sessão Devin CLI';
  item.command = 'iudevachat.iniciarSessao';
  item.show();
  context.subscriptions.push(item);
}

function iniciarSessao() {
  const terminal = getTerminal();
  terminal.show(true);
  terminal.sendText(getDevinInvocation());
}

function checkCli() {
  const devinPath = cfg().get('caminhoDevin') || 'devin';
  const command = `command -v ${shQuote(devinPath)} && ${shQuote(devinPath)} --version || true`;
  if (isWindows() && cfg().get('usarGitBashNoWindows', true)) {
    const bash = findGitBash();
    if (!bash) {
      vscode.window.showErrorMessage('Git Bash não encontrado. Configure iudevachat.gitBashPath ou instale Git for Windows.');
      return;
    }
    cp.execFile(bash, ['-lc', command], (err, stdout, stderr) => {
      const out = String(stdout || stderr || '').trim();
      if (err || !out) vscode.window.showErrorMessage(`Devin CLI não encontrado via Git Bash: ${devinPath}`);
      else vscode.window.showInformationMessage(`Devin CLI detectado: ${out.split('\n')[0]}`);
    });
    return;
  }
  cp.exec(command, { shell: '/bin/bash' }, (err, stdout, stderr) => {
    const out = String(stdout || stderr || '').trim();
    if (err || !out) vscode.window.showErrorMessage(`Devin CLI não encontrado: ${devinPath}`);
    else vscode.window.showInformationMessage(`Devin CLI detectado: ${out.split('\n')[0]}`);
  });
}

function register(context, command, fn) { context.subscriptions.push(vscode.commands.registerCommand(command, fn)); }

function activate(context) {
  const agentsProvider = new AgentsProvider();
  context.subscriptions.push(vscode.window.registerTreeDataProvider('iudevachat.agentesView', agentsProvider));
  context.subscriptions.push(vscode.window.registerWebviewViewProvider('iudevachat.chatPanel', new ChatPanelProvider()));
  createStatusBar(context);

  register(context, 'iudevachat.iniciarSessao', iniciarSessao);
  register(context, 'iudevachat.promptLivre', askFreePrompt);
  register(context, 'iudevachat.explicarSelecao', () => promptSelection('explicar'));
  register(context, 'iudevachat.revisarSelecao', () => promptSelection('revisar'));
  register(context, 'iudevachat.gerarTestesSelecao', () => promptSelection('testes'));
  register(context, 'iudevachat.refatorarSelecao', () => promptSelection('refatorar'));
  register(context, 'iudevachat.analisarArquivo', () => promptCurrentFile('analisar'));
  register(context, 'iudevachat.documentarArquivo', () => promptCurrentFile('documentar'));
  register(context, 'iudevachat.investigarArquivo', () => promptCurrentFile('corrigir'));
  register(context, 'iudevachat.revisarDiff', reviewDiff);
  register(context, 'iudevachat.planejarTarefa', planTask);
  register(context, 'iudevachat.rodarTestes', runTests);
  register(context, 'iudevachat.explicarErro', explainError);
  register(context, 'iudevachat.abrirConfig', openConfig);
  register(context, 'iudevachat.abrirRegras', openRules);
  register(context, 'iudevachat.abrirAgentesWorkspace', () => {
    if (!workspaceRoot()) return vscode.window.showWarningMessage('Abra um workspace primeiro.');
    openFolderPath(resolvePathMaybeWorkspace(cfg().get('diretorioAgentesWorkspace') || '.devin/agents'));
  });
  register(context, 'iudevachat.abrirAgentesGlobal', () => openFolderPath(resolvePathMaybeWorkspace(cfg().get('diretorioAgentesGlobal') || '~/.config/devin/agents')));
  register(context, 'iudevachat.criarAgenteWorkspace', () => createWorkspaceAgent(agentsProvider));
  register(context, 'iudevachat.atualizarAgentes', () => agentsProvider.refresh());
  register(context, 'iudevachat.verificarCli', checkCli);
}

function deactivate() {}

module.exports = { activate, deactivate };
