# Changelog

## 0.3.0

- Adicionado participante no Chat nativo do VS Code: `@iudevachat`.
- Adicionados slash commands: `/review`, `/plan`, `/test`, `/explain`, `/fix` e `/session`.
- Adicionado seletor de modelos Devin.
- Adicionado seletor de agentes Devin.
- A sessão Devin agora é iniciada explicitamente no diretório da pasta aberta no VS Code.
- Painel lateral atualizado com seleção de modelo, seleção de agente e abertura do Chat nativo.
- Status Bar passa a mostrar modelo e agente ativos.
- Adicionadas configurações `argumentoModelo`, `argumentoAgente`, `timeoutChatMs` e `chatNativoUsaTerminalQuandoPossivel`.

## 0.2.0

- Interface, configuração e documentação em português brasileiro.
- Desenvolvedor definido como Itaú Unibanco.
- Suporte a Git Bash em Windows com PowerShell desabilitado.
- Activity Bar, painel lateral, agentes, regras e comandos de revisão.
