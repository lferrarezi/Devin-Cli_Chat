# iuDevaChat

Extensão VS Code para uso do **Devin CLI** em português brasileiro, com experiência integrada ao fluxo de chat e ao workspace aberto.

Desenvolvedor: **Itaú Unibanco**  
Publisher técnico: `itau-unibanco`

## Principais recursos

- Participante no Chat nativo do VS Code: `@iudevachat`.
- Comandos slash no Chat:
  - `/review` para revisar o `git diff`.
  - `/plan` para planejar uma tarefa.
  - `/test` para identificar/rodar testes relevantes.
  - `/explain` para explicar seleção ou arquivo atual.
  - `/fix` para diagnosticar erro, log ou bug.
  - `/session` para abrir uma sessão interativa no terminal integrado.
- Seletor de modelo Devin.
- Seletor de agente Devin, lendo agentes do workspace e globais.
- Sessão Devin já iniciada no diretório da pasta aberta no VS Code.
- Painel lateral com prompt, modelo, agente e ações rápidas.
- Activity Bar própria.
- Menu de contexto no editor para explicar, revisar, gerar testes ou refatorar seleção.
- Integração com SCM para revisão de diff.
- Compatibilidade com máquinas Windows corporativas sem PowerShell, usando Git Bash.

## Uso no Chat nativo

Abra o Chat do VS Code e use:

```text
@iudevachat revise o impacto da mudança atual
```

Ou use comandos slash:

```text
@iudevachat /review
@iudevachat /plan implementar cache resiliente para esta API
@iudevachat /test
@iudevachat /explain
@iudevachat /fix erro de timeout no log atual
@iudevachat /session
```

O participante usa o workspace aberto como diretório de execução do Devin CLI.

## Seleção de modelos

A lista de modelos aparece no painel lateral e no comando:

```text
iuDevaChat: Selecionar modelo Devin
```

Configure os modelos liberados no ambiente:

```json
{
  "iudevachat.modelosDisponiveis": ["sonnet", "opus", "haiku"],
  "iudevachat.modeloAtual": "sonnet",
  "iudevachat.argumentoModelo": "--model"
}
```

Se o Devin CLI do ambiente não aceitar modelo via argumento, deixe o argumento vazio:

```json
{
  "iudevachat.argumentoModelo": ""
}
```

Nesse caso, o modelo continua sendo enviado no contexto do prompt.

## Seleção de agentes

A extensão detecta agentes em:

```text
.devin/agents/<nome>/AGENT.md
~/.config/devin/agents/<nome>/AGENT.md
```

Use:

```text
iuDevaChat: Selecionar agente Devin
```

Ou selecione pelo painel lateral. O valor `auto` não fixa agente.

Configurações:

```json
{
  "iudevachat.agenteAtual": "auto",
  "iudevachat.argumentoAgente": "",
  "iudevachat.diretorioAgentesWorkspace": ".devin/agents",
  "iudevachat.diretorioAgentesGlobal": "~/.config/devin/agents"
}
```

Por padrão, `argumentoAgente` vem vazio porque o suporte a agente por argumento depende da versão/configuração do Devin CLI. Quando vazio, o agente selecionado é enviado como instrução contextual no prompt.

## Sessão integrada no workspace

O comando abaixo abre o terminal integrado já no diretório da pasta aberta no VS Code:

```text
iuDevaChat: Iniciar sessão Devin no workspace
```

Também é possível usar no Chat:

```text
@iudevachat /session
```

## Windows corporativo sem PowerShell

A extensão não depende de PowerShell. Em Windows, ela tenta usar Git Bash automaticamente.

Configuração recomendada:

```json
{
  "iudevachat.usarGitBashNoWindows": true,
  "iudevachat.gitBashPath": "C:\\Program Files\\Git\\bin\\bash.exe"
}
```

Se `gitBashPath` estiver vazio, a extensão tenta autodetectar instalações comuns do Git for Windows.

## Configurações principais

```json
{
  "iudevachat.caminhoDevin": "devin",
  "iudevachat.argumentosPadrao": [],
  "iudevachat.modelosDisponiveis": ["sonnet", "opus", "haiku"],
  "iudevachat.modeloAtual": "sonnet",
  "iudevachat.argumentoModelo": "--model",
  "iudevachat.agenteAtual": "auto",
  "iudevachat.argumentoAgente": "",
  "iudevachat.modoEnvioPrompt": "argumento",
  "iudevachat.nomeTerminal": "iuDevaChat",
  "iudevachat.usarGitBashNoWindows": true,
  "iudevachat.gitBashPath": "",
  "iudevachat.diretorioAgentesGlobal": "~/.config/devin/agents",
  "iudevachat.diretorioAgentesWorkspace": ".devin/agents",
  "iudevachat.prefixoPromptPadrao": "Responda em português brasileiro. Seja objetivo, cite arquivos concretos e priorize impacto produtivo, segurança, testes e rollback.",
  "iudevachat.timeoutChatMs": 300000,
  "iudevachat.chatNativoUsaTerminalQuandoPossivel": false
}
```

## Observação operacional

A integração de Chat nativo executa o Devin CLI de forma não interativa e transmite a saída para o Chat. Se o Devin CLI do ambiente operar apenas em modo interativo, use `/session` ou habilite:

```json
{
  "iudevachat.chatNativoUsaTerminalQuandoPossivel": true
}
```

Nesse modo, o Chat vira o ponto de entrada e a execução roda no terminal integrado.
