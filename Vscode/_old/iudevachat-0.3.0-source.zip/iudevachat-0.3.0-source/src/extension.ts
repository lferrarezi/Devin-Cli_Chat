'use strict';

const vscode = require('vscode');
const fs = require('fs');
const path = require('path');
const os = require('os');
const cp = require('child_process');

const EXT = 'iudevachat';
let statusBar;
let chatPanelProvider;
let agentsProvider;

function cfg() { return vscode.workspace.getConfiguration(EXT); }
function workspaceRoot() { return vscode.workspace.workspaceFolders && vscode.workspace.workspaceFolders[0] ? vscode.workspace.workspaceFolders[0].uri.fsPath : undefined; }
function workspaceName() { return vscode.workspace.workspaceFolders && vscode.workspace.workspaceFolders[0] ? vscode.workspace.workspaceFolders[0].name : 'sem workspace'; }
function isWindows() { return process.platform === 'win32'; }
function getConfigValue(key, fallback) { const value = cfg().get(key); return value === undefined || value === null || value === '' ? fallback : value; }

function expandHome(inputPath) {
  if (!inputPath) return inputPath;
  if (inputPath === '~') return os.homedir();
  if (inputPath.startsWith('~/') || inputPath.startsWith('~\\')) return path.join(os.homedir(), inputPath.slice(2));
  return inputPath;
}

function resolvePathMaybeWorkspace(inputPath) {
  const expanded = expandHome(inputPath);
  if (!expanded) return expanded;
  if (path.isAbsolute(expanded)) return expanded;
  const root = workspaceRoot();
  return root ? path.join(root, expanded) : expanded;
}

function ensureDir(dir) { fs.mkdirSync(dir, { recursive: true }); }
function fileExists(file) { try { return fs.existsSync(file); } catch (_) { return false; } }
function shQuote(value) { return "'" + String(value).replace(/'/g, "'\\''") + "'"; }

function heredoc(prompt) {
  const marker = 'IUDEVACHAT_PROMPT_' + Date.now().toString(36);
  return `cat <<'${marker}'\n${prompt}\n${marker}`;
}

function findGitBash() {
  const configured = expandHome(cfg().get('gitBashPath'));
  const candidates = [
    configured,
    process.env.GIT_BASH_PATH,
    'C:\\Program Files\\Git\\bin\\bash.exe',
    'C:\\Program Files\\Git\\usr\\bin\\bash.exe',
    'C:\\Program Files (x86)\\Git\\bin\\bash.exe',
    path.join(os.homedir(), 'AppData', 'Local', 'Programs', 'Git', 'bin', 'bash.exe')
  ].filter(Boolean);
  return candidates.find((candidate) => fileExists(candidate));
}

function terminalOptions(name, cwd) {
  const options = { name, cwd: cwd || workspaceRoot() || os.homedir() };
  if (isWindows() && cfg().get('usarGitBashNoWindows', true)) {
    const bash = findGitBash();
    if (bash) {
      options.shellPath = bash;
      options.shellArgs = ['--login', '-i'];
    }
  }
  return options;
}

function getTerminal(name) {
  const terminalName = name || cfg().get('nomeTerminal') || 'iuDevaChat';
  const existing = vscode.window.terminals.find((terminal) => terminal.name === terminalName);
  if (existing) return existing;
  return vscode.window.createTerminal(terminalOptions(terminalName, workspaceRoot()));
}

function selectedModel() { return String(getConfigValue('modeloAtual', 'sonnet')); }
function selectedAgent() { return String(getConfigValue('agenteAtual', 'auto')); }
function availableModels() {
  const models = cfg().get('modelosDisponiveis') || ['sonnet', 'opus', 'haiku'];
  return Array.from(new Set(models.map(String).filter(Boolean)));
}

function getDevinArgs() {
  const args = [];
  const defaultArgs = cfg().get('argumentosPadrao') || [];
  args.push(...defaultArgs.map(String).filter(Boolean));
  const modelArg = String(cfg().get('argumentoModelo') || '').trim();
  const model = selectedModel();
  if (modelArg && model) args.push(modelArg, model);
  const agentArg = String(cfg().get('argumentoAgente') || '').trim();
  const agent = selectedAgent();
  if (agentArg && agent && agent !== 'auto') args.push(agentArg, agent);
  return args;
}

function getDevinInvocation() {
  const devinPath = cfg().get('caminhoDevin') || 'devin';
  return [shQuote(devinPath), ...getDevinArgs().map(shQuote)].join(' ');
}

function buildPrompt(prompt) {
  const prefix = cfg().get('prefixoPromptPadrao') || '';
  const model = selectedModel();
  const agent = selectedAgent();
  const root = workspaceRoot();
  const context = [
    `Workspace VS Code: ${workspaceName()}`,
    root ? `Diretório raiz: ${root}` : 'Diretório raiz: não há pasta aberta no VS Code',
    model ? `Modelo selecionado: ${model}` : '',
    agent && agent !== 'auto' ? `Agente selecionado: ${agent}. Use esse perfil/agente quando aplicável.` : 'Agente selecionado: auto'
  ].filter(Boolean).join('\n');
  return [prefix, context, prompt].filter(Boolean).join('\n\n');
}

function buildCommand(prompt) {
  const fullPrompt = buildPrompt(prompt);
  const mode = cfg().get('modoEnvioPrompt') || 'argumento';
  const base = getDevinInvocation();
  if (mode === 'stdin') return `${heredoc(fullPrompt)} | ${base}`;
  if (mode === 'arquivo-temporario') {
    const tempDir = path.join(os.tmpdir(), 'iudevachat');
    ensureDir(tempDir);
    const file = path.join(tempDir, `prompt-${Date.now()}.md`);
    fs.writeFileSync(file, fullPrompt, 'utf8');
    return `${base} ${shQuote(file)}`;
  }
  return `${base} ${shQuote(fullPrompt)}`;
}

function runPrompt(prompt, terminalName) {
  const terminal = getTerminal(terminalName);
  terminal.show(true);
  terminal.sendText(buildCommand(prompt));
}

function relPath(file) {
  const root = workspaceRoot();
  return root ? path.relative(root, file) : file;
}

function getActiveFileContext(includeContent) {
  const editor = vscode.window.activeTextEditor;
  if (!editor) return undefined;
  const file = relPath(editor.document.uri.fsPath);
  const language = editor.document.languageId;
  const selection = !editor.selection.isEmpty ? editor.document.getText(editor.selection) : '';
  const content = includeContent ? editor.document.getText() : '';
  return { editor, file, language, selection, content };
}

async function openFileEnsuring(file, defaultContent) {
  ensureDir(path.dirname(file));
  if (!fileExists(file)) fs.writeFileSync(file, defaultContent || '', 'utf8');
  await vscode.window.showTextDocument(vscode.Uri.file(file));
}

async function openFolderPath(dir) {
  if (!dir) return;
  ensureDir(dir);
  const uri = vscode.Uri.file(dir);
  await vscode.commands.executeCommand('vscode.openFolder', uri, { forceNewWindow: false });
}

function agentDirs() {
  return [
    { origem: 'Workspace', dir: resolvePathMaybeWorkspace(cfg().get('diretorioAgentesWorkspace') || '.devin/agents') },
    { origem: 'Global', dir: resolvePathMaybeWorkspace(cfg().get('diretorioAgentesGlobal') || '~/.config/devin/agents') }
  ];
}

function listAgentRecords() {
  const records = [{ name: 'auto', label: 'Auto', origem: 'Padrão', file: '' }];
  for (const entry of agentDirs()) {
    if (!entry.dir || !fileExists(entry.dir)) continue;
    const dirs = fs.readdirSync(entry.dir, { withFileTypes: true })
      .filter((dirent) => dirent.isDirectory() && fileExists(path.join(entry.dir, dirent.name, 'AGENT.md')))
      .map((dirent) => dirent.name)
      .sort();
    for (const name of dirs) records.push({ name, label: name, origem: entry.origem, file: path.join(entry.dir, name, 'AGENT.md') });
  }
  return records;
}

function updateStatusBar() {
  if (!statusBar) return;
  statusBar.text = `$(hubot) iuDevaChat: ${selectedModel()} / ${selectedAgent()}`;
  statusBar.tooltip = `Workspace: ${workspaceName()}\nModelo: ${selectedModel()}\nAgente: ${selectedAgent()}\nClique para abrir o chat nativo.`;
}

async function updateSetting(key, value) {
  await cfg().update(key, value, vscode.ConfigurationTarget.Workspace);
  updateStatusBar();
  if (chatPanelProvider) chatPanelProvider.postState();
  if (agentsProvider) agentsProvider.refresh();
}

async function selecionarModelo() {
  const current = selectedModel();
  const pick = await vscode.window.showQuickPick(availableModels().map((model) => ({ label: model, picked: model === current })), {
    title: 'iuDevaChat: selecionar modelo Devin',
    placeHolder: 'Escolha o modelo liberado no ambiente'
  });
  if (pick) await updateSetting('modeloAtual', pick.label);
}

async function selecionarAgente() {
  const current = selectedAgent();
  const pick = await vscode.window.showQuickPick(listAgentRecords().map((agent) => ({ label: agent.name, description: agent.origem, detail: agent.file, picked: agent.name === current })), {
    title: 'iuDevaChat: selecionar agente Devin',
    placeHolder: 'Escolha auto ou um agente localizado no workspace/global'
  });
  if (pick) await updateSetting('agenteAtual', pick.label);
}

async function askFreePrompt() {
  const prompt = await vscode.window.showInputBox({
    title: 'iuDevaChat: prompt livre',
    prompt: 'Digite a solicitação para o Devin CLI',
    placeHolder: 'Ex.: faça um plano de correção para os testes quebrados neste workspace'
  });
  if (prompt && prompt.trim()) runPrompt(prompt.trim());
}

function promptSelection(kind) {
  const ctx = getActiveFileContext(false);
  if (!ctx || !ctx.selection) {
    vscode.window.showWarningMessage('Selecione um trecho de código antes de acionar o iuDevaChat.');
    return;
  }
  const recipes = {
    explicar: `Explique a seleção abaixo do arquivo ${ctx.file}. Seja objetivo, destaque responsabilidade, dependências, riscos e pontos de atenção.\n\nLinguagem: ${ctx.language}\n\n\`\`\`${ctx.language}\n${ctx.selection}\n\`\`\``,
    revisar: `Revise a seleção abaixo do arquivo ${ctx.file}. Procure bugs, riscos de segurança, problemas de performance, observabilidade, testabilidade e impacto produtivo. Retorne achados acionáveis com severidade.\n\nLinguagem: ${ctx.language}\n\n\`\`\`${ctx.language}\n${ctx.selection}\n\`\`\``,
    testes: `Proponha testes para a seleção abaixo do arquivo ${ctx.file}. Cubra caminhos felizes, bordas, falhas, mocks necessários e dados de teste. Sugira nomes de testes e arquivos prováveis.\n\nLinguagem: ${ctx.language}\n\n\`\`\`${ctx.language}\n${ctx.selection}\n\`\`\``,
    refatorar: `Refatore com segurança a seleção abaixo do arquivo ${ctx.file}. Preserve contrato público, minimize blast radius, proponha passos pequenos e indique testes de regressão.\n\nLinguagem: ${ctx.language}\n\n\`\`\`${ctx.language}\n${ctx.selection}\n\`\`\``
  };
  runPrompt(recipes[kind]);
}

function promptCurrentFile(kind) {
  const ctx = getActiveFileContext(false);
  if (!ctx) {
    vscode.window.showWarningMessage('Abra um arquivo antes de acionar o iuDevaChat.');
    return;
  }
  const recipes = {
    analisar: `Analise o arquivo atual ${ctx.file}. Explique objetivo, hotspots, dependências relevantes, riscos produtivos, lacunas de teste e melhorias seguras.`,
    documentar: `Gere uma proposta de documentação técnica para o arquivo ${ctx.file}. Inclua objetivo, APIs/funções relevantes, exemplos de uso, contratos, riscos e troubleshooting.`,
    corrigir: `Investigue o arquivo ${ctx.file} como candidato a bug. Liste hipóteses, evidências a coletar, comandos de diagnóstico e patch mínimo recomendado.`
  };
  runPrompt(recipes[kind]);
}

function reviewDiff() {
  runPrompt('Revise o git diff atual deste repositório. Foque em bugs, segurança, privacidade, testes, observabilidade, manutenibilidade, compatibilidade e impacto produtivo. Estruture a resposta em: resumo executivo, achados por severidade, arquivos impactados, recomendações e testes obrigatórios. Cite caminhos de arquivos concretos.');
}

function planTask() {
  runPrompt('Faça um plano de execução para a tarefa em contexto neste workspace. Primeiro entenda a arquitetura e o git status. Depois proponha fases, arquivos prováveis, riscos, testes e plano de rollback. Não faça mudanças grandes sem justificar trade-offs.');
}

function runTests() {
  runPrompt('Identifique a stack de testes deste repositório e proponha ou execute o menor conjunto de testes relevante para validar a alteração atual. Explique comandos, cobertura esperada, falhas e próximos passos.');
}

function explainError() {
  runPrompt('Analise o erro mais recente do terminal ou logs disponíveis no workspace. Encontre causa raiz provável, arquivos envolvidos, comandos de diagnóstico e correção mínima segura.');
}

async function openConfig() {
  const root = workspaceRoot();
  const workspaceConfig = root ? path.join(root, '.devin', 'config.json') : undefined;
  const globalConfig = isWindows() ? path.join(process.env.APPDATA || os.homedir(), 'devin', 'config.json') : path.join(os.homedir(), '.config', 'devin', 'config.json');
  const target = workspaceConfig || globalConfig;
  await openFileEnsuring(target, '{\n  "model": "sonnet"\n}\n');
}

async function openRules() {
  const root = workspaceRoot();
  if (!root) {
    vscode.window.showWarningMessage('Abra um workspace antes de criar ou editar AGENTS.md.');
    return;
  }
  const file = path.join(root, 'AGENTS.md');
  const content = `# Instruções do projeto para Devin\n\n## Princípios de engenharia\n\n- Priorize diffs pequenos, reversíveis e fáceis de revisar.\n- Preserve contratos públicos, APIs e compatibilidade retroativa salvo orientação explícita.\n- Antes de refatorações amplas, exponha trade-offs, blast radius e plano de rollback.\n- Para toda mudança, indique testes executados ou recomendados.\n- Sinalize riscos de segurança, privacidade, observabilidade, performance e operação.\n\n## Formato de resposta esperado\n\n1. Resumo executivo\n2. Evidências e arquivos analisados\n3. Plano ou alterações propostas\n4. Riscos e mitigação\n5. Testes e validação\n`;
  await openFileEnsuring(file, content);
}

async function createWorkspaceAgent(provider) {
  const root = workspaceRoot();
  if (!root) {
    vscode.window.showWarningMessage('Abra um workspace antes de criar um agente Devin.');
    return;
  }
  const name = await vscode.window.showInputBox({ title: 'Novo agente Devin', prompt: 'Nome do agente', placeHolder: 'revisor-seguranca' });
  if (!name) return;
  const safeName = name.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9_-]+/g, '-').replace(/^-|-$/g, '');
  if (!safeName) return;
  const baseDir = resolvePathMaybeWorkspace(cfg().get('diretorioAgentesWorkspace') || '.devin/agents');
  const dir = path.join(baseDir, safeName);
  const file = path.join(dir, 'AGENT.md');
  const title = safeName.replace(/-/g, ' ');
  const content = `---\nname: ${safeName}\ndescription: Agente especializado em ${title}\nmodel: ${selectedModel()}\nallowed-tools:\n  - read\n  - grep\n  - glob\n  - exec\npermissions:\n  allow:\n    - Exec(git diff)\n    - Exec(git status)\n    - Exec(git log)\n  deny:\n    - write\n    - edit\n---\n\nVocê é o agente ${title}.\n\nDiretrizes operacionais:\n- Seja objetivo, rastreável e orientado a evidências.\n- Cite arquivos, símbolos e comandos concretos.\n- Priorize baixo acoplamento, segurança, observabilidade, testabilidade e impacto operacional.\n- Recomende mudanças pequenas, reversíveis e com testes de regressão.\n`;
  await openFileEnsuring(file, content);
  provider.refresh();
}

function listAgentsIn(dir, origem) {
  const items = [];
  if (!dir || !fileExists(dir)) {
    const item = new vscode.TreeItem(`${origem}: não encontrado`, vscode.TreeItemCollapsibleState.None);
    item.description = dir || '';
    item.iconPath = new vscode.ThemeIcon('warning');
    return [item];
  }
  const entries = fs.readdirSync(dir, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && fileExists(path.join(dir, entry.name, 'AGENT.md')))
    .map((entry) => entry.name)
    .sort();
  if (!entries.length) {
    const item = new vscode.TreeItem(`${origem}: vazio`, vscode.TreeItemCollapsibleState.None);
    item.description = dir;
    item.iconPath = new vscode.ThemeIcon('circle-slash');
    return [item];
  }
  for (const name of entries) {
    const agentFile = path.join(dir, name, 'AGENT.md');
    const item = new vscode.TreeItem(name, vscode.TreeItemCollapsibleState.None);
    item.description = origem + (name === selectedAgent() ? ' • ativo' : '');
    item.tooltip = agentFile;
    item.iconPath = new vscode.ThemeIcon(name === selectedAgent() ? 'check' : 'hubot');
    item.command = { command: 'vscode.open', title: 'Abrir agente', arguments: [vscode.Uri.file(agentFile)] };
    items.push(item);
  }
  return items;
}

class AgentsProvider {
  constructor() { this._onDidChangeTreeData = new vscode.EventEmitter(); this.onDidChangeTreeData = this._onDidChangeTreeData.event; }
  refresh() { this._onDidChangeTreeData.fire(); }
  getTreeItem(element) { return element; }
  getChildren(element) {
    if (element) return [];
    return agentDirs().flatMap((entry) => listAgentsIn(entry.dir, entry.origem));
  }
}

class ChatPanelProvider {
  constructor() { this.view = undefined; }
  resolveWebviewView(webviewView) {
    this.view = webviewView;
    webviewView.webview.options = { enableScripts: true };
    webviewView.webview.html = this.html();
    webviewView.webview.onDidReceiveMessage(async (message) => {
      if (!message || !message.command) return;
      const map = {
        openChat: 'iudevachat.abrirChat',
        start: 'iudevachat.iniciarSessao',
        prompt: 'iudevachat.promptLivre',
        diff: 'iudevachat.revisarDiff',
        plan: 'iudevachat.planejarTarefa',
        tests: 'iudevachat.rodarTestes',
        error: 'iudevachat.explicarErro',
        selectionReview: 'iudevachat.revisarSelecao',
        selectionTests: 'iudevachat.gerarTestesSelecao',
        modelPicker: 'iudevachat.selecionarModelo',
        agentPicker: 'iudevachat.selecionarAgente'
      };
      if (message.command === 'ready') { this.postState(); return; }
      if (message.command === 'sendPrompt') {
        const prompt = String(message.prompt || '').trim();
        if (prompt) runPrompt(prompt);
        return;
      }
      if (message.command === 'setModel') { await updateSetting('modeloAtual', String(message.value || 'sonnet')); return; }
      if (message.command === 'setAgent') { await updateSetting('agenteAtual', String(message.value || 'auto')); return; }
      const command = map[message.command];
      if (command) vscode.commands.executeCommand(command);
    });
  }
  postState() {
    if (!this.view) return;
    this.view.webview.postMessage({
      command: 'state',
      workspace: workspaceName(),
      workspacePath: workspaceRoot() || '',
      model: selectedModel(),
      models: availableModels(),
      agent: selectedAgent(),
      agents: listAgentRecords().map((a) => ({ name: a.name, origem: a.origem }))
    });
  }
  html() {
    const nonce = Date.now().toString(36);
    return `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-${nonce}';"><meta name="viewport" content="width=device-width, initial-scale=1.0"><style>
      body{font-family:var(--vscode-font-family);padding:12px;color:var(--vscode-foreground)}
      h2{font-size:16px;margin:0 0 6px}.hint{color:var(--vscode-descriptionForeground);font-size:12px;line-height:1.45;margin-bottom:12px}.meta{font-size:11px;color:var(--vscode-descriptionForeground);margin-bottom:8px;word-break:break-all}
      label{display:block;font-size:11px;text-transform:uppercase;color:var(--vscode-descriptionForeground);letter-spacing:.04em;margin:10px 0 4px}select,textarea{width:100%;box-sizing:border-box;background:var(--vscode-input-background);color:var(--vscode-input-foreground);border:1px solid var(--vscode-input-border);padding:7px;border-radius:4px}textarea{min-height:132px}
      button{width:100%;margin-top:8px;padding:8px;background:var(--vscode-button-background);color:var(--vscode-button-foreground);border:0;border-radius:4px;cursor:pointer}
      button.secondary{background:var(--vscode-button-secondaryBackground);color:var(--vscode-button-secondaryForeground)}
      .grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}.grid button{margin-top:0}.section{margin-top:14px;font-size:11px;text-transform:uppercase;color:var(--vscode-descriptionForeground);letter-spacing:.04em}.row{display:grid;grid-template-columns:1fr auto;gap:6px}.row button{margin-top:0;padding:7px 8px}
    </style></head><body>
      <h2>iuDevaChat</h2><div class="hint">Chat Devin CLI no workspace aberto. Selecione modelo e agente antes de iniciar a sessão ou enviar prompts.</div>
      <div class="meta" id="workspace">Workspace: carregando...</div>
      <label for="model">Modelo Devin</label><div class="row"><select id="model"></select><button class="secondary" id="modelPicker" title="Selecionar via Quick Pick">...</button></div>
      <label for="agent">Agente Devin</label><div class="row"><select id="agent"></select><button class="secondary" id="agentPicker" title="Selecionar via Quick Pick">...</button></div>
      <label for="prompt">Prompt</label><textarea id="prompt" placeholder="Ex.: analise o impacto da mudança atual e proponha um plano de rollout seguro"></textarea>
      <button id="send">Enviar para Devin no terminal</button>
      <button class="secondary" data-cmd="openChat">Abrir @iudevachat no Chat nativo</button>
      <div class="section">Ações rápidas</div><div class="grid">
        <button class="secondary" data-cmd="start">Sessão</button><button class="secondary" data-cmd="diff">Revisar diff</button>
        <button class="secondary" data-cmd="plan">Planejar</button><button class="secondary" data-cmd="tests">Testes</button>
        <button class="secondary" data-cmd="error">Erro/log</button><button class="secondary" data-cmd="selectionReview">Revisar seleção</button>
      </div>
      <script nonce="${nonce}">const vscode=acquireVsCodeApi();const model=document.getElementById('model');const agent=document.getElementById('agent');function fill(sel,items,current,fmt){sel.innerHTML='';items.forEach(x=>{const o=document.createElement('option');o.value=x.name||x;o.textContent=fmt?fmt(x):(x.name||x);o.selected=o.value===current;sel.appendChild(o);});}window.addEventListener('message',e=>{const m=e.data;if(m.command==='state'){document.getElementById('workspace').textContent='Workspace: '+m.workspace+(m.workspacePath?' • '+m.workspacePath:'');fill(model,m.models,m.model);fill(agent,m.agents,m.agent,x=>x.name+(x.origem?' • '+x.origem:''));}});model.addEventListener('change',()=>vscode.postMessage({command:'setModel',value:model.value}));agent.addEventListener('change',()=>vscode.postMessage({command:'setAgent',value:agent.value}));document.getElementById('modelPicker').addEventListener('click',()=>vscode.postMessage({command:'modelPicker'}));document.getElementById('agentPicker').addEventListener('click',()=>vscode.postMessage({command:'agentPicker'}));document.getElementById('send').addEventListener('click',()=>vscode.postMessage({command:'sendPrompt',prompt:document.getElementById('prompt').value}));document.querySelectorAll('[data-cmd]').forEach(b=>b.addEventListener('click',()=>vscode.postMessage({command:b.dataset.cmd})));vscode.postMessage({command:'ready'});</script>
    </body></html>`;
  }
}

function createStatusBar(context) {
  statusBar = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 80);
  statusBar.command = 'iudevachat.abrirChat';
  statusBar.show();
  context.subscriptions.push(statusBar);
  updateStatusBar();
}

async function abrirChat() {
  await vscode.commands.executeCommand('workbench.panel.chat.view.copilot.focus').then(undefined, async () => {
    await vscode.commands.executeCommand('workbench.action.chat.open').then(undefined, () => {});
  });
  await vscode.commands.executeCommand('workbench.action.chat.open', '@iudevachat ' ).then(undefined, () => {});
}

function iniciarSessao() {
  const root = workspaceRoot();
  if (!root) {
    vscode.window.showWarningMessage('Abra uma pasta no VS Code para iniciar o Devin com contexto de workspace.');
    return;
  }
  const terminal = getTerminal();
  terminal.show(true);
  terminal.sendText(getDevinInvocation());
}

function shellSpawn(command, cwd, onData, token) {
  return new Promise((resolve) => {
    const timeoutMs = Number(cfg().get('timeoutChatMs') || 300000);
    let child;
    let stdout = '';
    let stderr = '';
    const done = (code, signal, timedOut) => resolve({ code, signal, stdout, stderr, timedOut });
    if (isWindows() && cfg().get('usarGitBashNoWindows', true)) {
      const bash = findGitBash();
      if (!bash) return done(-1, undefined, false);
      child = cp.spawn(bash, ['-lc', command], { cwd, windowsHide: true });
    } else {
      child = cp.spawn('/bin/bash', ['-lc', command], { cwd });
    }
    const timer = setTimeout(() => { try { child.kill(); } catch (_) {} done(-1, 'timeout', true); }, timeoutMs);
    if (token) token.onCancellationRequested(() => { try { child.kill(); } catch (_) {} });
    child.stdout.on('data', (data) => { const text = data.toString(); stdout += text; if (onData) onData(text, false); });
    child.stderr.on('data', (data) => { const text = data.toString(); stderr += text; if (onData) onData(text, true); });
    child.on('error', (err) => { clearTimeout(timer); stderr += String(err.message || err); done(-1, undefined, false); });
    child.on('close', (code, signal) => { clearTimeout(timer); done(code, signal, false); });
  });
}

function chatPromptFromRequest(request) {
  const ctx = getActiveFileContext(false);
  const command = request.command || '';
  if (command === 'review') return 'Revise o git diff atual deste repositório. Cite arquivos concretos, severidade, riscos e testes obrigatórios.';
  if (command === 'plan') return `Planeje a tarefa a seguir no workspace atual. Inclua fases, arquivos prováveis, riscos, testes e rollback.\n\nTarefa: ${request.prompt || '(sem detalhe)'}`;
  if (command === 'test') return `Identifique e proponha/executar os testes relevantes para a solicitação abaixo.\n\nSolicitação: ${request.prompt || '(sem detalhe)'}`;
  if (command === 'fix') return `Investigue e proponha correção mínima segura para o erro/bug/log abaixo.\n\nContexto: ${request.prompt || '(usar workspace e terminal como contexto)'}`;
  if (command === 'explain') {
    if (ctx && ctx.selection) return `Explique a seleção atual no arquivo ${ctx.file}.\n\n\`\`\`${ctx.language}\n${ctx.selection}\n\`\`\`\n\nPedido adicional: ${request.prompt || '(sem detalhe)'}`;
    if (ctx) return `Explique o arquivo atual ${ctx.file}. Pedido adicional: ${request.prompt || '(sem detalhe)'}`;
  }
  if (command === 'session') return '__IUDEVACHAT_OPEN_TERMINAL__';
  return request.prompt || '';
}

async function registerChatParticipant(context) {
  if (!vscode.chat || !vscode.chat.createChatParticipant) return;
  const handler = async (request, chatContext, stream, token) => {
    const root = workspaceRoot();
    const prompt = chatPromptFromRequest(request);
    if (prompt === '__IUDEVACHAT_OPEN_TERMINAL__' || cfg().get('chatNativoUsaTerminalQuandoPossivel', false)) {
      iniciarSessao();
      stream.markdown(`Sessão Devin aberta no terminal integrado.\n\n- Workspace: \`${workspaceName()}\`\n- Modelo: \`${selectedModel()}\`\n- Agente: \`${selectedAgent()}\``);
      return {};
    }
    if (!root) {
      stream.markdown('Abra uma pasta no VS Code para usar o iuDevaChat com contexto de workspace.');
      return {};
    }
    if (!prompt.trim()) {
      stream.markdown('Envie um prompt ou use um comando slash, como `/review`, `/plan`, `/test`, `/explain`, `/fix` ou `/session`.');
      return {};
    }
    stream.progress(`Executando Devin CLI em ${workspaceName()} com modelo ${selectedModel()} e agente ${selectedAgent()}...`);
    stream.markdown(`**Contexto ativo**\n\n- Workspace: \`${workspaceName()}\`\n- Modelo Devin: \`${selectedModel()}\`\n- Agente Devin: \`${selectedAgent()}\`\n\n`);
    const command = buildCommand(prompt);
    let emitted = 0;
    const result = await shellSpawn(command, root, (chunk, isErr) => {
      emitted += chunk.length;
      const safe = chunk.replace(/```/g, '``\\`');
      if (safe.trim()) stream.markdown(isErr ? `\n\n_erro/stdout:_\n\n\`\`\`text\n${safe}\n\`\`\`\n` : safe);
    }, token);
    if (result.timedOut) stream.markdown(`\n\nExecução interrompida por timeout (${cfg().get('timeoutChatMs')} ms). Ajuste \`iudevachat.timeoutChatMs\` ou use /session para sessão interativa.`);
    else if (result.code && result.code !== 0) stream.markdown(`\n\nDevin CLI finalizou com código ${result.code}. Verifique autenticação, argumentos de modelo/agente ou use \`iuDevaChat: Verificar Devin CLI\`.`);
    else if (!emitted) stream.markdown('Devin CLI não retornou saída para o chat nativo. Use `/session` ou ative o modo terminal em `iudevachat.chatNativoUsaTerminalQuandoPossivel`.');
    return { metadata: { command: request.command || 'prompt', model: selectedModel(), agent: selectedAgent() } };
  };
  const participant = vscode.chat.createChatParticipant('iudevachat.devin', handler);
  participant.iconPath = vscode.Uri.joinPath(context.extensionUri, 'media', 'iudevachat.svg');
  participant.followupProvider = {
    provideFollowups() {
      return [
        { prompt: '/review', label: 'Revisar diff', command: 'review' },
        { prompt: '/plan implementar a próxima mudança com baixo risco', label: 'Planejar tarefa', command: 'plan' },
        { prompt: '/test', label: 'Validar testes', command: 'test' },
        { prompt: '/session', label: 'Abrir sessão terminal', command: 'session' }
      ];
    }
  };
  context.subscriptions.push(participant);
}

function checkCli() {
  const devinPath = cfg().get('caminhoDevin') || 'devin';
  const command = `command -v ${shQuote(devinPath)} && ${shQuote(devinPath)} --version || true`;
  if (isWindows() && cfg().get('usarGitBashNoWindows', true)) {
    const bash = findGitBash();
    if (!bash) {
      vscode.window.showErrorMessage('Git Bash não encontrado. Configure iudevachat.gitBashPath ou instale Git for Windows.');
      return;
    }
    cp.execFile(bash, ['-lc', command], (err, stdout, stderr) => {
      const out = String(stdout || stderr || '').trim();
      if (err || !out) vscode.window.showErrorMessage(`Devin CLI não encontrado via Git Bash: ${devinPath}`);
      else vscode.window.showInformationMessage(`Devin CLI detectado: ${out.split('\n')[0]}`);
    });
    return;
  }
  cp.exec(command, { shell: '/bin/bash' }, (err, stdout, stderr) => {
    const out = String(stdout || stderr || '').trim();
    if (err || !out) vscode.window.showErrorMessage(`Devin CLI não encontrado: ${devinPath}`);
    else vscode.window.showInformationMessage(`Devin CLI detectado: ${out.split('\n')[0]}`);
  });
}

function register(context, command, fn) { context.subscriptions.push(vscode.commands.registerCommand(command, fn)); }

function activate(context) {
  agentsProvider = new AgentsProvider();
  chatPanelProvider = new ChatPanelProvider();
  context.subscriptions.push(vscode.window.registerTreeDataProvider('iudevachat.agentesView', agentsProvider));
  context.subscriptions.push(vscode.window.registerWebviewViewProvider('iudevachat.chatPanel', chatPanelProvider));
  createStatusBar(context);
  registerChatParticipant(context);

  register(context, 'iudevachat.abrirChat', abrirChat);
  register(context, 'iudevachat.iniciarSessao', iniciarSessao);
  register(context, 'iudevachat.selecionarModelo', selecionarModelo);
  register(context, 'iudevachat.selecionarAgente', selecionarAgente);
  register(context, 'iudevachat.promptLivre', askFreePrompt);
  register(context, 'iudevachat.explicarSelecao', () => promptSelection('explicar'));
  register(context, 'iudevachat.revisarSelecao', () => promptSelection('revisar'));
  register(context, 'iudevachat.gerarTestesSelecao', () => promptSelection('testes'));
  register(context, 'iudevachat.refatorarSelecao', () => promptSelection('refatorar'));
  register(context, 'iudevachat.analisarArquivo', () => promptCurrentFile('analisar'));
  register(context, 'iudevachat.documentarArquivo', () => promptCurrentFile('documentar'));
  register(context, 'iudevachat.investigarArquivo', () => promptCurrentFile('corrigir'));
  register(context, 'iudevachat.revisarDiff', reviewDiff);
  register(context, 'iudevachat.planejarTarefa', planTask);
  register(context, 'iudevachat.rodarTestes', runTests);
  register(context, 'iudevachat.explicarErro', explainError);
  register(context, 'iudevachat.abrirConfig', openConfig);
  register(context, 'iudevachat.abrirRegras', openRules);
  register(context, 'iudevachat.abrirAgentesWorkspace', () => {
    if (!workspaceRoot()) return vscode.window.showWarningMessage('Abra um workspace primeiro.');
    openFolderPath(resolvePathMaybeWorkspace(cfg().get('diretorioAgentesWorkspace') || '.devin/agents'));
  });
  register(context, 'iudevachat.abrirAgentesGlobal', () => openFolderPath(resolvePathMaybeWorkspace(cfg().get('diretorioAgentesGlobal') || '~/.config/devin/agents')));
  register(context, 'iudevachat.criarAgenteWorkspace', () => createWorkspaceAgent(agentsProvider));
  register(context, 'iudevachat.atualizarAgentes', () => agentsProvider.refresh());
  register(context, 'iudevachat.verificarCli', checkCli);
  context.subscriptions.push(vscode.workspace.onDidChangeConfiguration((event) => {
    if (event.affectsConfiguration(EXT)) { updateStatusBar(); agentsProvider.refresh(); chatPanelProvider.postState(); }
  }));
}

function deactivate() {}

module.exports = { activate, deactivate };
