# Changelog

## 0.4.0

- Adicionado painel lateral de chat com UX integrada.
- Adicionados seletores persistentes de modelo e agente no topo do painel.
- Adicionada execução ancorada automaticamente na pasta aberta no VS Code.
- Adicionados botões rápidos para contexto do editor, revisão de diff e sessão interativa.
- Mantida integração com `@iudevachat` no Chat nativo do VS Code.
- Mantido suporte a Git Bash para ambientes Windows sem PowerShell.

## 0.3.0

- Adicionada integração com Chat nativo do VS Code.
- Adicionada seleção de modelos e agentes.

## 0.2.0

- Localização para português brasileiro.
- Desenvolvedor definido como Itaú Unibanco.
- Adicionado suporte a Git Bash.

## 0.1.0

- MVP com comandos e terminal integrado.
