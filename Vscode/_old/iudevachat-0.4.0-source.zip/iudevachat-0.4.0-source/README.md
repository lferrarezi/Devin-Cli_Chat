# iuDevaChat

Extensão VS Code para uso do Devin CLI em uma experiência de chat integrada, em português brasileiro, desenvolvida para distribuição interna do Itaú Unibanco.

## Objetivo

A extensão aproxima a experiência do Devin CLI do padrão de uso de extensões agentic modernas no VS Code: painel lateral de chat, seleção de modelo, seleção de agente, comandos rápidos, contexto do editor e execução sempre ancorada na pasta aberta no VS Code.

> Observação: a interface não copia marcas, assets ou implementação proprietária de outras extensões. Ela reproduz o padrão operacional esperado: painel lateral, composer, seletor de modelo, seletor de agente e integração com workspace.

## Funcionalidades

- Painel lateral `iuDevaChat > Chat` com interface integrada.
- Seleção de modelo disponível no topo do painel.
- Seleção de agente disponível no topo do painel.
- Sessão Devin iniciada no diretório da pasta aberta no VS Code.
- Botões rápidos:
  - `Contexto do editor`
  - `Revisar diff`
  - `Sessão`
- Participante de chat nativo `@iudevachat` com comandos:
  - `/review`
  - `/plan`
  - `/fix`
  - `/test`
  - `/session`
- Menu de contexto no editor para enviar seleção ao chat.
- Integração com SCM para revisão de diff.
- Compatibilidade com Windows corporativo sem PowerShell, usando Git Bash quando disponível.

## Instalação

```bash
code --install-extension iudevachat-0.4.0.vsix
```

## Uso

Abra uma pasta no VS Code e clique no ícone `iuDevaChat` na Activity Bar.

No painel:

1. Selecione o modelo.
2. Selecione o agente.
3. Digite o prompt.
4. Envie com `Enviar` ou `Ctrl+Enter`.

Para abrir uma sessão interativa no terminal:

```text
iuDevaChat: Nova sessão Devin no workspace
```

No Chat nativo do VS Code:

```text
@iudevachat /review
```

```text
@iudevachat /plan implementar cache resiliente para esta camada
```

## Configurações

```json
{
  "iudevachat.caminhoDevin": "devin",
  "iudevachat.argumentosPadrao": [],
  "iudevachat.modelosDisponiveis": ["sonnet", "opus", "haiku"],
  "iudevachat.modeloAtual": "sonnet",
  "iudevachat.argumentoModelo": "--model",
  "iudevachat.agenteAtual": "auto",
  "iudevachat.argumentoAgente": "",
  "iudevachat.diretorioAgentesWorkspace": ".devin/agents",
  "iudevachat.diretorioAgentesGlobal": "~/.config/devin/agents",
  "iudevachat.modoExecucaoChat": "resposta-integrada",
  "iudevachat.modoEnvioPrompt": "argumento",
  "iudevachat.timeoutChatMs": 300000,
  "iudevachat.usarGitBashNoWindows": true,
  "iudevachat.gitBashPath": ""
}
```

## Git Bash no Windows

Nas máquinas Windows em que PowerShell estiver desabilitado, mantenha:

```json
{
  "iudevachat.usarGitBashNoWindows": true
}
```

A extensão tenta localizar o Git Bash nos caminhos padrão. Caso necessário, configure:

```json
{
  "iudevachat.gitBashPath": "C:\\Program Files\\Git\\bin\\bash.exe"
}
```

## Agentes

A extensão procura agentes Devin em:

```text
.devin/agents/<nome>/AGENT.md
~/.config/devin/agents/<nome>/AGENT.md
```

O seletor sempre inclui `auto`.

## Modos de execução

### resposta-integrada

Executa o Devin CLI de forma não interativa e renderiza a resposta no painel de chat.

### terminal

Abre o Devin CLI no terminal integrado, no workspace atual. Use este modo se a instalação do Devin CLI for estritamente interativa.
