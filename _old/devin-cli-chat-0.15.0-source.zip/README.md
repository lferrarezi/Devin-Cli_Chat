# Devin Cli Chat

Extensao VS Code para usar o Devin CLI em uma tela propria de chat, com execucao ancorada na pasta aberta no VS Code.

## Experiencia 0.14.0

- Tela propria na Activity Bar, sem depender da tela nativa Chat do VS Code.
- Layout redesenhado no padrao de paineis modernos de agentes de codigo: conversa central, composer inferior, seletores no composer e acoes rapidas.
- Seletor de modelo no composer, preenchido automaticamente a partir do Devin CLI local quando possivel.
- Seletor de agente no composer, lendo `.devin/agents/<agente>/AGENT.md` e agentes globais.
- Execucao local no workspace aberto.
- Suporte a Windows corporativo sem PowerShell, usando Git Bash quando necessario.

## Identidade visual

- Icone da extensao atualizado a partir da imagem fornecida.
- A lista de extensoes usa `media/devin-cli-chat.png`.
- A Activity Bar usa `media/devin-cli-chat-activity.svg`, versao vetorial derivada do mesmo desenho para melhor compatibilidade com o VS Code.

## Uso

1. Instale o VSIX.
2. Abra uma pasta no VS Code.
3. Abra a Activity Bar `Devin Cli Chat`.
4. Selecione modelo e agente no composer inferior.
5. Envie o prompt.

## Instalacao limpa recomendada

Se voce instalou as versoes antigas `iuDevaChat`, remova-as para evitar que o participante antigo continue aparecendo na tela Chat nativa do VS Code.

```bash
code --uninstall-extension luiz-ferrarezi.iudevachat
code --uninstall-extension itau-unibanco.iudevachat
code --uninstall-extension luiz-alberto-abarca-ferrarezi.iudevachat
code --install-extension devin-cli-chat-0.14.0.vsix --force
```

## Configuracoes principais

```json
{
  "devinCliChat.caminhoDevin": "devin",
  "devinCliChat.modeloAtual": "auto",
  "devinCliChat.agenteAtual": "auto",
  "devinCliChat.modoExecucaoChat": "resposta-integrada",
  "devinCliChat.descobrirModelosAutomaticamente": true,
  "devinCliChat.usarGitBashNoWindows": true,
  "devinCliChat.timeoutDescobertaModelosMs": 3000,
  "devinCliChat.timeoutTotalDescobertaModelosMs": 7000,
  "devinCliChat.arquivosCacheModelos": [],
  "devinCliChat.limiteBytesCacheModelos": 5242880
}
```

## Descoberta automatica de modelos

A extensao agora prioriza leitura local e nao inicia processos do Devin CLI por padrao. No Windows, ela usa o modelo atual em `%APPDATA%\devin\config.json`, especialmente `agent.model`, e tenta montar a lista a partir de `%LOCALAPPDATA%\Devin\CLI\model_configs.bin` e `%LOCALAPPDATA%\Devin\CLI\team_settings.bin`.

Os arquivos `.bin` sao tratados apenas como cache de leitura. A extensao nao edita esses arquivos. Para alterar o modelo, use o seletor da extensao, o `agent.model` no `config.json` do Devin ou o comando/configuracao oficial do Devin CLI.

## Desenvolvedor

Luiz Alberto Abarca Ferrarezi


## 0.13.0

Correção de estabilidade: a seleção de modelos não inicia mais `devin acp` por padrão. O seletor usa `auto`, cache, configuração local e `devinCliChat.modelosDisponiveis`. A consulta externa ao CLI ficou opt-in via `devinCliChat.comandoDescobertaModelos` ou `devinCliChat.usarAcpParaDescobertaModelos`. Layout e ícone foram preservados.

## 0.14.0

- Mantido layout e icone da versao anterior.
- Detecção de modelos passou a usar leitura local de `%APPDATA%\devin\config.json` para o modelo atual.
- Lista de modelos passa a ser extraida, de forma somente leitura, dos caches `%LOCALAPPDATA%\Devin\CLI\model_configs.bin` e `%LOCALAPPDATA%\Devin\CLI\team_settings.bin`.
- Nenhum processo do Devin CLI e iniciado por padrao para descobrir modelos.


## Leitura dos modelos

A extensao nao edita os caches binarios do Devin. Ela usa leitura local em modo somente leitura. No Windows, os caminhos padrao sao:

- `%APPDATA%\devin\config.json`: modelo atual em `agent.model`;
- `%LOCALAPPDATA%\Devin\CLI\model_configs.bin`: catalogo de modelos, com id no field protobuf 22 e nome amigavel no field 1 de cada registro;
- `%LOCALAPPDATA%\Devin\CLI\team_settings.bin`: allowlist/cache de equipe, com modelos nos fields protobuf 7 e 26.
