# Changelog

## 0.6.0

- Nome exibido alterado para **Devin Cli Chat**.
- Removida a integração com a tela nativa `Chat` do VS Code.
- Mantida uma tela própria na Activity Bar com seletor de modelo e seletor de agente.
- Mantida a execução no workspace aberto no VS Code.
- Mantido desenvolvedor **Luiz Ferrarezi**.

## 0.5.0

- Correção da chamada integrada com `devin -p -- <prompt>`.
- Desenvolvedor alterado para Luiz Ferrarezi.
