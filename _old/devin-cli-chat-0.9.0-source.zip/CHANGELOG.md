# Changelog

## 0.9.0

- Adicionada descoberta automatica de modelos a partir do Devin CLI local, priorizando `devin acp` e `configOptions`.
- Adicionado botao para atualizar modelos no painel de chat.
- Adicionado comando `Devin Cli Chat: Atualizar modelos do Devin CLI`.
- Alterado `devinCliChat.modelosDisponiveis` para ser apenas fallback manual, evitando lista estatica divergente.
- Adicionadas configuracoes `devinCliChat.descobrirModelosAutomaticamente`, `devinCliChat.comandoDescobertaModelos`, `devinCliChat.timeoutDescobertaModelosMs` e `devinCliChat.cacheModelosMs`.

## 0.8.0

- Ajustada lista padrao de modelos.
- Adicionado fallback `auto`.
