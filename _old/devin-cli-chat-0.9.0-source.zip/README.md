# Devin Cli Chat

Extensao VS Code para usar o Devin CLI em uma tela propria de chat, com interface em portugues brasileiro.

## Principais recursos

- Chat proprio na Activity Bar, sem depender da tela nativa de Chat do VS Code.
- Execucao no workspace/pasta aberta no VS Code.
- Selecao de agente a partir de `.devin/agents/<nome>/AGENT.md` e do diretorio global do Devin.
- Descoberta automatica de modelos a partir do Devin CLI local.
- Botao para atualizar modelos no seletor.
- Fallback para modelo `auto`, que nao envia `--model` e deixa o Devin CLI aplicar o padrao autorizado.
- Compatibilidade com Windows corporativo sem PowerShell, usando Git Bash quando necessario.

## Descoberta automatica de modelos

A extensao tenta consultar o Devin CLI local usando ACP primeiro, pois o `devin acp` expõe opcoes de configuracao de sessao, incluindo modelos quando disponivel. Se ACP nao retornar modelos, ela usa uma sequencia de estrategias:

1. `devin acp` com `initialize` + `session/new` e leitura de `configOptions`
2. `devin models --format json`
2. `devin models --json`
3. `devin models`
4. `devin model list --format json`
5. `devin model list --json`
6. `devin model list`
7. `devin --list-models`
8. `devin --models`
9. probe com modelo invalido para capturar mensagens de validacao/allowlist
11. `devin --help` como fallback de baixa confianca

Quando a descoberta funciona, o seletor usa a lista detectada no seu ambiente local. Isso evita divergencia entre a extensao e a allowlist enterprise disponivel no terminal.

## Configuracoes relevantes

```json
{
  "devinCliChat.caminhoDevin": "devin",
  "devinCliChat.descobrirModelosAutomaticamente": true,
  "devinCliChat.comandoDescobertaModelos": "",
  "devinCliChat.timeoutDescobertaModelosMs": 15000,
  "devinCliChat.cacheModelosMs": 1800000,
  "devinCliChat.modeloAtual": "auto",
  "devinCliChat.modelosDisponiveis": []
}
```

Se o seu Devin CLI tiver um comando especifico para listar modelos, configure `devinCliChat.comandoDescobertaModelos`, por exemplo:

```json
{
  "devinCliChat.comandoDescobertaModelos": "models --json"
}
```

## Uso

1. Instale o VSIX.
2. Abra uma pasta no VS Code.
3. Abra a Activity Bar `Devin Cli Chat`.
4. Aguarde a descoberta de modelos ou clique em `R`.
5. Selecione modelo e agente.
6. Envie o prompt.

## Instalacao

```bash
code --install-extension devin-cli-chat-0.9.0.vsix --force
```
