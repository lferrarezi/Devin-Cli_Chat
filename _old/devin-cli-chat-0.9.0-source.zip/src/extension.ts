'use strict';
const vscode = require('vscode');
const fs = require('fs');
const path = require('path');
const os = require('os');
const cp = require('child_process');

const EXT = 'devinCliChat';
const CACHE_KEY = 'devinCliChat.modelosDetectados.v2';
const FALLBACK_MODELS = ['auto'];
const KNOWN_MODEL_HINTS = new Set(['opus','sonnet','swe','codex','gemini','auto']);

let provider;
let status;
let extensionContext;
let modelDiscovery = {
  status: 'idle',
  detail: 'Aguardando descoberta automatica de modelos.',
  source: 'inicial',
  models: []
};
let modelDiscoveryPromise;

function cfg(){ return vscode.workspace.getConfiguration(EXT); }
function root(){ return vscode.workspace.workspaceFolders && vscode.workspace.workspaceFolders[0] ? vscode.workspace.workspaceFolders[0].uri.fsPath : undefined; }
function rootName(){ return vscode.workspace.workspaceFolders && vscode.workspace.workspaceFolders[0] ? vscode.workspace.workspaceFolders[0].name : 'sem pasta aberta'; }
function home(p){ if(!p) return p; const s=String(p); return s === '~' ? os.homedir() : (s.startsWith('~/') || s.startsWith('~\\')) ? path.join(os.homedir(), s.slice(2)) : s; }
function absMaybe(p){ const v = home(p); if(!v) return v; return path.isAbsolute(v) ? v : path.join(root() || os.homedir(), v); }
function exists(p){ try { return !!p && fs.existsSync(p); } catch { return false; } }
function quote(s){ return `'${String(s).replace(/'/g, `'\\''`)}'`; }
function normalizeModel(m){ const value = String(m || '').trim(); if(!value || value === 'default' || value === 'padrao') return 'auto'; return value; }
function model(){ return normalizeModel(cfg().get('modeloAtual') || 'auto'); }
function modelForCli(){ const m = model(); return m === 'auto' ? undefined : m; }
function agent(){ return cfg().get('agenteAtual') || 'auto'; }
function devinPath(){ return cfg().get('caminhoDevin') || 'devin'; }
function findGitBash(){
  const c = [
    home(cfg().get('gitBashPath')),
    process.env.GIT_BASH_PATH,
    'C:\\Program Files\\Git\\bin\\bash.exe',
    'C:\\Program Files\\Git\\usr\\bin\\bash.exe',
    'C:\\Program Files (x86)\\Git\\bin\\bash.exe',
    path.join(os.homedir(),'AppData','Local','Programs','Git','bin','bash.exe')
  ].filter(Boolean);
  return c.find(exists);
}
function terminalShell(){ if(process.platform === 'win32' && cfg().get('usarGitBashNoWindows', true)){ return findGitBash(); } return process.env.SHELL || undefined; }
function manualModels(){ const configured = cfg().get('modelosDisponiveis'); return Array.isArray(configured) ? configured.map(String).map(s=>s.trim()).filter(Boolean) : []; }
function models(){
  const detected = Array.isArray(modelDiscovery.models) ? modelDiscovery.models : [];
  let list = detected.length ? detected : manualModels();
  if(!list.length) list = FALLBACK_MODELS;
  const out = ['auto', ...list];
  const current = model();
  if(current && !out.includes(current)) out.unshift(current);
  return Array.from(new Set(out.filter(Boolean)));
}
function modelSourceLabel(){
  if(modelDiscovery.status === 'loading') return 'detectando modelos no Devin CLI...';
  if(modelDiscovery.models && modelDiscovery.models.length) return `modelos detectados via ${modelDiscovery.source}`;
  if(manualModels().length) return 'usando fallback manual em devinCliChat.modelosDisponiveis';
  return modelDiscovery.detail || 'sem modelos detectados; usando auto';
}
function baseArgs(){ const out = [...(cfg().get('argumentosPadrao') || []).map(String).filter(Boolean)]; const ma = String(cfg().get('argumentoModelo') || '').trim(); const m = modelForCli(); if(ma && m) out.push(ma, m); return out; }
function fullPrompt(text){ const prefix = cfg().get('prefixoPromptPadrao') || ''; const selectedModel = modelForCli() || 'auto (padrao do Devin CLI)'; const ctx = [
  `Workspace VS Code: ${rootName()}`,
  root()?`Diretorio raiz: ${root()}`:'Diretorio raiz: nao ha pasta aberta',
  `Modelo selecionado: ${selectedModel}`,
  agent() !== 'auto' ? `Agente selecionado: ${agent()}` : 'Agente selecionado: auto'
].join('\n');
const agentHint = agent() !== 'auto' ? `Use o perfil/subagente Devin chamado "${agent()}" quando aplicavel. Se a CLI nao aceitar selecao direta de agente nesta chamada, trate este agente como persona operacional e siga as instrucoes do respectivo AGENT.md.` : '';
return [prefix, ctx, agentHint, text].filter(Boolean).join('\n\n'); }
function terminalCommand(text){ const args = baseArgs().map(quote).join(' '); const exe = quote(devinPath()); if(!text) return [exe, args].filter(Boolean).join(' '); return [exe, args, '--', quote(fullPrompt(text))].filter(Boolean).join(' '); }
function openTerminal(text){ const sh = terminalShell(); const t = vscode.window.createTerminal({ name:(cfg().get('nomeTerminal') || 'Devin Cli Chat'), cwd: root() || os.homedir(), shellPath: sh, shellArgs: process.platform==='win32' && sh?['--login','-i']:undefined }); t.show(true); t.sendText(terminalCommand(text)); }
function runIntegrated(text){ return new Promise((resolve)=>{ const args = [...baseArgs(), '-p', '--', fullPrompt(text)]; const child = cp.execFile(devinPath(), args, { cwd: root() || os.homedir(), timeout: cfg().get('timeoutChatMs') || 300000, maxBuffer: 1024*1024*16, windowsHide: true }, (err, stdout, stderr)=>{
    if(err && process.platform === 'win32'){
      runIntegratedViaBash(text, err).then(resolve); return;
    }
    const pieces=[]; if(stdout) pieces.push(stdout.trim()); if(stderr) pieces.push('STDERR:\n'+stderr.trim()); if(err) pieces.push(`Falha ao executar Devin CLI: ${err.message}`); resolve(pieces.join('\n\n') || 'Sem saida do Devin CLI.');
  });
  child.on('error', (err)=>resolve(`Falha ao iniciar Devin CLI: ${err.message}\n\nValide o caminho em devinCliChat.caminhoDevin e execute "Devin Cli Chat: Verificar Devin CLI".`));
}); }
function runIntegratedViaBash(text, firstError){ return new Promise((resolve)=>{ const sh = findGitBash(); if(!sh){ resolve(`Falha ao executar Devin CLI: ${firstError.message}\n\nGit Bash nao foi encontrado. Configure devinCliChat.gitBashPath ou ajuste devinCliChat.caminhoDevin.`); return; } const cmd = `${quote(devinPath())} ${baseArgs().map(quote).join(' ')} -p -- ${quote(fullPrompt(text))}`; cp.exec(cmd, { cwd: root() || os.homedir(), shell: sh, timeout: cfg().get('timeoutChatMs') || 300000, maxBuffer: 1024*1024*16 }, (err, stdout, stderr)=>{ const pieces=[]; if(stdout) pieces.push(stdout.trim()); if(stderr) pieces.push('STDERR:\n'+stderr.trim()); if(err) pieces.push(`Falha ao executar Devin CLI via Git Bash: ${err.message}`); resolve(pieces.join('\n\n') || 'Sem saida do Devin CLI.'); }); }); }
async function setConfig(k,v){ await cfg().update(k,v,vscode.ConfigurationTarget.Workspace); updateStatus(); provider && provider.refreshMeta(); }
function globalAgentsPath(){ const configured = cfg().get('diretorioAgentesGlobal'); if(process.platform === 'win32' && (!configured || configured === '~/.config/devin/agents')){ return path.join(process.env.APPDATA || path.join(os.homedir(),'AppData','Roaming'), 'devin', 'agents'); } return absMaybe(configured); }
function scanAgents(){ const dirs = [absMaybe(cfg().get('diretorioAgentesWorkspace')), globalAgentsPath()]; const out = ['auto']; for(const d of dirs){ try{ if(!d || !fs.existsSync(d)) continue; for(const name of fs.readdirSync(d)){ const p = path.join(d,name,'AGENT.md'); if(fs.existsSync(p)) out.push(name); } }catch{} } return Array.from(new Set(out)); }
function activeContext(){ const ed = vscode.window.activeTextEditor; if(!ed) return 'Nenhum editor ativo.'; const doc = ed.document; const sel = ed.selection && !ed.selection.isEmpty ? doc.getText(ed.selection) : doc.getText(); return [`Arquivo: ${doc.uri.fsPath}`, 'Conteudo:', '```', sel.slice(0,60000), '```'].join('\n'); }
function gitDiff(){ try{ return cp.execFileSync('git',['diff','--no-ext-diff'],{cwd:root()||os.homedir(),encoding:'utf8',maxBuffer:1024*1024*8}); }catch(e){ return `Nao foi possivel obter git diff: ${e.message}`; } }
function updateStatus(){ if(!status){ status = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 90); status.command='devinCliChat.abrirPainel'; status.show(); } const selectedModel = modelForCli() || 'auto'; status.text = `Devin Cli Chat: ${selectedModel} / ${agent()}`; status.tooltip = `Workspace: ${rootName()}\n${modelSourceLabel()}`; }

function shellSplit(input){
  const out=[]; let cur=''; let quoteChar=null; let esc=false;
  for(const ch of String(input||'')){
    if(esc){ cur += ch; esc=false; continue; }
    if(ch === '\\'){ esc=true; continue; }
    if(quoteChar){ if(ch === quoteChar) quoteChar=null; else cur += ch; continue; }
    if(ch === '"' || ch === "'"){ quoteChar=ch; continue; }
    if(/\s/.test(ch)){ if(cur){ out.push(cur); cur=''; } continue; }
    cur += ch;
  }
  if(cur) out.push(cur);
  return out;
}
function discoveryCommands(){
  const custom = shellSplit(cfg().get('comandoDescobertaModelos') || '');
  const commands = [];
  if(custom.length) commands.push({source:`devin ${custom.join(' ')}`, args:custom, trust:'high'});
  commands.push(
    {source:'devin models --format json', args:['models','--format','json'], trust:'high'},
    {source:'devin models --json', args:['models','--json'], trust:'high'},
    {source:'devin models', args:['models'], trust:'high'},
    {source:'devin model list --format json', args:['model','list','--format','json'], trust:'high'},
    {source:'devin model list --json', args:['model','list','--json'], trust:'high'},
    {source:'devin model list', args:['model','list'], trust:'high'},
    {source:'devin --list-models', args:['--list-models'], trust:'high'},
    {source:'devin --models', args:['--models'], trust:'high'},
    {source:'invalid-model probe', args:['--model','__devin_cli_chat_model_probe__','-p','--','ok'], trust:'medium'},
    {source:'devin --help', args:['--help'], trust:'low'}
  );
  return commands;
}
function execDevin(args){
  return new Promise((resolve)=>{
    let done=false;
    const finish=(result)=>{ if(done) return; done=true; resolve(result); };
    const opts = { cwd: root() || os.homedir(), timeout: cfg().get('timeoutDescobertaModelosMs') || 15000, maxBuffer: 1024*1024*4, windowsHide: true };
    const child = cp.execFile(devinPath(), args, opts, (err, stdout, stderr)=>{
      if(err && process.platform === 'win32'){
        execDevinViaBash(args).then(finish); return;
      }
      finish({ err, stdout: stdout || '', stderr: stderr || '' });
    });
    child.on('error', (err)=>{
      if(process.platform === 'win32') execDevinViaBash(args).then(finish);
      else finish({err, stdout:'', stderr:''});
    });
  });
}
function execDevinViaBash(args){
  return new Promise((resolve)=>{
    const sh = findGitBash();
    if(!sh){ resolve({err:new Error('Git Bash nao encontrado'), stdout:'', stderr:''}); return; }
    const cmd = `${quote(devinPath())} ${args.map(quote).join(' ')}`;
    cp.exec(cmd, { cwd: root() || os.homedir(), shell: sh, timeout: cfg().get('timeoutDescobertaModelosMs') || 15000, maxBuffer: 1024*1024*4 }, (err, stdout, stderr)=>resolve({err, stdout:stdout||'', stderr:stderr||''}));
  });
}

function spawnAcpProcess(){
  try{
    return cp.spawn(devinPath(), ['acp'], { cwd: root() || os.homedir(), stdio:['pipe','pipe','pipe'], windowsHide:true });
  }catch(e){
    if(process.platform === 'win32'){
      const sh = findGitBash();
      if(sh) return cp.spawn(sh, ['--login','-lc',`${quote(devinPath())} acp`], { cwd: root() || os.homedir(), stdio:['pipe','pipe','pipe'], windowsHide:true });
    }
    throw e;
  }
}
function modelsFromAcpConfigOptions(configOptions){
  if(!Array.isArray(configOptions)) return [];
  const values=[];
  for(const opt of configOptions){
    const category = String(opt && opt.category || '').toLowerCase();
    const id = String(opt && opt.id || '').toLowerCase();
    const name = String(opt && opt.name || '').toLowerCase();
    if(category !== 'model' && id !== 'model' && !name.includes('model')) continue;
    const options = Array.isArray(opt.options) ? opt.options : [];
    for(const option of options){
      if(option && typeof option === 'object') values.push(option.value || option.id || option.name);
      else values.push(option);
    }
    if(opt.currentValue) values.push(opt.currentValue);
  }
  return uniqModels(values);
}
function discoverModelsViaAcp(){
  return new Promise((resolve)=>{
    let child;
    try{ child = spawnAcpProcess(); }catch(e){ resolve({models:[], error:e}); return; }
    let done=false;
    let buffer='';
    let stderr='';
    let sessionId;
    const timeoutMs = cfg().get('timeoutDescobertaModelosMs') || 15000;
    const timer = setTimeout(()=>finish([], new Error('Timeout ACP')), timeoutMs);
    function finish(models, err){
      if(done) return;
      done=true;
      clearTimeout(timer);
      try{
        if(sessionId) child.stdin.write(JSON.stringify({jsonrpc:'2.0',id:99,method:'session/close',params:{sessionId}})+'\n');
      }catch{}
      setTimeout(()=>{ try{ child.kill(); }catch{} }, 150);
      resolve({models, error:err, stderr});
    }
    function send(id, method, params){
      try{ child.stdin.write(JSON.stringify({jsonrpc:'2.0', id, method, params})+'\n'); }
      catch(e){ finish([], e); }
    }
    child.on('error', err=>finish([], err));
    child.stderr.on('data', d=>{ stderr += String(d); });
    child.stdout.on('data', data=>{
      buffer += String(data);
      let idx;
      while((idx = buffer.indexOf('\n')) >= 0){
        const line = buffer.slice(0, idx).trim();
        buffer = buffer.slice(idx+1);
        if(!line) continue;
        let msg;
        try{ msg = JSON.parse(line); }catch{ continue; }
        if(msg.id === 1 && msg.result){
          send(2, 'session/new', { cwd: root() || os.homedir(), mcpServers: [] });
        } else if(msg.id === 2){
          if(msg.error){ finish([], new Error(msg.error.message || 'Erro ACP em session/new')); return; }
          sessionId = msg.result && msg.result.sessionId;
          const models = modelsFromAcpConfigOptions(msg.result && msg.result.configOptions);
          if(models.length > 1) finish(models, undefined);
          else finish([], new Error('ACP nao retornou configOptions de modelo'));
        } else if(msg.id && msg.method){
          try{ child.stdin.write(JSON.stringify({jsonrpc:'2.0', id:msg.id, error:{code:-32601, message:'Metodo nao suportado pela descoberta de modelos'}})+'\n'); }catch{}
        }
      }
    });
    child.on('exit', code=>{ if(!done) finish([], new Error(`ACP encerrou com codigo ${code}`)); });
    send(1, 'initialize', {
      protocolVersion: 1,
      clientInfo: { name: 'Devin Cli Chat', version: '0.9.0' },
      clientCapabilities: { fs: { readTextFile:false, writeTextFile:false }, terminal:false }
    });
  });
}

function uniqModels(items){
  const out=[]; const seen=new Set();
  for(const raw of items){
    const value = normalizeCandidate(raw);
    if(!value) continue;
    const key = value.toLowerCase();
    if(!seen.has(key)){ seen.add(key); out.push(value); }
  }
  if(!out.includes('auto')) out.unshift('auto');
  return out;
}
function normalizeCandidate(raw){
  let s = String(raw || '').trim();
  s = s.replace(/^[`'"\[\](),:;]+|[`'"\[\](),:;]+$/g, '').trim();
  if(!s) return '';
  if(s === '<MODEL>' || s === '[MODEL]' || s === 'MODEL') return '';
  if(/[\\/]/.test(s) || s.includes('@')) return '';
  if(!/^[A-Za-z0-9][A-Za-z0-9._-]{1,80}$/.test(s)) return '';
  const lower = s.toLowerCase();
  const stop = new Set(['devin','model','models','available','allowed','valid','invalid','error','usage','options','prompt','print','response','exit','format','json','list','set','session','command','flag','slash','name','current','configured','default','padrao','the','and','or','for','with','true','false','normal','dangerous','bypass','accept-edits','plan','ask','workspace','help','version','auth','login','logout','status','mcp','rules','skills','paths','show','remove','add','update','setup','uninstall','context','compact','theme','mode']);
  if(stop.has(lower)) return '';
  if(KNOWN_MODEL_HINTS.has(lower)) return lower;
  if(/^(claude|gpt|codex|gemini|swe|kimi|glm|llama|mistral|deepseek|qwen|o[0-9]|nova|command|granite|mixtral)[A-Za-z0-9._-]*/i.test(s)) return s;
  if(/[.-]/.test(s) && /\d/.test(s)) return s;
  return '';
}
function collectStringsFromJson(obj, acc){
  if(Array.isArray(obj)){ for(const x of obj) collectStringsFromJson(x, acc); return; }
  if(obj && typeof obj === 'object'){
    for(const [k,v] of Object.entries(obj)){
      const key = k.toLowerCase();
      if(typeof v === 'string' && /(model|name|id|value)/.test(key)) acc.push(v);
      else collectStringsFromJson(v, acc);
    }
    return;
  }
  if(typeof obj === 'string') acc.push(obj);
}
function parseJsonModels(text){
  const clean = String(text||'').trim();
  if(!clean) return [];
  const chunks = [clean];
  const firstBrace = clean.search(/[\[{]/);
  if(firstBrace > 0) chunks.push(clean.slice(firstBrace));
  for(const c of chunks){
    try{
      const parsed = JSON.parse(c);
      const acc=[]; collectStringsFromJson(parsed, acc);
      const models = uniqModels(acc);
      if(models.length > 1) return models;
    }catch{}
  }
  return [];
}
function parseTextModels(text, trust){
  const all = String(text || '');
  const json = parseJsonModels(all);
  if(json.length > 1) return json;
  const candidates=[];
  const lines = all.split(/\r?\n/);
  for(const line of lines){
    const lower = line.toLowerCase();
    const modelishLine = /(model|models|allowed|available|valid|whitelist|allowlist|config name|provider|claude|gpt|codex|gemini|swe|opus|sonnet|kimi|glm|llama|mistral|deepseek|qwen)/.test(lower);
    if(trust === 'low' && !modelishLine) continue;
    const backticks = [...line.matchAll(/`([^`]+)`/g)].map(m=>m[1]);
    candidates.push(...backticks);
    const afterColon = line.includes(':') ? line.slice(line.indexOf(':')+1) : line;
    candidates.push(...afterColon.split(/[\s,|]+/g));
  }
  return uniqModels(candidates);
}
function loadModelCache(){
  if(!extensionContext) return;
  const cached = extensionContext.globalState.get(CACHE_KEY);
  if(cached && Array.isArray(cached.models)){
    const ttl = cfg().get('cacheModelosMs') || 1800000;
    const fresh = Date.now() - (cached.time || 0) < ttl;
    modelDiscovery = {
      status: fresh ? 'ok' : 'stale',
      detail: fresh ? 'Cache de modelos carregado.' : 'Cache de modelos expirado; aguardando nova descoberta.',
      source: cached.source || 'cache',
      models: cached.models
    };
  }
}
async function saveModelCache(models, source){
  if(!extensionContext) return;
  await extensionContext.globalState.update(CACHE_KEY, { time: Date.now(), source, models });
}
async function discoverModels(force){
  if(!cfg().get('descobrirModelosAutomaticamente', true)){
    modelDiscovery = {status:'off', detail:'Descoberta automatica desabilitada.', source:'configuracao', models:[]};
    provider && provider.refreshMeta(); updateStatus(); return modelDiscovery;
  }
  if(modelDiscoveryPromise) return modelDiscoveryPromise;
  const cached = extensionContext && extensionContext.globalState.get(CACHE_KEY);
  const ttl = cfg().get('cacheModelosMs') || 1800000;
  if(!force && cached && Array.isArray(cached.models) && Date.now() - (cached.time || 0) < ttl){
    modelDiscovery = {status:'ok', detail:'Lista carregada do cache local.', source:cached.source || 'cache', models:cached.models};
    provider && provider.refreshMeta(); updateStatus(); return modelDiscovery;
  }
  modelDiscovery = {status:'loading', detail:'Consultando o Devin CLI local...', source:'auto', models:modelDiscovery.models || []};
  provider && provider.refreshMeta(); updateStatus();
  modelDiscoveryPromise = (async()=>{
    const errors=[];
    const acp = await discoverModelsViaAcp();
    if(acp.models && acp.models.filter(m => m !== 'auto').length){
      const list = uniqModels(acp.models);
      modelDiscovery = {status:'ok', detail:`${list.length-1} modelo(s) detectado(s).`, source:'devin acp configOptions', models:list};
      await saveModelCache(list, 'devin acp configOptions');
      provider && provider.refreshMeta(); updateStatus();
      return modelDiscovery;
    }
    if(acp.error) errors.push(`devin acp: ${acp.error.message}`);
    for(const cmd of discoveryCommands()){
      const res = await execDevin(cmd.args);
      const text = [res.stdout, res.stderr].filter(Boolean).join('\n');
      const parsed = parseTextModels(text, cmd.trust);
      const useful = parsed.filter(m => m !== 'auto');
      if(useful.length){
        const list = uniqModels(parsed);
        modelDiscovery = {status:'ok', detail:`${list.length-1} modelo(s) detectado(s).`, source:cmd.source, models:list};
        await saveModelCache(list, cmd.source);
        provider && provider.refreshMeta(); updateStatus();
        return modelDiscovery;
      }
      if(res.err) errors.push(`${cmd.source}: ${res.err.message}`);
    }
    modelDiscovery = {status:'error', detail:`Nao foi possivel detectar modelos automaticamente. ${errors.slice(0,2).join(' | ')}`, source:'fallback', models:[]};
    provider && provider.refreshMeta(); updateStatus();
    return modelDiscovery;
  })();
  try { return await modelDiscoveryPromise; }
  finally { modelDiscoveryPromise = undefined; }
}
async function ensureModels(){
  if(!cfg().get('descobrirModelosAutomaticamente', true)) return;
  if(modelDiscovery.status === 'idle' || modelDiscovery.status === 'stale' || !modelDiscovery.models.length){
    discoverModels(false);
  }
}
async function pickManualModel(){ const value = await vscode.window.showInputBox({ title:'Devin Cli Chat: Definir modelo manual', prompt:'Informe o nome exato aceito pelo Devin CLI ou pela allowlist enterprise.', value: modelForCli() || '' }); if(value && value.trim()) await setConfig('modeloAtual', value.trim()); }
async function pickModel(){
  await discoverModels(false);
  const items = models().map(m => ({ label:m, description:m==='auto'?'nao envia --model; usa padrao/allowlist do Devin CLI':'' }));
  items.push({ label:'$(sync) Atualizar modelos do Devin CLI', description:'executa a descoberta automatica novamente' });
  items.push({ label:'$(edit) Informar modelo manual...', description:'usar um nome que nao aparece na lista' });
  const pick = await vscode.window.showQuickPick(items,{placeHolder:`Selecione o modelo Devin (${modelSourceLabel()})`});
  if(!pick) return;
  if(pick.label.includes('Atualizar modelos')){ await discoverModels(true); return pickModel(); }
  if(pick.label.includes('Informar modelo manual')) return pickManualModel();
  await setConfig('modeloAtual', pick.label);
}

class ChatViewProvider{
  constructor(context){ this.context=context; this.view=undefined; }
  resolveWebviewView(view){ this.view=view; view.webview.options={ enableScripts:true, localResourceRoots:[this.context.extensionUri] }; view.webview.html=this.html(view.webview); view.webview.onDidReceiveMessage(async msg=>{ if(msg.type==='ready'){ this.refreshMeta(); ensureModels(); } if(msg.type==='send') await this.send(msg.text||''); if(msg.type==='terminal') openTerminal(msg.text||''); if(msg.type==='setModel') await setConfig('modeloAtual', msg.value); if(msg.type==='manualModel') await pickManualModel(); if(msg.type==='refreshModels') await discoverModels(true); if(msg.type==='setAgent') await setConfig('agenteAtual', msg.value); if(msg.type==='review') await this.send('Revise o git diff atual com foco em bugs, seguranca, testes, impacto produtivo e rollback.\n\n```diff\n'+gitDiff()+'\n```'); if(msg.type==='selection') await this.send('Analise o contexto do editor atual.\n\n'+activeContext()); }); }
  post(m){ try{ this.view && this.view.webview.postMessage(m); }catch{} }
  refreshMeta(){ this.post({type:'meta', models:models(), model:model(), modelStatus:modelSourceLabel(), modelDiscoveryStatus:modelDiscovery.status, agents:scanAgents(), agent:agent(), workspace:rootName(), mode:cfg().get('modoExecucaoChat')||'resposta-integrada'}); }
  async send(text){ const prompt = String(text||'').trim(); if(!prompt) return; this.post({type:'message', role:'user', text:prompt}); this.post({type:'busy', value:true}); const mode = cfg().get('modoExecucaoChat') || 'resposta-integrada'; if(mode === 'terminal'){ openTerminal(prompt); this.post({type:'message', role:'assistant', text:'Sessao aberta no terminal integrado, ja posicionada na pasta aberta no VS Code.'}); this.post({type:'busy', value:false}); return; } const answer = await runIntegrated(prompt); this.post({type:'message', role:'assistant', text:answer}); this.post({type:'busy', value:false}); }
  html(webview){ const nonce=Date.now().toString(36); return `<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline' ${webview.cspSource}; script-src 'nonce-${nonce}';"><meta name="viewport" content="width=device-width, initial-scale=1.0"><style>
:root{--bg:var(--vscode-sideBar-background);--fg:var(--vscode-foreground);--muted:var(--vscode-descriptionForeground);--border:var(--vscode-panel-border);--input:var(--vscode-input-background);--button:var(--vscode-button-background);--buttonfg:var(--vscode-button-foreground)}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font-family:var(--vscode-font-family);font-size:var(--vscode-font-size);height:100vh;display:flex;flex-direction:column}.top{border-bottom:1px solid var(--border);padding:10px;display:grid;gap:8px}.brand{display:flex;align-items:center;justify-content:space-between}.brand b{font-size:13px}.workspace{font-size:11px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:55%}.selectors{display:grid;grid-template-columns:1fr 1fr;gap:6px}.selectblock label{font-size:10px;color:var(--muted);display:block;margin-bottom:3px}.selectrow{display:grid;grid-template-columns:1fr auto auto;gap:4px}select{width:100%;background:var(--input);color:var(--fg);border:1px solid var(--border);border-radius:4px;padding:5px}.quick{display:flex;gap:6px;flex-wrap:wrap}button{background:var(--button);color:var(--buttonfg);border:0;border-radius:4px;padding:5px 8px;cursor:pointer}button.secondary{background:var(--vscode-button-secondaryBackground);color:var(--vscode-button-secondaryForeground)}.messages{flex:1;overflow:auto;padding:10px;display:flex;flex-direction:column;gap:10px}.msg{border:1px solid var(--border);border-radius:8px;padding:9px;white-space:pre-wrap;line-height:1.42}.user{background:var(--vscode-editor-inactiveSelectionBackground)}.assistant{background:var(--vscode-editor-background)}.role{font-size:10px;color:var(--muted);margin-bottom:5px;text-transform:uppercase}.composer{border-top:1px solid var(--border);padding:10px;display:grid;gap:8px}textarea{width:100%;min-height:82px;resize:vertical;background:var(--input);color:var(--fg);border:1px solid var(--border);border-radius:6px;padding:8px;font-family:var(--vscode-editor-font-family)}.actions{display:flex;gap:8px;align-items:center}.hint{font-size:11px;color:var(--muted);margin-left:auto}.busy{opacity:.65;pointer-events:none}.mini{padding:4px 6px}.modelStatus{font-size:10px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}</style></head><body><div class="top"><div class="brand"><b>Devin Cli Chat</b><span class="workspace" id="workspace">workspace</span></div><div class="selectors"><div class="selectblock"><label>Modelo</label><div class="selectrow"><select id="model"></select><button class="secondary mini" id="refreshModels" title="Atualizar modelos do Devin CLI">R</button><button class="secondary mini" id="manualModel" title="Informar modelo manual">+</button></div><div class="modelStatus" id="modelStatus">detectando modelos...</div></div><div class="selectblock"><label>Agente</label><select id="agent"></select></div></div><div class="quick"><button class="secondary" id="selection">Contexto do editor</button><button class="secondary" id="review">Revisar diff</button><button class="secondary" id="terminal">Sessao</button></div></div><main class="messages" id="messages"><div class="msg assistant"><div class="role">Devin Cli Chat</div>Tela propria de chat com Devin CLI. A execucao ocorre no workspace aberto no VS Code. A lista de modelos e descoberta automaticamente no Devin CLI local. Use R para recarregar ou + para informar um modelo manual.</div></main><div class="composer"><textarea id="prompt" placeholder="Peca para planejar, revisar, explicar, corrigir ou gerar testes..."></textarea><div class="actions"><button id="send">Enviar</button><span class="hint" id="mode"></span></div></div><script nonce="${nonce}">const vscode=acquireVsCodeApi();const $=id=>document.getElementById(id);function opt(sel,items,val){const current=sel.value;sel.innerHTML='';items.forEach(x=>{const o=document.createElement('option');o.value=x;o.textContent=x==='auto'?'auto - padrao Devin CLI':x;if(x===val || (!val && x===current))o.selected=true;sel.appendChild(o)})}function add(role,text){const d=document.createElement('div');d.className='msg '+(role==='user'?'user':'assistant');const r=document.createElement('div');r.className='role';r.textContent=role==='user'?'Voce':'Devin Cli Chat';d.appendChild(r);const pre=document.createElement('div');pre.textContent=text;d.appendChild(pre);$('messages').appendChild(d);$('messages').scrollTop=$('messages').scrollHeight}window.addEventListener('message',e=>{const m=e.data;if(m.type==='meta'){opt($('model'),m.models,m.model);opt($('agent'),m.agents,m.agent);$('workspace').textContent=m.workspace;$('mode').textContent=m.mode==='terminal'?'terminal':'integrado';$('modelStatus').textContent=m.modelStatus||'';$('refreshModels').textContent=m.modelDiscoveryStatus==='loading'?'...':'R'} if(m.type==='message')add(m.role,m.text); if(m.type==='busy')document.body.classList.toggle('busy',m.value)});$('send').onclick=()=>{const t=$('prompt').value.trim();if(t){vscode.postMessage({type:'send',text:t});$('prompt').value=''}};$('prompt').addEventListener('keydown',e=>{if(e.key==='Enter'&&(e.metaKey||e.ctrlKey))$('send').click()});$('model').onchange=e=>vscode.postMessage({type:'setModel',value:e.target.value});$('manualModel').onclick=()=>vscode.postMessage({type:'manualModel'});$('refreshModels').onclick=()=>vscode.postMessage({type:'refreshModels'});$('agent').onchange=e=>vscode.postMessage({type:'setAgent',value:e.target.value});$('terminal').onclick=()=>vscode.postMessage({type:'terminal'});$('review').onclick=()=>vscode.postMessage({type:'review'});$('selection').onclick=()=>vscode.postMessage({type:'selection'});vscode.postMessage({type:'ready'});</script></body></html>`; }
}
async function activate(context){
  extensionContext = context;
  loadModelCache();
  provider=new ChatViewProvider(context);
  context.subscriptions.push(vscode.window.registerWebviewViewProvider('devinCliChat.chatView',provider,{webviewOptions:{retainContextWhenHidden:true}}));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.abrirPainel',async()=>vscode.commands.executeCommand('workbench.view.extension.devinCliChat')));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.novaSessao',()=>openTerminal('')));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.revisarDiff',async()=>{await vscode.commands.executeCommand('workbench.view.extension.devinCliChat'); provider && provider.send('Revise o git diff atual com foco em bugs, seguranca, testes, impacto produtivo e rollback.\n\n```diff\n'+gitDiff()+'\n```');}));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.enviarSelecao',async()=>{await vscode.commands.executeCommand('workbench.view.extension.devinCliChat'); provider && provider.send('Analise o contexto do editor atual.\n\n'+activeContext());}));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.selecionarModelo',pickModel));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.definirModeloManual',pickManualModel));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.atualizarModelos',async()=>{ await discoverModels(true); vscode.window.showInformationMessage(modelDiscovery.models.length ? `Modelos atualizados: ${modelDiscovery.models.length-1} detectado(s).` : `Nao foi possivel detectar modelos automaticamente.`); }));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.selecionarAgente',async()=>{const pick=await vscode.window.showQuickPick(scanAgents(),{placeHolder:'Selecione o agente Devin'}); if(pick) await setConfig('agenteAtual',pick);}));
  context.subscriptions.push(vscode.commands.registerCommand('devinCliChat.verificarCli',async()=>{cp.execFile(devinPath(),['--version'],{cwd:root()||os.homedir(),windowsHide:true},(err,stdout,stderr)=>{vscode.window.showInformationMessage(err?`Falha ao verificar Devin CLI: ${err.message}`:`Devin CLI encontrado: ${(stdout||stderr||'ok').trim()}`); if(!err) discoverModels(true);});}));
  updateStatus();
  ensureModels();
  context.subscriptions.push(vscode.workspace.onDidChangeConfiguration(e=>{if(e.affectsConfiguration(EXT)){loadModelCache(); updateStatus(); provider && provider.refreshMeta(); ensureModels();}}));
}
function deactivate(){}
module.exports={activate,deactivate};
