# Changelog

## 0.5.0

- Desenvolvedor alterado para Luiz Ferrarezi.
- Corrigida a execução integrada: agora usa `devin -p -- <prompt>` para capturar resposta no painel.
- Sessão interativa passa a usar `devin -- <prompt>` quando há prompt inicial.
- Execução integrada passa a usar `execFile`, sem dependência de PowerShell.
- Fallback via Git Bash no Windows quando necessário.
- Lista de modelos atualizada para nomes curtos suportados pelo Devin CLI.
- Documentação em português brasileiro atualizada.

## 0.4.0

- Painel lateral de chat com seletor de modelo e agente.
- Integração com Chat nativo do VS Code via `@iudevachat`.
