# iuDevaChat

Desenvolvedor: **Luiz Ferrarezi**

Extensão VS Code para operar o **Devin CLI** em uma experiência de chat lateral, com seleção de modelo, seleção de agente e execução ancorada na pasta aberta no VS Code.

## Uso

1. Instale o VSIX.
2. Abra uma pasta no VS Code.
3. Abra a Activity Bar **iuDevaChat**.
4. Selecione o modelo e o agente.
5. Envie mensagens pelo painel ou use `@iudevachat` no Chat nativo do VS Code.

## Modos

- **Resposta integrada**: usa `devin -p -- <prompt>` para capturar a resposta e renderizar no painel.
- **Terminal**: abre uma sessão REPL do Devin CLI no terminal integrado.

A documentação atual do Devin CLI recomenda `devin -p` para uso single-turn/scriptável e `devin -- <prompt>` para iniciar REPL com prompt inicial.

## Windows corporativo

A extensão não depende de PowerShell para abrir sessões. No terminal integrado do Windows, ela tenta usar Git Bash quando `iudevachat.usarGitBashNoWindows` está habilitado.

Configure manualmente quando necessário:

```json
{
  "iudevachat.gitBashPath": "C:\\Program Files\\Git\\bin\\bash.exe"
}
```

## Configurações principais

```json
{
  "iudevachat.caminhoDevin": "devin",
  "iudevachat.modeloAtual": "opus",
  "iudevachat.modelosDisponiveis": ["opus", "sonnet", "swe", "codex", "gemini"],
  "iudevachat.agenteAtual": "auto",
  "iudevachat.modoExecucaoChat": "resposta-integrada",
  "iudevachat.usarGitBashNoWindows": true
}
```

## Agentes

A extensão lista agentes encontrados em:

```text
.devin/agents/<nome>/AGENT.md
~/.config/devin/agents/<nome>/AGENT.md
```

Quando um agente é selecionado, o nome é injetado no contexto do prompt. Isso evita acoplamento a flags ainda não consolidadas para subagentes no Devin CLI.

## Comandos

- `iuDevaChat: Abrir chat`
- `iuDevaChat: Nova sessão Devin no workspace`
- `iuDevaChat: Revisar git diff`
- `iuDevaChat: Selecionar modelo`
- `iuDevaChat: Selecionar agente`
- `iuDevaChat: Verificar Devin CLI`
